package com.example.shop.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Bài 18 — cache tỷ giá. Lời gọi mạng tốt nhất là lời gọi không xảy ra.
 * ConcurrentMapCacheManager KHÔNG có TTL — Bài 19 thay bằng Caffeine (10 phút) rồi Redis.
 */
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("exchangeRates");
    }
}
