package com.example.shop.config;

import java.util.Optional;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Bài 16 — bật auditing. Class RIÊNG, không đặt @EnableJpaAuditing lên ShopApiApplication
 * (test lát cắt ở Bài 26 sẽ vấp nếu đặt ở đó).
 */
@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
public class JpaAuditingConfig {

    /** Ai đang thao tác. Bài 22 sẽ đọc từ SecurityContextHolder. */
    @Bean
    public AuditorAware<String> auditorAware() {
        return () -> Optional.of("system");
    }
}
