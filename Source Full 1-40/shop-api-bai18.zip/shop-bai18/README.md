# shop-api — trạng thái sau Bài 18: Gọi API bên ngoài

> Bài học chính không phải cách gọi HTTP — mà là cách **không để dịch vụ của người khác
> kéo sập dịch vụ của bạn**.

## Chạy

```bash
docker compose up -d
mvn spring-boot:run
curl http://localhost:8081/api/products/1/price-usd
```

```json
{ "id": 1, "name": "Bàn phím cơ", "price": 1250000.0, "currency": "VND",
  "convertedPrice": 49.21, "convertedCurrency": "USD", "nguonTyGia": "API" }
```

API tỷ giá: https://open.er-api.com (miễn phí, không cần key).

## Thay đổi so với Bài 17

| | |
|---|---|
| `pom.xml` | + `spring-retry`, `spring-aspects` |
| `config/ExchangeRateProperties.java` | base-url, connect/read timeout, tỷ giá mặc định |
| `config/RestClientConfig.java` | `RestClient` **có timeout** |
| `config/RetryConfig.java`, `CacheConfig.java` | `@EnableRetry`, `@EnableCaching` |
| `client/` | `ExchangeRateClient` + record + hai exception 4xx/5xx |
| `ProductService.giaQuyDoi` | Bắt lỗi → tỷ giá mặc định, `nguonTyGia: "MAC_DINH"` |
| `GET /api/products/{id}/price-usd` | **Mới** |

## Ba thí nghiệm (sửa `application.yml`, trả lại sau)

| | `base-url` | Kết quả |
|---|---|---|
| 1 | `https://khong-ton-tai-12345.example.com/v6` | 3 lần thử, vẫn 200 với tỷ giá mặc định |
| 2 | `https://httpbin.org/delay/10` | Mỗi lần hỏng sau 5s — tổng ~16s: retry không miễn phí |
| 3 | endpoint treo + **bỏ timeout** | Request không bao giờ về — 200 cái là cả API chết |

## Ba cơ chế bổ sung nhau

| | Chặn |
|---|---|
| **Timeout** | Treo vô hạn |
| **Retry** + backoff + jitter | Lỗi thoáng qua — chỉ 5xx và lỗi mạng, không 4xx |
| **Circuit breaker** (nâng cao, comment cuối `ExchangeRateClient`) | Gõ cửa một cánh cửa đã khoá |

## Bẫy

| Bẫy | |
|---|---|
| Không timeout | Mặc định vô hạn — một dịch vụ phụ kéo sập cả hệ thống |
| Retry mọi lỗi | 4xx thử lại vẫn sai, chỉ làm người dùng đợi lâu hơn |
| `@Recover` + `@Cacheable` | Giá trị mặc định bị cache — không TTL là nằm đó tới khi restart |
| Self-invocation | `@Retryable`, `@Cacheable` vô hiệu khi gọi qua `this` |

> Mọi lời gọi ra ngoài đều có thể chậm, lỗi, hoặc không bao giờ trả về.
