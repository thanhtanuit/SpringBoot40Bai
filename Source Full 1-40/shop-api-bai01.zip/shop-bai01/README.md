# shop-api — trạng thái sau Bài 1: Endpoint đầu tiên

Dự án chạy xuyên suốt 40 bài của khoá **Luyện Spring Boot**. Đây là điểm xuất phát:
một ứng dụng Spring Boot với đúng một dependency và ba endpoint.

## Yêu cầu

- JDK 21 (`java -version` phải thấy số 21)
- Maven 3.9+ (hoặc dùng `mvnw` nếu bạn tạo dự án từ start.spring.io)

## Chạy

```bash
mvn spring-boot:run
```

Tìm trong log dòng `Tomcat started on port 8081`. Không cài Tomcat, không đóng gói WAR —
Spring Boot nhúng sẵn Tomcat vào ứng dụng.

> Muốn có `./mvnw` như trong video: chạy một lần `mvn wrapper:wrapper` ở thư mục gốc.

## Ba endpoint

| Request | Kết quả | Content-Type |
|---|---|---|
| `GET /api/hello` | `Xin chào Spring Boot` | `text/plain` |
| `GET /api/hello/Nam` | `Xin chào, Nam` | `text/plain` |
| `GET /api/tinh?a=3&b=5` | `{"a":3,"b":5,"tong":8}` | `application/json` |

Kiểm chứng Content-Type:

```bash
curl -i http://localhost:8081/api/hello
curl -i "http://localhost:8081/api/tinh?a=3&b=5"
```

Hoặc mở `requests.http` trong IntelliJ và bấm ▶ cạnh từng request.

## Cấu trúc

```
shop-api/
├── pom.xml                          chỉ spring-boot-starter-web (+ test)
├── requests.http
└── src/main/
    ├── java/com/example/shop/
    │   ├── ShopApiApplication.java  @SpringBootApplication
    │   └── web/
    │       ├── HelloController.java ba endpoint
    │       └── KetQua.java          record trả về dạng JSON
    └── resources/
        └── application.properties   server.port=8081
```

## Vì sao trả object lại ra JSON?

Spring giữ một danh sách `HttpMessageConverter`. Khi method trả về giá trị, Spring chọn
bộ **đầu tiên** xử lý được kiểu đó:

- `String` → `StringHttpMessageConverter` → `text/plain`
- `KetQua` → `MappingJackson2HttpMessageConverter` (Jackson) → `application/json`

Jackson đi kèm Spring Web; auto-configuration thấy nó trong classpath và tự đăng ký.

## Ba cái bẫy của Bài 1

| Bẫy | Triệu chứng | Cách tránh |
|---|---|---|
| Class nằm ngoài package gốc | Gọi API ra 404, không có lỗi nào | Mọi class đặt dưới `com.example.shop` |
| Dùng `@Controller` cho API | Spring đi tìm trang HTML | Luôn dùng `@RestController` |
| Tự ghép chuỗi JSON | Dữ liệu có dấu nháy là vỡ | Trả về object, để Jackson lo |

## Bài tập

1. Làm lại đủ ba endpoint mà không nhìn video.
2. Viết comment trên `HelloController` tự giải thích vì sao object ra JSON.
3. Thí nghiệm: chuyển `HelloController` sang package `com.example.controller`, chạy lại,
   gọi `/api/hello` → thấy 404. Rồi chuyển về.

## Bài sau

**Bài 2 — CRUD trong bộ nhớ:** dùng chính controller này làm đủ bộ thêm, xem, sửa, xoá
sản phẩm, và trả đúng mã trạng thái HTTP — 201, 204, 404.
