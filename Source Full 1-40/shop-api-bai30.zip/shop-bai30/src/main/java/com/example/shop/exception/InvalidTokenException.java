package com.example.shop.exception;

/** 401 — REFRESH_TOKEN_INVALID, SESSION_REVOKED, TOKEN_EXPIRED. */
public class InvalidTokenException extends BusinessException {

    public InvalidTokenException(ErrorCode code) {
        super(code);
    }
}
