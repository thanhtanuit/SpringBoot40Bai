package com.example.shop.exception;

import java.util.Arrays;

/**
 * Bài 30 — exception gốc mang ErrorCode. args chèn vào thông điệp ({0}, {1}...) — dịch ở
 * GlobalExceptionHandler theo Accept-Language.
 *
 * message nội bộ = mã + tham số — cho LOG và test, không phải cho người dùng.
 * Vẫn extends RuntimeException (Bài 5) → rollback đúng (Bài 13).
 */
public class BusinessException extends RuntimeException {

    private final ErrorCode code;
    private final transient Object[] args;

    public BusinessException(ErrorCode code, Object... args) {
        super(code.name() + (args.length > 0 ? " " + Arrays.toString(args) : ""));
        this.code = code;
        this.args = args;
    }

    public ErrorCode getCode() {
        return code;
    }

    public Object[] getArgs() {
        return args;
    }
}
