package com.example.shop.security;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Bài 22 — đọc "Authorization: Bearer ..." và đặt Authentication vào SecurityContext.
 *
 * KHÔNG phải @Component, CÓ CHỦ ĐÍCH: Filter là bean thì Spring Boot TỰ ĐĂNG KÝ nó thêm một lần
 * vào servlet filter chain thường, chạy TRƯỚC Spring Security. OncePerRequestFilter sau đó bỏ qua
 * lần chạy trong security chain, và SecurityContextHolderFilter ghi đè context vừa đặt
 * → 401 khó hiểu. SecurityConfig tạo filter này bằng new.
 *
 * OncePerRequestFilter: chạy ĐÚNG MỘT LẦN mỗi request (không lặp khi forward/error dispatch).
 *
 * Filter KHÔNG ném exception — chỉ đặt hoặc không đặt Authentication. Từ chối là việc của
 * AuthorizationFilter phía sau; tạo 401 là việc của AuthenticationEntryPoint. Ném từ filter
 * → trang lỗi HTML mặc định của Tomcat, không phải JSON.
 *
 * SecurityContextHolder nằm trong ThreadLocal — cùng cơ chế MDC (Bài 7), cùng lý do không
 * tự sang thread @Async (Bài 20).
 */
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
    private static final String PREFIX = "Bearer ";

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    public JwtAuthenticationFilter(JwtService jwtService, UserDetailsService userDetailsService) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {

        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith(PREFIX)) {
            chain.doFilter(request, response);   // không có token → để phía sau quyết định
            return;
        }

        String token = header.substring(PREFIX.length());
        try {
            String username = jwtService.extractUsername(token);
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                if (jwtService.isValid(token, userDetails)) {
                    var auth = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            }
        } catch (Exception e) {
            // Chữ ký sai, hết hạn, sai định dạng, user bị xoá... → coi như chưa đăng nhập
            log.debug("Token không hợp lệ: {}", e.getMessage());
            SecurityContextHolder.clearContext();
        }

        chain.doFilter(request, response);
    }

    /** Chỉ bỏ qua các endpoint KHÔNG cần token. /api/auth/me cần token nên vẫn lọc. */
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();
        return path.equals("/api/v1/auth/login")
                || path.equals("/api/v1/auth/register")
                || path.equals("/api/v1/auth/refresh");
    }
}
