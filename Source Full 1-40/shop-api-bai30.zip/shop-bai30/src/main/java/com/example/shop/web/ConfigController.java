package com.example.shop.web;

import java.util.List;
import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.config.ShopProperties;
import com.example.shop.payment.PaymentGateway;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * CHỈ ĐỂ HỌC — xem cấu hình đang có hiệu lực.
 * Phơi cấu hình ra ngoài ở production là việc KHÔNG làm.
 * Bài 29 thay bằng Actuator, có kiểm soát quyền truy cập.
 */
@RestController
@Tag(name = "Dev")
@RequestMapping("/config")
public class ConfigController {

    private final ShopProperties shop;
    private final Environment env;
    private final PaymentGateway gateway;

    public ConfigController(ShopProperties shop, Environment env, PaymentGateway gateway) {
        this.shop = shop;
        this.env = env;
        this.gateway = gateway;
    }

    @GetMapping
    public Map<String, Object> config() {
        return Map.of(
                "shop", shop,
                "activeProfiles", List.of(env.getActiveProfiles()),
                "defaultProfiles", List.of(env.getDefaultProfiles()));
    }

    /** dev → FakePaymentGateway · prod → RealPaymentGateway */
    @GetMapping("/gateway")
    public Map<String, String> gateway() {
        return Map.of("gateway", gateway.getClass().getSimpleName());
    }
}
