package com.example.shop.web;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.dto.AuthResponse;
import com.example.shop.dto.LoginRequest;
import com.example.shop.dto.RefreshRequest;
import com.example.shop.dto.RegisterRequest;
import com.example.shop.dto.UserResponse;
import com.example.shop.model.User;
import com.example.shop.service.AuthService;

import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/auth")
@Tag(name = "Auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register")
    @SecurityRequirements
    @Operation(summary = "Đăng ký", description = "Người tự đăng ký luôn là USER.")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse dangKy(@Valid @RequestBody RegisterRequest req) {
        User user = service.dangKy(req);
        return new UserResponse(user.getId(), user.getUsername(), user.getEmail(),
                user.getRoles().stream().map(Enum::name).sorted().toList());
    }

    @PostMapping("/login")
    @SecurityRequirements
    @Operation(summary = "Đăng nhập",
               description = "Trả `accessToken` (15 phút) và `refreshToken` (7 ngày). Dán accessToken vào **Authorize**.")
    @ApiResponse(responseCode = "401", description = "Sai tên đăng nhập hoặc mật khẩu")
    public AuthResponse dangNhap(@Valid @RequestBody LoginRequest req) {
        return service.dangNhap(req);
    }

    @PostMapping("/refresh")
    @SecurityRequirements
    @Operation(summary = "Làm mới token",
               description = "Xoay vòng: token cũ bị thu hồi. Dùng lại token đã thu hồi → thu hồi TOÀN BỘ phiên.")
    public AuthResponse lamMoi(@Valid @RequestBody RefreshRequest req) {
        return service.lamMoi(req.refreshToken());
    }

    @PostMapping("/logout")
    @SecurityRequirements
    @Operation(summary = "Đăng xuất", description = "Thu hồi refresh token. Access token vẫn dùng được tới hết hạn.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void dangXuat(@Valid @RequestBody RefreshRequest req) {
        service.dangXuat(req.refreshToken());
    }

    /** @AuthenticationPrincipal gọn hơn SecurityContextHolder...getPrincipal() rồi ép kiểu. */
    @GetMapping("/me")
    @Operation(summary = "Người đang đăng nhập")
    @PreAuthorize("isAuthenticated()")
    public UserResponse toi(@AuthenticationPrincipal UserDetails user) {
        return service.thongTinHienTai(user.getUsername());
    }
}
