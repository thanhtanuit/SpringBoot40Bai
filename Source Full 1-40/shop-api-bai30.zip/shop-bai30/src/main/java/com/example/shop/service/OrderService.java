package com.example.shop.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.OrderItemRequest;
import com.example.shop.exception.BusinessException;
import com.example.shop.exception.ErrorCode;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.metrics.OrderMetrics;
import com.example.shop.model.AuditLog;
import com.example.shop.model.Order;
import com.example.shop.model.OrderItem;
import com.example.shop.model.Product;
import com.example.shop.repository.AuditLogRepository;
import com.example.shop.repository.OrderRepository;
import com.example.shop.repository.ProductRepository;

/**
 * Bài 13 — một nghiệp vụ là MỘT transaction: trừ kho, lưu đơn, ghi audit
 * cùng sống hoặc cùng chết.
 *
 * Import từ org.springframework.transaction.annotation — KHÔNG phải jakarta.transaction
 * (thiếu readOnly, propagation, rollbackFor).
 *
 * Spring tiêm vào controller một PROXY bọc ngoài class này. Proxy mở transaction,
 * gọi method thật, xong êm thì commit, có exception thì rollback.
 * → Transaction nằm ở PROXY, không nằm trong code của bạn.
 *
 * ===== THÍ NGHIỆM 1 — tháo @Transactional =====
 * Gỡ @Transactional khỏi class, thêm productRepo.save(p) ở bước 1 (dirty checking chỉ
 * chạy TRONG transaction). Đặt hàng với customerName "LOI ..." → 500.
 * SELECT lại: kho ĐÃ GIẢM, đơn ĐÃ LƯU, audit TRỐNG. Người dùng bấm lại → trừ kho lần nữa.
 * Không có transaction thì mỗi lời gọi repository tự commit ngay.
 *
 * ===== THÍ NGHIỆM 2 — checked exception =====
 * Đổi dòng throw ở công tắc LOI thành  throw new Exception(...)  (+ throws Exception).
 * Dữ liệu BỊ LƯU dù có @Transactional.
 * BẪY 1: Spring chỉ tự rollback với RuntimeException và Error. Checked → COMMIT.
 * Sửa: @Transactional(rollbackFor = Exception.class) — hoặc như Bài 5: exception nghiệp vụ
 * luôn extends RuntimeException.
 *
 * ===== THÍ NGHIỆM 3 — self-invocation (xem datHangSai bên dưới) =====
 */
@Service
@Transactional
public class OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepo;
    private final ProductRepository productRepo;
    private final AuditLogRepository auditRepo;
    private final AuditService auditService;
    private final CacheManager cacheManager;
    private final NotificationService notificationService;
    private final OrderMetrics metrics;

    public OrderService(OrderRepository orderRepo, ProductRepository productRepo,
                        AuditLogRepository auditRepo, AuditService auditService,
                        CacheManager cacheManager, NotificationService notificationService,
                        OrderMetrics metrics) {
        this.orderRepo = orderRepo;
        this.productRepo = productRepo;
        this.auditRepo = auditRepo;
        this.auditService = auditService;
        this.cacheManager = cacheManager;
        this.notificationService = notificationService;
        this.metrics = metrics;
    }

    /** Bài 29 — bọc bằng Timer + đếm thành công/thất bại. */
    public Order datHang(CreateOrderRequest req) {
        return metrics.doThoiGian(() -> {
            try {
                Order don = xuLyDatHang(req);
                metrics.ghiNhanThanhCong(don.getTotalAmount());
                return don;
            } catch (BusinessException e) {
                // tag bằng mã lỗi: tập giá trị HỮU HẠN, không bùng nổ cardinality
                metrics.ghiNhanThatBai(e.getCode().name().toLowerCase());
                throw e;
            } catch (RuntimeException e) {
                metrics.ghiNhanThatBai("other");
                throw e;
            }
        });
    }

    private Order xuLyDatHang(CreateOrderRequest req) {
        log.debug("Yêu cầu đặt hàng khách={} số dòng={}", req.customerName(), req.items().size());

        // REQUIRES_NEW — ghi TRƯỚC chỗ có thể lỗi. Đơn rollback thì dòng này vẫn còn.
        auditService.ghi("ATTEMPT", "Order", null,
                "Khách " + req.customerName() + " thử đặt " + req.items().size() + " dòng");

        Order order = new Order(req.customerName());

        // ===== Bước 1: trừ kho =====
        for (OrderItemRequest dong : req.items()) {
            Product p = productRepo.findById(dong.productId())
                    .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.PRODUCT_NOT_FOUND, dong.productId()));
            if (p.getStock() < dong.quantity()) {
                // Bài 30: mã + tham số, thông điệp dịch theo ngôn ngữ người gọi
                throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK,
                        p.getName(), p.getStock(), dong.quantity());
            }
            p.setStock(p.getStock() - dong.quantity());   // dirty checking — trong transaction
            order.addItem(new OrderItem(p, dong.quantity()));
            dotCacheSanPham(p.getId());
        }

        // ===== Bước 2: lưu đơn =====
        order.tinhTongTien();
        Order daLuu = orderRepo.save(order);

        // ===== Công tắc bật lỗi: tên bắt đầu "LOI" → hỏng ngay trước bước 3 =====
        if (req.customerName().startsWith("LOI")) {
            throw new RuntimeException("Lỗi giả lập sau khi đã trừ kho và lưu đơn");
        }

        // ===== Bước 3: ghi audit — CÙNG transaction =====
        auditRepo.save(new AuditLog("CREATE", "Order", daLuu.getId(),
                "Tổng " + daLuu.getTotalAmount()));

        log.info("Đã tạo đơn hàng id={} tổng={}", daLuu.getId(), daLuu.getTotalAmount());

        // Bài 20 — @Async: truyền ID và String, KHÔNG truyền entity.
        // Chạy TRƯỚC commit — rollback sau đó thì email đã đi (Bài 32 sửa).
        notificationService.guiThongBaoDatHang(daLuu.getId(), daLuu.getCustomerName());
        return daLuu;
    }

    /**
     * THÍ NGHIỆM 3 — BẪY 2: SELF-INVOCATION.
     *
     * SUPPORTS: không có transaction sẵn thì proxy KHÔNG mở cái mới.
     * Bên trong, this.datHang(req) — "this" là OBJECT THẬT, không phải proxy
     * → lời gọi đi thẳng, @Transactional của datHang KHÔNG có tác dụng.
     * Mỗi lời gọi repository tự commit riêng → đơn "LOI..." vẫn được lưu, dữ liệu lệch.
     *
     * Cùng số phận: @Cacheable (Bài 19), @Async (Bài 20), @PreAuthorize (Bài 23).
     * Cách sửa: tách sang class khác (sạch nhất) · tự tiêm chính mình với @Lazy ·
     * TransactionTemplate.
     *
     * Để thử: bỏ comment endpoint /api/orders/sai trong OrderController, gọi với tên
     * "LOI ...", kiểm tra bằng SQL. Quan sát xong XOÁ method này và endpoint đó.
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public Order datHangSai(CreateOrderRequest req) {
        return this.datHang(req);
    }

    /**
     * Bài 19 — ĐƯỜNG GHI KHÁC cũng phải dọn cache: trừ kho làm ProductResponse.stock cũ.
     * Cache transaction-aware → evict thực hiện SAU commit; rollback thì không evict.
     * (Tồn kho vốn là dữ liệu KHÔNG nên cache lâu — câu hỏi trước khi cache:
     * "dữ liệu cũ vài phút có chấp nhận được không?")
     */
    private void dotCacheSanPham(Long productId) {
        Cache cache = cacheManager.getCache("products");
        if (cache != null) {
            cache.evict(productId);
        }
    }

    /**
     * Bài 25 — quy tắc giảm giá theo tổng đơn (CHƯA áp vào datHang — dùng để luyện
     * @ParameterizedTest với giá trị SÁT RANH GIỚI).
     * double có sai số — tiền thật nên dùng BigDecimal (lần thứ hai gặp, sau Bài 12).
     */
    double tinhGiamGia(double tongTien) {
        if (tongTien >= 10_000_000) {
            return tongTien * 0.15;
        }
        if (tongTien >= 5_000_000) {
            return tongTien * 0.10;
        }
        if (tongTien >= 2_000_000) {
            return tongTien * 0.05;
        }
        return 0;
    }

    @Transactional(readOnly = true)
    public Order findById(Long id) {
        return orderRepo.findByIdWithItems(id)
                .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.ORDER_NOT_FOUND, id));
    }
}
