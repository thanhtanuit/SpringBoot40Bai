package com.example.shop.web;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.shop.model.Product;
import com.example.shop.service.ProductService;
import com.example.shop.storage.FileStorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Bài 17 — ảnh sản phẩm.
 *
 * KHÔNG BAO GIỜ phục vụ file người dùng tải lên từ cùng domain với ứng dụng mà không
 * phòng bị: một "ảnh" chứa HTML/JS có thể thành XSS. Ở đây: nosniff + chỉ trả đúng
 * image/png hoặc image/jpeg. Thực tế: domain riêng cho nội dung tĩnh, hoặc
 * Content-Disposition: attachment.
 */
@RestController
@RequestMapping("/products/{id}/image")
@Tag(name = "Product images")
public class ProductImageController {

    private final ProductService service;
    private final FileStorageService storage;

    public ProductImageController(ProductService service, FileStorageService storage) {
        this.service = service;
        this.storage = storage;
    }

    @PostMapping(consumes = org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Tải ảnh lên", description = "PNG hoặc JPEG, tối đa 2MB. Tên file do server sinh (UUID).")
    public Map<String, String> upload(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        String tenFile = service.capNhatAnh(id, file);
        return Map.of(
                "filename", tenFile,
                "url", "/api/v1/products/%d/image".formatted(id));
    }

    /** Nâng cao — nhiều file; max-request-size (10MB) mới là thứ chặn ở đây. */
    @PostMapping("/batch")
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    public List<String> uploadNhieu(@PathVariable Long id, @RequestParam("files") MultipartFile[] files) {
        service.findById(id);
        return Arrays.stream(files).map(storage::store).toList();
    }

    @GetMapping
    @SecurityRequirements
    @Operation(summary = "Tải ảnh về")
    public ResponseEntity<Resource> download(@PathVariable Long id) {
        Product product = service.findById(id);
        if (product.getImagePath() == null) {
            return ResponseEntity.notFound().build();
        }

        Resource file = storage.load(product.getImagePath());
        MediaType type = product.getImagePath().endsWith(".png") ? MediaType.IMAGE_PNG : MediaType.IMAGE_JPEG;

        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"%s\"".formatted(product.getImagePath()))
                .header("X-Content-Type-Options", "nosniff")
                .cacheControl(CacheControl.maxAge(Duration.ofDays(7)).cachePublic())
                .body(file);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    public void xoaAnh(@PathVariable Long id) {
        service.xoaAnh(id);
    }
}
