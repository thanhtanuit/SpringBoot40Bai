package com.example.shop.config;

import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

/**
 * Bài 30 — đa ngôn ngữ.
 *
 * MessageSource do Spring Boot tự tạo từ spring.messages.* (application.yml):
 *   encoding UTF-8               thiếu → tiếng Việt thành ký tự lỗi. Bug mất thời gian vô lý.
 *   use-code-as-default-message  quên dịch một key → trả về chính key thay vì ném lỗi. Xấu nhưng không sập.
 *   fallback-to-system-locale: false  không có → request "vi" trên máy JVM tiếng Anh nhận... tiếng Anh.
 *
 * AcceptHeaderLocaleResolver: đọc Accept-Language trình duyệt tự gửi. Mặc định vi.
 * Tên bean phải là "localeResolver".
 */
@Configuration
public class I18nConfig {

    public static final Locale VI = Locale.of("vi");

    @Bean
    public LocaleResolver localeResolver() {
        AcceptHeaderLocaleResolver resolver = new AcceptHeaderLocaleResolver();
        resolver.setDefaultLocale(VI);
        resolver.setSupportedLocales(List.of(VI, Locale.ENGLISH));
        return resolver;
    }

    /**
     * Validation dùng CHUNG MessageSource: message = "{product.name.notblank}" tra trong
     * messages*.properties theo locale của request. Quên dấu ngoặc nhọn → API trả nguyên văn key.
     *
     * Hai cơ chế chèn tham số nằm cạnh nhau, dễ nhầm:
     *   {min} {max}   Bean Validation — thay bằng giá trị trong annotation
     *   {0} {1}       MessageFormat của MessageSource — thay bằng args của BusinessException
     */
    @Bean
    public LocalValidatorFactoryBean validator(MessageSource messageSource) {
        LocalValidatorFactoryBean factory = new LocalValidatorFactoryBean();
        factory.setValidationMessageSource(messageSource);
        return factory;
    }
}
