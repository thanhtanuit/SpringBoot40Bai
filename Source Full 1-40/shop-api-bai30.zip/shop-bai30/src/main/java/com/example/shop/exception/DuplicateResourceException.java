package com.example.shop.exception;

/** 409 — DUPLICATE_NAME, DUPLICATE_SKU, DUPLICATE_USERNAME, DUPLICATE_EMAIL. */
public class DuplicateResourceException extends BusinessException {

    public DuplicateResourceException(ErrorCode code, Object value) {
        super(code, value);
    }
}
