package com.example.shop.service;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.config.JwtProperties;
import com.example.shop.dto.AuthResponse;
import com.example.shop.dto.LoginRequest;
import com.example.shop.dto.RegisterRequest;
import com.example.shop.dto.UserResponse;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ErrorCode;
import com.example.shop.exception.InvalidCredentialsException;
import com.example.shop.exception.InvalidTokenException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.RefreshToken;
import com.example.shop.model.Role;
import com.example.shop.model.User;
import com.example.shop.repository.UserRepository;
import com.example.shop.security.JwtService;
import com.example.shop.security.RefreshTokenService;

@Service
@Transactional
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository repo;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final UserDetailsService userDetailsService;
    private final JwtService jwtService;
    private final RefreshTokenService refreshTokenService;
    private final JwtProperties jwtProps;

    public AuthService(UserRepository repo, PasswordEncoder encoder, AuthenticationManager authManager,
                       UserDetailsService userDetailsService, JwtService jwtService,
                       RefreshTokenService refreshTokenService, JwtProperties jwtProps) {
        this.repo = repo;
        this.encoder = encoder;
        this.authManager = authManager;
        this.userDetailsService = userDetailsService;
        this.jwtService = jwtService;
        this.refreshTokenService = refreshTokenService;
        this.jwtProps = jwtProps;
    }

    public User dangKy(RegisterRequest req) {
        if (repo.existsByUsername(req.username())) {
            throw new DuplicateResourceException(ErrorCode.DUPLICATE_USERNAME, req.username());
        }
        if (repo.existsByEmail(req.email())) {
            throw new DuplicateResourceException(ErrorCode.DUPLICATE_EMAIL, req.email());
        }
        User daLuu = repo.save(new User(req.username(), encoder.encode(req.password()),
                req.email(), Set.of(Role.USER)));
        log.info("Đã đăng ký tài khoản id={} username={}", daLuu.getId(), daLuu.getUsername());
        return daLuu;
    }

    /**
     * Thông điệp lỗi GỘP CHUNG cho sai username lẫn sai mật khẩu — phân biệt là cho kẻ tấn công
     * biết username nào tồn tại (Bài 21).
     */
    public AuthResponse dangNhap(LoginRequest req) {
        Authentication auth;
        try {
            auth = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.username(), req.password()));
        } catch (BadCredentialsException | DisabledException e) {
            log.warn("Đăng nhập thất bại cho username={}", req.username());
            throw new InvalidCredentialsException();
        }

        UserDetails userDetails = (UserDetails) auth.getPrincipal();
        String access = jwtService.generateToken(userDetails);
        String refresh = refreshTokenService.taoMoi(req.username());

        log.info("Đăng nhập thành công: {}", req.username());
        return AuthResponse.of(access, refresh, jwtProps.accessTokenTtl().toSeconds());
    }

    /**
     * Xoay vòng: token cũ thu hồi, cấp cặp mới.
     * noRollbackFor: giữ lại việc thu hồi toàn bộ phiên khi phát hiện tái sử dụng.
     */
    @Transactional(noRollbackFor = InvalidTokenException.class)
    public AuthResponse lamMoi(String refreshToken) {
        RefreshToken rt = refreshTokenService.kiemTra(refreshToken);
        refreshTokenService.thuHoi(refreshToken);

        String username = rt.getUser().getUsername();
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        String accessMoi = jwtService.generateToken(userDetails);
        String refreshMoi = refreshTokenService.taoMoi(username);

        return AuthResponse.of(accessMoi, refreshMoi, jwtProps.accessTokenTtl().toSeconds());
    }

    /**
     * Đăng xuất = thu hồi refresh token. Access token hiện tại VẪN dùng được tới hết hạn (tối đa
     * 15 phút) — đánh đổi cốt lõi của stateless. Khẩn cấp: blacklist trong Redis (bớt stateless).
     */
    public void dangXuat(String refreshToken) {
        refreshTokenService.thuHoi(refreshToken);
    }

    @Transactional(readOnly = true)
    public UserResponse thongTinHienTai(String username) {
        User u = repo.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND, username));
        return new UserResponse(u.getId(), u.getUsername(), u.getEmail(),
                u.getRoles().stream().map(Enum::name).sorted().toList());
    }
}
