package com.example.shop.dto;

import com.example.shop.validation.ValidSku;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Bài 14 — body cho PATCH /api/products/{id}. MỌI trường tuỳ chọn: client chỉ gửi phần
 * muốn sửa. Không có @NotNull/@NotBlank, nhưng GỬI thì phải hợp lệ.
 * Thay cho PriceUpdateRequest — PATCH tổng quát bao trùm đổi giá.
 */
@Schema(description = "Cập nhật một phần — chỉ gửi trường muốn đổi")
public record UpdateProductRequest(

        @Size(min = 2, max = 100, message = "{product.name.size}")
        String name,

        @ValidSku
        String sku,

        @Schema(example = "990000")
        @Positive(message = "{product.price.positive}")
        Double price,

        @Min(value = 0, message = "{product.stock.min}")
        Integer stock
) {
}
