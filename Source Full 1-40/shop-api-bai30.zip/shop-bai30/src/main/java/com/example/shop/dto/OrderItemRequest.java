package com.example.shop.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record OrderItemRequest(

        @Schema(example = "1")
        @NotNull(message = "{order.item.product.notnull}")
        Long productId,

        @Schema(example = "2")
        @NotNull(message = "{order.item.quantity.notnull}")
        @Min(value = 1, message = "{order.item.quantity.min}")
        Integer quantity
) {
}
