package com.example.shop.exception;

/** 404 — mã cụ thể theo loại tài nguyên: PRODUCT_NOT_FOUND, ORDER_NOT_FOUND... */
public class ResourceNotFoundException extends BusinessException {

    public ResourceNotFoundException(ErrorCode code, Object id) {
        super(code, id);
    }
}
