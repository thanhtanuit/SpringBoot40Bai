package com.example.shop.web;

import java.util.Map;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Bài 19 — CHỈ ĐỂ HỌC: thống kê cache. Có số liệu Caffeine (profile "caffeine");
 * với Redis xem: docker compose exec redis redis-cli INFO stats
 */
@RestController
@Tag(name = "Dev")
@RequestMapping("/cache")
public class CacheController {

    private final CacheManager cacheManager;

    public CacheController(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @GetMapping("/stats")
    public Map<String, Object> thongKe() {
        Cache cache = cacheManager.getCache("products");
        if (cache instanceof CaffeineCache caffeine) {
            var stats = caffeine.getNativeCache().stats();
            return Map.of(
                    "loai", "caffeine",
                    "hitCount", stats.hitCount(),
                    "missCount", stats.missCount(),
                    "hitRate", "%.1f%%".formatted(stats.hitRate() * 100),
                    "evictionCount", stats.evictionCount());
        }
        return Map.of(
                "loai", cacheManager.getClass().getSimpleName(),
                "ghiChu", "Redis: docker compose exec redis redis-cli INFO stats");
    }
}
