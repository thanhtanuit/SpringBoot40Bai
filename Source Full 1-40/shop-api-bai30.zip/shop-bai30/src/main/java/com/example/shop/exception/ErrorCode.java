package com.example.shop.exception;

import org.springframework.http.HttpStatus;

/**
 * Bài 30 — MÃ LỖI ỔN ĐỊNH. Frontend xử lý theo MÃ, không theo chuỗi:
 *
 *   if (err.message === 'Không đủ hàng trong kho')   // SAI — vỡ khi sửa chính tả, không dịch được
 *   if (err.code === 'INSUFFICIENT_STOCK')           // ĐÚNG — mã là hợp đồng
 *
 * Thông điệp để NGƯỜI đọc, mã để MÁY xử lý.
 * Mỗi mã gắn sẵn HTTP status — không thể vô tình trả 404 ở endpoint này, 409 ở endpoint khác
 * cho cùng một lỗi.
 */
public enum ErrorCode {

    // 400
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST, "error.validation.failed"),
    MALFORMED_REQUEST(HttpStatus.BAD_REQUEST, "error.request.malformed"),
    INVALID_PARAMETER(HttpStatus.BAD_REQUEST, "error.request.invalid_parameter"),
    INVALID_SORT(HttpStatus.BAD_REQUEST, "error.request.invalid_sort"),
    INVALID_FILE(HttpStatus.BAD_REQUEST, "error.file.invalid"),

    // 401
    UNAUTHORIZED(HttpStatus.UNAUTHORIZED, "error.auth.unauthorized"),
    INVALID_CREDENTIALS(HttpStatus.UNAUTHORIZED, "error.auth.invalid_credentials"),
    TOKEN_EXPIRED(HttpStatus.UNAUTHORIZED, "error.auth.token_expired"),
    REFRESH_TOKEN_INVALID(HttpStatus.UNAUTHORIZED, "error.auth.refresh_invalid"),
    SESSION_REVOKED(HttpStatus.UNAUTHORIZED, "error.auth.session_revoked"),

    // 403
    FORBIDDEN(HttpStatus.FORBIDDEN, "error.auth.forbidden"),

    // 404 / 405
    PRODUCT_NOT_FOUND(HttpStatus.NOT_FOUND, "error.product.not_found"),
    DELETED_PRODUCT_NOT_FOUND(HttpStatus.NOT_FOUND, "error.product.deleted_not_found"),
    ORDER_NOT_FOUND(HttpStatus.NOT_FOUND, "error.order.not_found"),
    USER_NOT_FOUND(HttpStatus.NOT_FOUND, "error.user.not_found"),
    ENDPOINT_NOT_FOUND(HttpStatus.NOT_FOUND, "error.endpoint.not_found"),
    METHOD_NOT_ALLOWED(HttpStatus.METHOD_NOT_ALLOWED, "error.request.method_not_allowed"),

    // 409
    DUPLICATE_NAME(HttpStatus.CONFLICT, "error.product.duplicate_name"),
    DUPLICATE_SKU(HttpStatus.CONFLICT, "error.product.duplicate_sku"),
    DUPLICATE_USERNAME(HttpStatus.CONFLICT, "error.user.duplicate_username"),
    DUPLICATE_EMAIL(HttpStatus.CONFLICT, "error.user.duplicate_email"),
    INSUFFICIENT_STOCK(HttpStatus.CONFLICT, "error.order.insufficient_stock"),
    CONCURRENT_MODIFICATION(HttpStatus.CONFLICT, "error.concurrent_modification"),
    DATA_CONFLICT(HttpStatus.CONFLICT, "error.data_conflict"),

    // 413 / 429 / 500
    FILE_TOO_LARGE(HttpStatus.PAYLOAD_TOO_LARGE, "error.file.too_large"),
    RATE_LIMIT_EXCEEDED(HttpStatus.TOO_MANY_REQUESTS, "error.rate_limit"),
    INTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "error.internal");

    private final HttpStatus status;
    private final String messageKey;

    ErrorCode(HttpStatus status, String messageKey) {
        this.status = status;
        this.messageKey = messageKey;
    }

    public HttpStatus status() {
        return status;
    }

    public String messageKey() {
        return messageKey;
    }
}
