package com.example.shop.exception;

/** 401 — MỘT mã chung cho sai username lẫn sai mật khẩu (Bài 21). */
public class InvalidCredentialsException extends BusinessException {

    public InvalidCredentialsException() {
        super(ErrorCode.INVALID_CREDENTIALS);
    }
}
