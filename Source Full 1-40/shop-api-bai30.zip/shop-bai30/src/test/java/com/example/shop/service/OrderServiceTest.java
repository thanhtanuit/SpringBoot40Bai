package com.example.shop.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.OrderItemRequest;
import com.example.shop.exception.BusinessException;
import com.example.shop.exception.ErrorCode;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.metrics.OrderMetrics;
import com.example.shop.model.Order;
import com.example.shop.model.Product;
import com.example.shop.repository.AuditLogRepository;
import com.example.shop.repository.OrderRepository;
import com.example.shop.repository.ProductRepository;

/** Bài 25 — nơi có logic đáng test: tính tiền và trừ kho. */
@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService")
class OrderServiceTest {

    @Mock private OrderRepository orderRepo;
    @Mock private ProductRepository productRepo;
    @Mock private AuditLogRepository auditRepo;
    @Mock private AuditService auditService;
    @Mock private CacheManager cacheManager;
    @Mock private NotificationService notificationService;

    /**
     * Bài 29 — OrderMetrics KHÔNG mock: mock thì doThoiGian(...) trả null và KHÔNG chạy việc bên trong.
     * Dùng bản thật trên SimpleMeterRegistry (trong bộ nhớ) — kiểm được luôn số liệu.
     */
    private final SimpleMeterRegistry registry = new SimpleMeterRegistry();
    @Spy private OrderMetrics metrics = new OrderMetrics(registry);

    @InjectMocks
    private OrderService service;

    private Product banPhim;
    private Product chuot;

    @BeforeEach
    void setUp() {
        banPhim = new Product("Bàn phím", "BPH-0001", 1_000_000, 10);
        chuot = new Product("Chuột", "CHU-0001", 300_000, 5);
    }

    private static CreateOrderRequest don(String khach, OrderItemRequest... dong) {
        return new CreateOrderRequest(khach, List.of(dong));
    }

    @Nested
    @DisplayName("Đặt hàng")
    class DatHang {

        @Test
        void should_TinhDungTongTien_When_DonCoNhieuDong() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(productRepo.findById(2L)).thenReturn(Optional.of(chuot));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            Order ketQua = service.datHang(don("Nguyễn Văn A",
                    new OrderItemRequest(1L, 2),     // 2 × 1.000.000 = 2.000.000
                    new OrderItemRequest(2L, 3)));   // 3 ×   300.000 =   900.000

            assertThat(ketQua.getTotalAmount()).isEqualTo(2_900_000);
            assertThat(ketQua.getItems()).hasSize(2);
            assertThat(ketQua)
                    .extracting(Order::getCustomerName, Order::getTotalAmount)
                    .containsExactly("Nguyễn Văn A", 2_900_000.0);
        }

        @Test
        void should_TangMetric_When_DatHangThanhCong() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("A", new OrderItemRequest(1L, 2)));

            assertThat(registry.get("shop.orders.created").counter().count()).isEqualTo(1);
            assertThat(registry.get("shop.orders.amount").summary().totalAmount()).isEqualTo(2_000_000);
            assertThat(registry.get("shop.orders.duration").timer().count()).isEqualTo(1);
        }

        @Test
        void should_DemThatBaiTheoLyDo_When_KhongDuHang() {
            when(productRepo.findById(2L)).thenReturn(Optional.of(chuot));

            assertThatThrownBy(() -> service.datHang(don("A", new OrderItemRequest(2L, 99))))
                    .isInstanceOf(BusinessException.class);

            assertThat(registry.get("shop.orders.failed").tag("reason", "insufficient_stock")
                    .counter().count()).isEqualTo(1);
        }

        @Test
        void should_TruDungTonKho_When_DatHangThanhCong() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("A", new OrderItemRequest(1L, 3)));

            assertThat(banPhim.getStock()).isEqualTo(7);   // 10 − 3
        }

        @Test
        void should_ChotGiaLucMua_When_GiaDoiSauDo() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            Order ketQua = service.datHang(don("A", new OrderItemRequest(1L, 1)));
            banPhim.setPrice(9_999_999);   // tăng giá sau khi mua

            // Bài 9: unitPrice SAO CHÉP lúc mua, không tham chiếu
            assertThat(ketQua.getItems().get(0).getUnitPrice()).isEqualTo(1_000_000);
        }

        @Test
        void should_GuiThongBao_When_DatHangThanhCong() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("Nguyễn Văn A", new OrderItemRequest(1L, 1)));

            verify(notificationService).guiThongBaoDatHang(any(), eq("Nguyễn Văn A"));
            verify(auditService).ghi(eq("ATTEMPT"), eq("Order"), any(), anyString());
        }

        @Test
        void should_ThrowInsufficientStock_When_KhongDuHang() {
            when(productRepo.findById(2L)).thenReturn(Optional.of(chuot));

            // Bài 30: kiểm MÃ và THAM SỐ, không kiểm câu chữ (câu chữ giờ dịch theo ngôn ngữ)
            assertThatThrownBy(() -> service.datHang(don("A", new OrderItemRequest(2L, 99))))
                    .isInstanceOfSatisfying(BusinessException.class, e -> {
                        assertThat(e.getCode()).isEqualTo(ErrorCode.INSUFFICIENT_STOCK);
                        assertThat(e.getArgs()).containsExactly("Chuột", 5, 99);
                    });

            verify(orderRepo, never()).save(any());
            assertThat(chuot.getStock()).isEqualTo(5);   // kho KHÔNG bị trừ
        }

        @Test
        void should_ThrowNotFound_When_SanPhamKhongTonTai() {
            when(productRepo.findById(9999L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.datHang(don("A", new OrderItemRequest(9999L, 1))))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .extracting(e -> ((BusinessException) e).getCode())
                    .isEqualTo(ErrorCode.PRODUCT_NOT_FOUND);

            assertThat(registry.get("shop.orders.failed").tag("reason", "product_not_found")
                    .counter().count()).isEqualTo(1);
        }

        /**
         * GIỚI HẠN CỦA UNIT TEST: banPhim.getStock() lúc này là 8, KHÔNG phải 10 — service đã trừ
         * dòng đầu trước khi gặp lỗi dòng sau. Thực tế @Transactional rollback nên DB không đổi,
         * nhưng MOCKITO KHÔNG MÔ PHỎNG TRANSACTION.
         * Unit test kiểm được "save không bị gọi". Kiểm rollback thật cần DB thật — Bài 27.
         */
        @Test
        void should_KhongLuuDon_When_DongSauHetHang() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(productRepo.findById(2L)).thenReturn(Optional.of(chuot));

            assertThatThrownBy(() -> service.datHang(don("A",
                    new OrderItemRequest(1L, 2),      // hợp lệ
                    new OrderItemRequest(2L, 99))))   // hết hàng
                    .isInstanceOf(BusinessException.class);

            verify(orderRepo, never()).save(any());
            assertThat(banPhim.getStock()).isEqualTo(8);   // ← chỉ transaction thật mới trả về 10
        }

        @Test
        void should_KhongGhiAuditCreateVaKhongGuiThongBao_When_CongTacLoiBat() {
            when(productRepo.findById(1L)).thenReturn(Optional.of(banPhim));
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            assertThatThrownBy(() -> service.datHang(don("LOI khách", new OrderItemRequest(1L, 1))))
                    .isInstanceOf(RuntimeException.class);

            verify(auditRepo, never()).save(any());
            verify(notificationService, never()).guiThongBaoDatHang(any(), any());
        }
    }

    /**
     * Giá trị SÁT RANH GIỚI: 1.999.999 và 2.000.000, 4.999.999 và 5.000.000. Lỗi off-by-one
     * (">" thay vì ">=") chỉ lộ ra ở đúng những điểm này — test giữa khoảng không bắt được.
     * isCloseTo(..., within(0.01)) vì double có sai số.
     */
    @ParameterizedTest(name = "Tổng {0}đ → giảm {1}đ")
    @CsvSource({
            "  1000000,       0",
            "  1999999,       0",
            "  2000000,  100000",
            "  4999999,  249999.95",
            "  5000000,  500000",
            "  9999999,  999999.9",
            " 10000000, 1500000",
            " 20000000, 3000000"
    })
    void should_TinhDungGiamGia_TheoCacMuc(double tongTien, double giamGiaMongDoi) {
        assertThat(service.tinhGiamGia(tongTien)).isCloseTo(giamGiaMongDoi, within(0.01));
    }
}
