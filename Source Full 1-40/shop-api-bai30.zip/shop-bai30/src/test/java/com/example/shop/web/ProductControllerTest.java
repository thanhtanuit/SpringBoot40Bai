package com.example.shop.web;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.shop.config.I18nConfig;
import com.example.shop.config.SecurityConfig;
import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.ProductResponse;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ErrorCode;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.security.ApiErrorWriter;
import com.example.shop.security.JsonAccessDeniedHandler;
import com.example.shop.security.JsonAuthenticationEntryPoint;
import com.example.shop.security.JwtService;
import com.example.shop.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Bài 26 — hợp đồng HTTP. Bài 30: đổi ĐỊNH DẠNG mọi response — thay đổi rủi ro nhất từ đầu
 * bộ bài. Danh sách test đỏ sau khi đổi CHÍNH LÀ danh sách việc cần làm — không phải đoán.
 *
 *   $.name        → $.data.name
 *   $.title       → $.error.code
 *   /api/products → /api/v1/products
 *
 * @Import thêm I18nConfig (validator dùng MessageSource) và ApiErrorWriter (401/403).
 * ApiVersionConfig (WebMvcConfigurer) và ApiResponseWrapper (advice) slice tự nạp.
 */
@WebMvcTest(ProductController.class)
@Import({SecurityConfig.class, JsonAuthenticationEntryPoint.class, JsonAccessDeniedHandler.class,
         ApiErrorWriter.class, I18nConfig.class, ProductPresenter.class})
@ActiveProfiles("test")
@DisplayName("ProductController")
class ProductControllerTest {

    private static final String URL = "/api/v1/products";

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;

    @MockitoBean private ProductService service;
    @MockitoBean private ProductMapper mapper;
    @MockitoBean private JwtService jwtService;
    @MockitoBean private UserDetailsService userDetailsService;

    private static ProductResponse dto(Long id, String name, Double costPrice) {
        return new ProductResponse(id, name, "BPH-0001", 1_250_000, 15, "Bàn phím",
                Instant.now(), Instant.now(), costPrice);
    }

    private String json(Object o) throws Exception {
        return objectMapper.writeValueAsString(o);
    }

    @Nested
    @DisplayName("GET /api/v1/products/{id}")
    class LayTheoId {

        @Test
        void should_TraVe200VaBocTrongData_When_IdTonTai() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "Bàn phím cơ", 875_000.0));

            mockMvc.perform(get(URL + "/1"))
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                    .andExpect(jsonPath("$.success").value(true))
                    .andExpect(jsonPath("$.data.id").value(1))
                    .andExpect(jsonPath("$.data.name").value("Bàn phím cơ"))
                    .andExpect(jsonPath("$.data.price").value(1_250_000.0))
                    .andExpect(jsonPath("$.data.costPrice").doesNotExist())
                    .andExpect(jsonPath("$.error").doesNotExist())
                    .andExpect(jsonPath("$.timestamp").exists());
        }

        @Test
        @WithMockUser(roles = "ADMIN")
        void should_HienGiaVon_When_LaAdmin() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "Bàn phím cơ", 875_000.0));

            mockMvc.perform(get(URL + "/1"))
                    .andExpect(jsonPath("$.data.costPrice").value(875_000.0));
        }

        @Test
        void should_TraVe404VaMaLoi_When_KhongTimThay() throws Exception {
            when(service.findResponseById(9999L))
                    .thenThrow(new ResourceNotFoundException(ErrorCode.PRODUCT_NOT_FOUND, 9999L));

            mockMvc.perform(get(URL + "/9999"))
                    .andExpect(status().isNotFound())     // status VẪN ĐÚNG — không nói dối
                    .andExpect(jsonPath("$.success").value(false))
                    .andExpect(jsonPath("$.data").doesNotExist())
                    .andExpect(jsonPath("$.error.code").value("PRODUCT_NOT_FOUND"))
                    .andExpect(jsonPath("$.error.message").value(containsString("9999")))
                    .andExpect(jsonPath("$.error.path").value(URL + "/9999"));
        }

        /** Toàn bộ điểm của Bài 30: CÙNG code, KHÁC message. */
        @Test
        void should_TraVeCungMaLoi_KhacMessage_TheoAcceptLanguage() throws Exception {
            when(service.findResponseById(9999L))
                    .thenThrow(new ResourceNotFoundException(ErrorCode.PRODUCT_NOT_FOUND, 9999L));

            mockMvc.perform(get(URL + "/9999").header("Accept-Language", "vi"))
                    .andExpect(jsonPath("$.error.code").value("PRODUCT_NOT_FOUND"))
                    .andExpect(jsonPath("$.error.message").value(containsString("Không tìm thấy")));

            mockMvc.perform(get(URL + "/9999").header("Accept-Language", "en"))
                    .andExpect(jsonPath("$.error.code").value("PRODUCT_NOT_FOUND"))
                    .andExpect(jsonPath("$.error.message").value(containsString("not found")));
        }

        @Test
        void should_TraVe400_When_IdSaiKieu() throws Exception {
            mockMvc.perform(get(URL + "/abc"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.error.code").value("INVALID_PARAMETER"));
        }

        @Test
        void should_TraVe404_When_DuongDanKhongTonTai() throws Exception {
            mockMvc.perform(get("/api/v1/khong-ton-tai").with(user("x")))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.error.code").value("ENDPOINT_NOT_FOUND"));
        }
    }

    @Nested
    @DisplayName("POST /api/v1/products")
    class TaoSanPham {

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe201VaLocation_When_DuLieuHopLe() throws Exception {
            var req = new CreateProductRequest("Chuột", "CHU-0001", 350_000.0, 40);
            var product = new Product("Chuột", "CHU-0001", 350_000, 40);
            when(service.create(anyString(), anyString(), anyDouble(), any())).thenReturn(product);
            when(mapper.toResponse(product)).thenReturn(dto(5L, "Chuột", null));

            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(json(req)))
                    .andExpect(status().isCreated())
                    .andExpect(header().string("Location", containsString("/api/v1/products/")))
                    .andExpect(jsonPath("$.data.id").value(5));
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe400VaFieldErrorsTiengViet_When_DuLieuSai() throws Exception {
            String body = """
                    { "name": "A", "sku": "sai-dinh-dang", "price": -5, "stock": -1 }
                    """;

            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(body)
                            .header("Accept-Language", "vi"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.error.code").value("VALIDATION_FAILED"))
                    .andExpect(jsonPath("$.error.message").value("Dữ liệu gửi lên không hợp lệ"))
                    .andExpect(jsonPath("$.error.fieldErrors.name").value("Tên sản phẩm phải từ 2 đến 100 ký tự"))
                    .andExpect(jsonPath("$.error.fieldErrors.sku").value("SKU phải có dạng ABC-1234"))
                    .andExpect(jsonPath("$.error.fieldErrors.price").value("Giá phải lớn hơn 0"))
                    .andExpect(jsonPath("$.error.fieldErrors.stock").exists());

            verify(service, never()).create(any(), any(), anyDouble(), any());
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVeFieldErrorsTiengAnh_When_AcceptLanguageEn() throws Exception {
            String body = """
                    { "name": "A", "sku": "sai", "price": -5 }
                    """;

            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(body)
                            .header("Accept-Language", "en"))
                    .andExpect(jsonPath("$.error.code").value("VALIDATION_FAILED"))
                    .andExpect(jsonPath("$.error.message").value("The submitted data is invalid"))
                    .andExpect(jsonPath("$.error.fieldErrors.name").value("Product name must be between 2 and 100 characters"))
                    .andExpect(jsonPath("$.error.fieldErrors.price").value("Price must be greater than zero"));
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe400_When_BodyHong() throws Exception {
            String bodyHong = """
                    { "name": "X", "sku": "XXX-0001", "price": "khong-phai-so" }
                    """;

            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(bodyHong))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.error.code").value("MALFORMED_REQUEST"))
                    .andExpect(jsonPath("$.error.message").value(not(containsString("java"))));
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe409_When_TenTrung() throws Exception {
            when(service.create(anyString(), anyString(), anyDouble(), any()))
                    .thenThrow(new DuplicateResourceException(ErrorCode.DUPLICATE_NAME, "Chuột"));

            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON)
                            .content(json(new CreateProductRequest("Chuột", "CHU-0001", 350_000.0, 40))))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.error.code").value("DUPLICATE_NAME"))
                    .andExpect(jsonPath("$.error.message").value(containsString("Chuột")));
        }
    }

    @Nested
    @DisplayName("Phân quyền")
    class PhanQuyen {

        private final CreateProductRequest req = new CreateProductRequest("X", "XXX-0001", 1000.0, 1);

        @Test
        void should_TraVe401ApiResponse_When_POSTKhongDangNhap() throws Exception {
            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(json(req)))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.success").value(false))
                    .andExpect(jsonPath("$.error.code").value("UNAUTHORIZED"));
        }

        @Test
        @WithMockUser(roles = "USER")
        void should_TraVe403ApiResponse_When_USERGoiPOST() throws Exception {
            mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(json(req)))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.error.code").value("FORBIDDEN"));

            verify(service, never()).create(any(), any(), anyDouble(), any());
        }

        @Test
        @WithMockUser(roles = "USER")
        void should_TraVe403_When_USERGoiPATCH() throws Exception {
            mockMvc.perform(patch(URL + "/1").contentType(MediaType.APPLICATION_JSON).content("{ \"price\": 1 }"))
                    .andExpect(status().isForbidden());
        }

        @ParameterizedTest(name = "{0} gọi DELETE → {1}")
        @CsvSource({
                "USER,   403",
                "SELLER, 403",
                "ADMIN,  204"
        })
        void should_PhanQuyenDung_When_GoiDELETE(String role, int ma) throws Exception {
            mockMvc.perform(delete(URL + "/1").with(user("test").roles(role)))
                    .andExpect(status().is(ma));
        }

        @ParameterizedTest(name = "{0} gọi POST → {1}")
        @CsvSource({
                "USER,   403",
                "SELLER, 201",
                "ADMIN,  201"
        })
        void should_PhanQuyenDung_When_GoiPOST(String role, int ma) throws Exception {
            var product = new Product("X", "XXX-0001", 1000, 1);
            when(service.create(anyString(), anyString(), anyDouble(), any())).thenReturn(product);
            when(mapper.toResponse(any())).thenReturn(dto(9L, "X", null));

            mockMvc.perform(post(URL).with(user("test").roles(role))
                            .contentType(MediaType.APPLICATION_JSON).content(json(req)))
                    .andExpect(status().is(ma));
        }
    }
}
