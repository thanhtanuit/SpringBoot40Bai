# shop-api — trạng thái sau Bài 30: Chuẩn hoá response và đa ngôn ngữ (hết Phần 3)

## Chạy

```bash
docker compose up -d
mvn spring-boot:run
cd shop-ui && npm install && npm run dev
```

## Định dạng response

```json
{ "success": true, "data": { "id": 1, "name": "Bàn phím cơ" }, "timestamp": "..." }
```

```json
{
  "success": false,
  "error": {
    "code": "INSUFFICIENT_STOCK",
    "message": "Không đủ hàng cho \"Chuột\": còn 5, cần 99",
    "path": "/api/v1/orders"
  },
  "timestamp": "..."
}
```

HTTP status **vẫn đúng** (409, 404, 401...). Bọc body là một chuyện, nói dối về status là chuyện khác.

## Thay đổi so với Bài 29

| | |
|---|---|
| `exception/ErrorCode.java` | Mã lỗi ổn định, mỗi mã gắn sẵn HTTP status + khoá thông điệp |
| `exception/BusinessException.java` | Gốc của mọi lỗi nghiệp vụ, mang `ErrorCode` + tham số |
| `ResourceNotFound`, `Duplicate`, `InvalidCredentials`, `InvalidToken`, `InvalidFile` | Kế thừa `BusinessException` |
| `OrderService` | `IllegalStateException` → `BusinessException(INSUFFICIENT_STOCK, tên, còn, cần)`; metric `reason` = mã lỗi |
| `GlobalExceptionHandler` | Viết lại — mọi lỗi qua `ErrorCode`, dịch theo locale; + 404 đường dẫn, 405 |
| `dto/ApiResponse`, `ApiError` | Định dạng thống nhất |
| `web/ApiResponseWrapper` | `ResponseBodyAdvice` bọc tự động, chỉ khi converter là Jackson |
| `security/ApiErrorWriter` | 401/403 từ filter chain cùng định dạng |
| `config/I18nConfig` | `AcceptHeaderLocaleResolver` (vi mặc định, en), validator dùng chung `MessageSource` |
| `messages.properties`, `messages_en.properties` | Thông điệp lỗi + validation |
| DTO | `message = "{product.name.notblank}"` — khoá, không phải câu |
| `config/ApiVersionConfig` | Tiền tố `/api/v1` cho mọi controller trong `web` (trừ `HelloController`) |
| Controller | `@RequestMapping("/products")` thay `"/api/products"` |
| Test | Đổi `$.name` → `$.data.name`, `$.title` → `$.error.code`, thêm test i18n |
| `shop-ui` | `baseURL /api/v1`, interceptor bóc lớp `data`, rẽ nhánh theo `error.code` |

## Frontend xử lý theo mã

```javascript
if (err.code === 'INSUFFICIENT_STOCK') moGiaoDienChonSoLuong()
if (err.code === 'TOKEN_EXPIRED')      thuRefreshToken()
if (err.code === 'DUPLICATE_SKU')      highlightOSku()
```

## Bẫy

| Bẫy | |
|---|---|
| Thiếu `encoding: UTF-8` | Tiếng Việt thành ký tự lỗi |
| `fallback-to-system-locale` mặc định `true` | Request `vi` trên máy JVM tiếng Anh nhận tiếng Anh |
| Quên `{ }` quanh khoá validation | API trả nguyên văn `product.name.notblank` |
| `{min}` với `{0}` | Hai cơ chế chèn tham số khác nhau nằm cạnh nhau |
| Bọc `String` | `ClassCastException` — wrapper chỉ bọc khi converter là Jackson |
| `@RequestMapping("/api/products")` + tiền tố `/api/v1` | Thành `/api/v1/api/products` |
| Luôn trả 200 kèm `success: false` | Mọi công cụ giám sát báo "không lỗi" |

## Tranh luận với chính mình

**Ủng hộ `ApiResponse`:** một hình dạng duy nhất cho frontend; chỗ đặt metadata chung.

**Phản đối:** lặp lại thông tin HTTP đã có; `ProblemDetail` là **chuẩn** (RFC 9457); thêm tầng
lồng — `res.data.data.items`.

**Thực dụng:** API chủ yếu phục vụ web/mobile của chính mình → `ProblemDetail` cho lỗi, DTO thẳng
cho thành công, `code` trong trường mở rộng của ProblemDetail. Được mã ổn định **và** chuẩn mở.

Viết kết luận của bạn vào Notion — biết mình đang đánh đổi cái gì.

## Hết Phần 3

JWT xoay vòng · phân quyền theo vai trò và sở hữu · CORS · ba tầng test · OpenAPI · health
liveness/readiness · metric nghiệp vụ · response thống nhất, mã lỗi ổn định, đa ngôn ngữ.

Bài 31: package by feature — và bộ test Phần 3 phải xanh hết sau khi di chuyển.
