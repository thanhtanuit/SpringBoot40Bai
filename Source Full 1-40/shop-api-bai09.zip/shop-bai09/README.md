# shop-api — trạng thái sau Bài 9: Quan hệ giữa các bảng

## Chạy

```bash
mvn spring-boot:run
```

`data.sql` tạo 3 danh mục, 5 sản phẩm. Phần "Bài 9" trong `requests.http` đặt hàng
và thử các trường hợp lỗi. H2 console: http://localhost:8081/h2-console
(JDBC URL `jdbc:h2:mem:shopdb`).

## Mô hình dữ liệu

```
category 1 ──── n product 1 ──── n order_item n ──── 1 orders
```

## Cấu trúc mới

```
model/
├── Category.java       độc lập, KHÔNG cascade từ Product
├── Product.java        + @ManyToOne(fetch = LAZY) category
├── Order.java          @Table("orders"), @OneToMany(mappedBy, cascade ALL, orphanRemoval), addItem()
└── OrderItem.java      phía chủ, chốt unitPrice lúc mua
repository/
├── CategoryRepository.java
└── OrderRepository.java          findByIdWithItems — JOIN FETCH
dto/
├── CreateOrderRequest.java       @NotEmpty @Valid List
├── OrderItemRequest.java
├── OrderResponse.java            phẳng, không tham chiếu vòng
├── OrderItemResponse.java
└── OrderMapper.java
service/OrderService.java         trừ kho (dirty checking), một lần save
web/OrderController.java          kèm hai thí nghiệm "cố tình sai" trong comment
exception/GlobalExceptionHandler  + IllegalStateException → 409
```

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| `@ManyToOne` mặc định EAGER | Luôn viết `fetch = LAZY` |
| Quên set hai chiều → `order_id` NULL | Luôn đi qua `addItem()` |
| Trả entity ra API | Vòng lặp vô tận hoặc `LazyInitializationException` — dùng DTO |

## Hai thí nghiệm cố tình sai

Xem comment cuối `OrderController`:

1. Endpoint `/raw` trả thẳng `Order` → `StackOverflowError`.
2. Bỏ `JOIN FETCH` → `LazyInitializationException: no Session`.

Tự tay gây ra, đọc kỹ thông báo, rồi trả về như cũ.

Đếm số câu SELECT khi gọi `GET /api/orders/1` có và không có `JOIN FETCH` — Bài 10 cần.
