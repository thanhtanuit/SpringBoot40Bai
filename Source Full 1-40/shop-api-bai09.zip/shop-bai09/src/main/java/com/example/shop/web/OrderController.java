package com.example.shop.web;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.OrderMapper;
import com.example.shop.dto.OrderResponse;
import com.example.shop.model.Order;
import com.example.shop.service.OrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrderResponse> create(@Valid @RequestBody CreateOrderRequest req) {
        Order moi = service.datHang(req);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.getId())
                .toUri();
        return ResponseEntity.created(location).body(OrderMapper.toResponse(moi));
    }

    @GetMapping("/{id}")
    public OrderResponse findById(@PathVariable Long id) {
        return OrderMapper.toResponse(service.findById(id));
    }

    /*
     * ===== THÍ NGHIỆM 1 — CỐ TÌNH SAI: trả thẳng entity =====
     * Bỏ comment, gọi GET /api/orders/1/raw → 500, log: Infinite recursion (StackOverflowError)
     *   Order["items"] → OrderItem["order"] → Order["items"] → ...
     * @JsonIgnore chỉ vá triệu chứng và bắt entity biết chuyện JSON. Cách đúng: DTO.
     * Quan sát xong XOÁ đi.
     *
     * @GetMapping("/{id}/raw")
     * public Order raw(@PathVariable Long id) {
     *     return service.findById(id);
     * }
     *
     * ===== THÍ NGHIỆM 2 — LazyInitializationException =====
     * Trong OrderService.findById đổi orderRepo.findByIdWithItems(id) thành orderRepo.findById(id).
     * Gọi GET /api/orders/1 → could not initialize proxy - no Session.
     * items là proxy LAZY; mapper chạm vào khi giao dịch đã đóng. open-in-view: false (Bài 8)
     * làm lỗi hiện ra — bật nó thì lỗi biến mất nhưng thành N+1 âm thầm. Trả lại như cũ.
     */
}
