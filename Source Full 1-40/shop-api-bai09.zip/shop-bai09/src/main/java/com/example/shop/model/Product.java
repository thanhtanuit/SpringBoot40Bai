package com.example.shop.model;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Bài 8: record → CLASS. Entity KHÔNG THỂ là record:
 *  1. JPA cần constructor rỗng để dựng object rồi mới đổ dữ liệu vào
 *  2. JPA cần gán được vào field — record bất biến
 *  3. Hibernate cần tạo proxy KẾ THỪA class cho nạp trễ — record là final
 *
 * Lằn ranh cả khoá: ENTITY thay đổi được · DTO bất biến.
 * DTO của Bài 4 vẫn là record — đừng đổi theo.
 */
@Entity
@Table(name = "product",
       uniqueConstraints = @UniqueConstraint(name = "uk_product_name", columnNames = "name"))
public class Product {

    /** IDENTITY: cột tự tăng của database. Giá trị chỉ có SAU khi INSERT chạy. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false)
    private double price;

    @Column(nullable = false)
    private int stock;

    /**
     * Bài 9 — BẪY 1: @ManyToOne mặc định là EAGER. fetch = LAZY phải VIẾT RA TAY.
     * EAGER: nạp Product là nạp luôn Category, rồi Category nạp tiếp... một findAll
     * đơn giản thành hàng chục JOIN. Quy tắc: mọi quan hệ để LAZY, khi cần thì nạp
     * CÓ CHỦ ĐÍCH bằng JOIN FETCH hoặc @EntityGraph.
     *
     * Phía "nhiều" giữ khoá ngoại: cột category_id nằm ở bảng product.
     * KHÔNG cascade — xoá sản phẩm không được kéo theo danh mục.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    /** protected: "cái này dành cho JPA, không phải cho bạn" — vẫn đủ quyền tạo proxy. */
    protected Product() {
    }

    /** Không nhận id — database cấp id, không phải code. */
    public Product(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    @PrePersist
    void prePersist() {
        this.createdAt = Instant.now();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
