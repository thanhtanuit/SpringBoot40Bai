package com.example.shop.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.OrderItemRequest;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Order;
import com.example.shop.model.OrderItem;
import com.example.shop.model.Product;
import com.example.shop.repository.OrderRepository;
import com.example.shop.repository.ProductRepository;

@Service
@Transactional
public class OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepo;
    private final ProductRepository productRepo;

    public OrderService(OrderRepository orderRepo, ProductRepository productRepo) {
        this.orderRepo = orderRepo;
        this.productRepo = productRepo;
    }

    /**
     * Bật show-sql rồi đếm: 1 INSERT orders + n INSERT order_item + các UPDATE product.
     * Không có dòng nào nói "lưu OrderItem" — cascade lo.
     */
    public Order datHang(CreateOrderRequest req) {
        log.debug("Yêu cầu đặt hàng khách={} số dòng={}", req.customerName(), req.items().size());
        Order order = new Order(req.customerName());

        for (OrderItemRequest dong : req.items()) {
            Product p = productRepo.findById(dong.productId())
                    .orElseThrow(() -> new ResourceNotFoundException("Sản phẩm", dong.productId()));

            if (p.getStock() < dong.quantity()) {
                // → 409 Conflict (GlobalExceptionHandler)
                throw new IllegalStateException("Không đủ hàng cho '" + p.getName()
                        + "': còn " + p.getStock() + ", cần " + dong.quantity());
            }

            p.setStock(p.getStock() - dong.quantity());   // dirty checking — không save
            order.addItem(new OrderItem(p, dong.quantity()));
        }

        order.tinhTongTien();
        Order daLuu = orderRepo.save(order);              // MỘT lần save, cascade lo phần còn lại
        log.info("Đã tạo đơn hàng id={} tổng={}", daLuu.getId(), daLuu.getTotalAmount());
        return daLuu;
    }

    @Transactional(readOnly = true)
    public Order findById(Long id) {
        return orderRepo.findByIdWithItems(id)
                .orElseThrow(() -> new ResourceNotFoundException("Đơn hàng", id));
    }
}
