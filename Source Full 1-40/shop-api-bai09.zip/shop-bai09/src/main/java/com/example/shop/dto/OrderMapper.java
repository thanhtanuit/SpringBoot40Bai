package com.example.shop.dto;

import com.example.shop.model.Order;
import com.example.shop.model.OrderItem;

/**
 * Viết tay như ProductMapper — Bài 14 thay bằng MapStruct.
 *
 * Chạm item.getProduct().getName(): product là LAZY. Nếu chưa nạp và phiên đã đóng
 * → LazyInitializationException. Mapper không đổi luật chơi của JPA —
 * findByIdWithItems với JOIN FETCH lo phần nạp.
 */
public final class OrderMapper {

    private OrderMapper() {
    }

    public static OrderResponse toResponse(Order o) {
        return new OrderResponse(
                o.getId(),
                o.getCustomerName(),
                o.getTotalAmount(),
                o.getCreatedAt(),
                o.getItems().stream().map(OrderMapper::toItemResponse).toList());
    }

    public static OrderItemResponse toItemResponse(OrderItem i) {
        return new OrderItemResponse(
                i.getProduct().getId(),
                i.getProduct().getName(),
                i.getUnitPrice(),
                i.getQuantity(),
                i.getLineTotal());
    }
}
