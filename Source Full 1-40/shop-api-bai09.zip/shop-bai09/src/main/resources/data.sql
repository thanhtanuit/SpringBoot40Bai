-- Bài 9: danh mục trước, sản phẩm sau (khoá ngoại category_id).
INSERT INTO category (name) VALUES ('Bàn phím');
INSERT INTO category (name) VALUES ('Chuột');
INSERT INTO category (name) VALUES ('Âm thanh & hình ảnh');

INSERT INTO product (name, price, stock, category_id, created_at) VALUES ('Bàn phím cơ',       1250000, 10, 1, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, category_id, created_at) VALUES ('Chuột không dây',    350000, 25, 2, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, category_id, created_at) VALUES ('Tai nghe chụp tai',  890000,  8, 3, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, category_id, created_at) VALUES ('Màn hình 27 inch',  4500000,  4, 3, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, category_id, created_at) VALUES ('Webcam Full HD',     650000, 15, 3, CURRENT_TIMESTAMP);
