# shop-api — trạng thái sau Bài 14: Mapping Entity ↔ DTO với MapStruct

> Bài 4: *"code này nhàm chán, và mình cố tình để nó nhàm chán như vậy"*.
> Hôm nay xoá nó, đổi lấy code máy sinh ra **lúc biên dịch**.

## Chạy

```bash
docker compose up -d
mvn clean spring-boot:run
```

**Đọc code sinh ra** — so với `ProductMapper` viết tay ở Bài 4:

```
target/generated-sources/annotations/com/example/shop/mapper/ProductMapperImpl.java
target/generated-sources/annotations/com/example/shop/mapper/OrderMapperImpl.java
```

## Thay đổi so với Bài 13

| | |
|---|---|
| `pom.xml` | `mapstruct` + `mapstruct-processor` trong `annotationProcessorPaths`, `unmappedTargetPolicy=ERROR` |
| `dto/ProductMapper.java`, `dto/OrderMapper.java` | **Xoá** |
| `mapper/ProductMapper.java`, `mapper/OrderMapper.java` | **Interface** `@Mapper` |
| `dto/PriceUpdateRequest.java` | **Xoá** — thay bằng `UpdateProductRequest` |
| `PATCH /api/products/{id}/price` | **Xoá** — thay bằng `PATCH /api/products/{id}` tổng quát |
| Controller | Mapper tiêm qua constructor |

## Thí nghiệm

1. Xoá `@Mapping(target = "category", ignore = true)` trong `ProductMapper`, build →
   `Unmapped target property: "category"`. Hoàn tác.
2. Thêm trường `String note` vào `ProductResponse`, build → lỗi tương tự. Với mặc định
   `WARN`, client sẽ nhận `"note": null` mà không ai biết.
3. Xoá `mapstruct-processor` khỏi `annotationProcessorPaths` → biên dịch được, nhưng app
   chết lúc boot vì không có bean `ProductMapper`.

## Ba điều đọng lại

1. MapStruct sinh code **lúc biên dịch** — nhanh như viết tay, sai là build đỏ.
2. `unmappedTargetPolicy=ERROR` biến **quên map** thành **lỗi build**.
3. `@MappingTarget` + `IGNORE` là công thức chuẩn cho **PATCH**.

## Ba cái bẫy

| Bẫy | Hậu quả |
|---|---|
| Để mặc định `WARN` | Field null lọt ra ngoài im lặng |
| Mapper chạm quan hệ lazy ngoài phiên | `LazyInitializationException` như Bài 9 |
| Lombok sai thứ tự processor | "Unknown property" — không nhắc gì tới thứ tự |
