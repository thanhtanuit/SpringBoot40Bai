package com.example.shop.dto;

/**
 * Bài 10 thêm categoryName. Chạm product.getCategory().getName() khi category là LAZY
 * và phiên đã đóng → LazyInitializationException. Repository nạp sẵn bằng @EntityGraph.
 */
public record ProductResponse(Long id, String name, String sku, double price, int stock, String categoryName) {
}
