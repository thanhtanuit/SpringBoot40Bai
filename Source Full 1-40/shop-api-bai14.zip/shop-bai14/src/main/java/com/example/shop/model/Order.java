package com.example.shop.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

/**
 * Đơn hàng.
 *
 * Tên bảng "orders", KHÔNG phải "order" — ORDER là từ khoá SQL (ORDER BY),
 * đặt vậy là lỗi cú pháp rất khó hiểu lúc chạy.
 */
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String customerName;

    @Column(nullable = false)
    private double totalAmount;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    /**
     * mappedBy = "order": phía OrderItem.order mới là CHỦ quan hệ, tôi chỉ soi gương.
     * Thiếu mappedBy → Hibernate hiểu là hai quan hệ độc lập và TỰ TẠO BẢNG TRUNG GIAN.
     * Không báo lỗi gì.
     *
     * cascade ALL + orphanRemoval: CHỈ dùng khi quan hệ là SỞ HỮU.
     * Câu hỏi tự kiểm tra: "xoá cái cha thì cái con còn ý nghĩa gì không?"
     * Dòng hàng không thuộc đơn nào thì vô nghĩa → được cascade.
     */
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();

    protected Order() {
    }

    public Order(String customerName) {
        this.customerName = customerName;
    }

    @PrePersist
    void prePersist() {
        this.createdAt = Instant.now();
    }

    /**
     * BẪY 2: quan hệ hai chiều — Java KHÔNG tự đồng bộ hai đầu.
     * Chỉ items.add(item) mà quên item.setOrder(this): phía Java trông đúng hoàn toàn,
     * nhưng Hibernate nhìn PHÍA CHỦ (item.order = null) → order_id ghi NULL → lỗi ràng buộc
     * không nhắc gì tới setOrder. Luôn đi qua phương thức tiện ích này.
     */
    public void addItem(OrderItem item) {
        items.add(item);
        item.setOrder(this);
    }

    public void tinhTongTien() {
        this.totalAmount = items.stream().mapToDouble(OrderItem::getLineTotal).sum();
    }

    public Long getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    /** Chỉ đọc — không cho thao tác trực tiếp lên danh sách từ bên ngoài. */
    public List<OrderItem> getItems() {
        return Collections.unmodifiableList(items);
    }
}
