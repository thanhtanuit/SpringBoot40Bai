package com.example.shop.web;

import java.net.URI;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.shop.config.ShopProperties;
import com.example.shop.dto.BestSellerResponse;
import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.PageResponse;
import com.example.shop.dto.ProductResponse;
import com.example.shop.dto.SliceResponse;
import com.example.shop.dto.UpdateProductRequest;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;
    private final ShopProperties props;
    private final ProductMapper mapper;

    /**
     * Bài 14: mapper giờ là BEAN — tiêm qua constructor (Bài 3), không còn method tĩnh.
     * Lần thứ tư thay ruột mà hợp đồng không đổi: Bài 3 tầng, Bài 8 JPA,
     * Bài 11 Postgres, Bài 14 cách chuyển đổi.
     */
    public ProductController(ProductService service, ShopProperties props, ProductMapper mapper) {
        this.service = service;
        this.props = props;
        this.mapper = mapper;
    }

    /**
     * Chỉ khai Pageable — Spring tự dựng từ ?page=&size=&sort=.
     * Sắp xếp nhiều cấp: ?sort=price,desc&sort=name,asc
     */
    @GetMapping
    public PageResponse<ProductResponse> findAll(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return PageResponse.from(service.findAll(chuanHoa(pageable)), mapper::toResponse);
    }

    /** Cuộn vô hạn — Slice, một câu SQL. So log với GET /api/products. */
    @GetMapping("/scroll")
    public SliceResponse<ProductResponse> scroll(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return SliceResponse.from(service.scroll(chuanHoa(pageable)), mapper::toResponse);
    }

    /** Bốn bộ lọc, tất cả tuỳ chọn. */
    @GetMapping("/search")
    public PageResponse<ProductResponse> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) Long categoryId,
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {
        return PageResponse.from(
                service.search(keyword, minPrice, maxPrice, categoryId, chuanHoa(pageable)),
                mapper::toResponse);
    }

    @GetMapping("/best-sellers")
    public List<BestSellerResponse> bestSellers(@RequestParam(defaultValue = "5") int limit) {
        return service.bestSellers(Math.min(Math.max(limit, 1), props.maxItemsPerPage()));
    }

    @GetMapping("/{id}")
    public ProductResponse findById(@PathVariable Long id) {
        return mapper.toResponse(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody CreateProductRequest req) {
        Product moi = service.create(req.name(), req.sku(), req.price(), req.stock());
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.getId())
                .toUri();
        return ResponseEntity.created(location).body(mapper.toResponse(moi));
    }

    @PutMapping("/{id}")
    public ProductResponse update(@PathVariable Long id, @Valid @RequestBody CreateProductRequest req) {
        return mapper.toResponse(service.update(id, req.name(), req.sku(), req.price(), req.stock()));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    /** Bài 14: PATCH tổng quát — thay endpoint /{id}/price của Bài 2. */
    @PatchMapping("/{id}")
    public ProductResponse patch(@PathVariable Long id, @Valid @RequestBody UpdateProductRequest req) {
        return mapper.toResponse(service.patch(id, req));
    }

    /**
     * BẪY 1: không chặn trần size → ?size=1000000 nạp cả bảng vào RAM, một request hạ server.
     * Không cần là tấn công — chỉ cần frontend "lấy hết cho tiện".
     * Trần lấy từ shop.max-items-per-page của Bài 6 — giá trị đó cuối cùng cũng có việc.
     * (spring.data.web.pageable.max-page-size trong application.yml là lưới an toàn thứ hai.)
     */
    private Pageable chuanHoa(Pageable p) {
        int max = props.maxItemsPerPage();
        if (p.getPageSize() <= max) {
            return p;
        }
        return PageRequest.of(p.getPageNumber(), max, p.getSort());
    }
}
