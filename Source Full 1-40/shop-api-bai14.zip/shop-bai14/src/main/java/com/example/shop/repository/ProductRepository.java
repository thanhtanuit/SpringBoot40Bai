package com.example.shop.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.shop.model.Product;

/**
 * Bài 10 — ba bậc viết truy vấn:
 *   1–2 điều kiện cố định          → derived query (tên method)
 *   phức tạp hơn nhưng vẫn cố định → @Query
 *   số điều kiện đổi theo request  → Specification (Bài 15)
 *
 * @EntityGraph(attributePaths = "category"): nạp luôn danh mục bằng LEFT JOIN trong
 * câu chính, thay vì LAZY rồi bắn thêm một truy vấn cho TỪNG sản phẩm (N+1).
 * Lấy 5 sản phẩm: KHÔNG có → 7 câu SQL (1 dữ liệu + 1 count + 5 category)
 *                 CÓ       → 2 câu SQL
 * An toàn với @ManyToOne. Với @OneToMany + phân trang → "applying in memory" (Bài 39).
 */
public interface ProductRepository extends JpaRepository<Product, Long> {

    // ===== Bài 8 =====
    boolean existsByNameIgnoreCase(String name);

    boolean existsByNameIgnoreCaseAndIdNot(String name, Long id);

    // ===== Bài 12 =====
    boolean existsBySku(String sku);

    boolean existsBySkuAndIdNot(String sku, Long id);

    // ===== Bài 10: @EntityGraph đè lên method có sẵn, không phải viết JPQL =====
    @Override
    @EntityGraph(attributePaths = "category")
    Page<Product> findAll(Pageable pageable);

    @Override
    @EntityGraph(attributePaths = "category")
    Optional<Product> findById(Long id);

    /** Slice: lấy size + 1 bản ghi để biết còn trang sau — BỎ HẲN câu count. */
    @EntityGraph(attributePaths = "category")
    Slice<Product> findSliceBy(Pageable pageable);

    // ===== Bài 10: derived query — gọi thử rồi ĐỌC SQL trong log =====

    /** LOWER(name) LIKE LOWER('%?%') */
    @EntityGraph(attributePaths = "category")
    List<Product> findByNameContainingIgnoreCase(String keyword);

    /** price BETWEEN ? AND ? */
    @EntityGraph(attributePaths = "category")
    List<Product> findByPriceBetween(double min, double max);

    @EntityGraph(attributePaths = "category")
    List<Product> findByCategoryId(Long categoryId);

    /** SELECT COUNT(*) ... WHERE category_id = ? */
    long countByCategoryId(Long categoryId);

    /*
     * Giới hạn của derived query — đừng làm thế này:
     *   findByNameContainingIgnoreCaseAndPriceBetweenAndCategoryIdAndStockGreaterThanOrderByPriceDesc
     */

    // ===== Bài 10: tìm kiếm với bốn bộ lọc TUỲ CHỌN =====

    /**
     * Mẹo "tham số IS NULL OR điều kiện": một câu phục vụ cả 16 tổ hợp.
     *
     * JOIN FETCH + phân trang → PHẢI có countQuery riêng, KHÔNG có JOIN FETCH.
     *
     * KHÔNG ĐẸP, cố tình để lại:
     *  - bốn điều kiện viết HAI lần (câu chính + câu đếm)
     *  - điều kiện luôn có mặt trong SQL dù tham số null → DB thường không dùng được index
     * Bài 15 (Specification): bộ lọc không gửi thì BIẾN MẤT hẳn khỏi câu SQL.
     */
    @Query(value = """
            SELECT p FROM Product p LEFT JOIN FETCH p.category c
            WHERE (:keyword IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')))
              AND (:minPrice IS NULL OR p.price >= :minPrice)
              AND (:maxPrice IS NULL OR p.price <= :maxPrice)
              AND (:categoryId IS NULL OR c.id = :categoryId)
            """,
           countQuery = """
            SELECT COUNT(p) FROM Product p LEFT JOIN p.category c
            WHERE (:keyword IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')))
              AND (:minPrice IS NULL OR p.price >= :minPrice)
              AND (:maxPrice IS NULL OR p.price <= :maxPrice)
              AND (:categoryId IS NULL OR c.id = :categoryId)
            """)
    Page<Product> search(@Param("keyword") String keyword,
                         @Param("minPrice") Double minPrice,
                         @Param("maxPrice") Double maxPrice,
                         @Param("categoryId") Long categoryId,
                         Pageable pageable);
}
