package com.example.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Chỉ kiểm tra app khởi động được. Profile "test" dùng H2 (src/test/resources),
 * FakePaymentGateway (@Profile("!prod")) — không cần Docker.
 */
@SpringBootTest
@ActiveProfiles("test")
class ShopApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
