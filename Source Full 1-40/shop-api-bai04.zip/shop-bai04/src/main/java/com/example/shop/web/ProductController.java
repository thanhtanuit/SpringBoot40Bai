package com.example.shop.web;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.PriceUpdateRequest;
import com.example.shop.dto.ProductMapper;
import com.example.shop.dto.ProductResponse;
import com.example.shop.model.Product;
import com.example.shop.service.ProductService;

import jakarta.validation.Valid;

/**
 * Vào bằng DTO, ra bằng DTO. Model chỉ đi lại bên trong các tầng.
 *
 * BẪY 3: @Valid là CÔNG TẮC. Thiếu nó thì mọi annotation trên DTO
 * chỉ là đồ trang trí. @Valid phải nằm trên cùng tham số với @RequestBody.
 *
 * Vi phạm → Spring dừng lại, không vào method, trả 400.
 * Hiện body 400 KHÔNG nói trường nào sai — Bài 5 xử lý.
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping
    public List<ProductResponse> findAll() {
        return ProductMapper.toResponseList(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> findById(@PathVariable Long id) {
        return service.findById(id)
                .map(ProductMapper::toResponse)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody CreateProductRequest req) {
        Product moi = service.create(req.name(), req.price(), req.stock());
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.id())
                .toUri();
        return ResponseEntity.created(location).body(ProductMapper.toResponse(moi));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductResponse> update(@PathVariable Long id,
                                                  @Valid @RequestBody CreateProductRequest req) {
        return service.update(id, req.name(), req.price(), req.stock())
                .map(ProductMapper::toResponse)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        return service.delete(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }

    @PatchMapping("/{id}/price")
    public ResponseEntity<ProductResponse> updatePrice(@PathVariable Long id,
                                                       @Valid @RequestBody PriceUpdateRequest req) {
        return service.updatePrice(id, req.price())
                .map(ProductMapper::toResponse)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
