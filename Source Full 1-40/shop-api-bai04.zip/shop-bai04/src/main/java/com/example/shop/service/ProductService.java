package com.example.shop.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.shop.model.Product;
import com.example.shop.repository.ProductRepository;

import jakarta.annotation.PostConstruct;

/**
 * Tầng nghiệp vụ. Service KHÔNG biết DTO — nhận từng trường rời,
 * làm việc với model. Controller lo chuyện DTO ↔ model.
 */
@Service
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    @PostConstruct
    void logRepoDangDung() {
        log.info("ProductService đang dùng repository: {}", repo.getClass().getSimpleName());
    }

    public List<Product> findAll() {
        return repo.findAll();
    }

    public Optional<Product> findById(Long id) {
        return repo.findById(id);
    }

    /** stock là tuỳ chọn — null thì coi là 0. */
    public Product create(String name, double price, Integer stock) {
        kiemTraTrungTen(name, null);
        return repo.save(new Product(null, name, price, stock == null ? 0 : stock));
    }

    public Optional<Product> update(Long id, String name, double price, Integer stock) {
        if (repo.findById(id).isEmpty()) {
            return Optional.empty();
        }
        kiemTraTrungTen(name, id);
        return Optional.of(repo.save(new Product(id, name, price, stock == null ? 0 : stock)));
    }

    public Optional<Product> updatePrice(Long id, double price) {
        return repo.findById(id)
                .map(cu -> repo.save(new Product(cu.id(), cu.name(), price, cu.stock())));
    }

    public boolean delete(Long id) {
        if (repo.findById(id).isEmpty()) {
            return false;
        }
        repo.deleteById(id);
        return true;
    }

    /** Trùng tên → 500 (tạm thời). Bài 5 biến thành 409. */
    private void kiemTraTrungTen(String name, Long boQuaId) {
        boolean trung = repo.findAll().stream()
                .anyMatch(p -> p.name() != null
                        && p.name().equalsIgnoreCase(name)
                        && !p.id().equals(boQuaId));
        if (trung) {
            throw new IllegalArgumentException("Đã tồn tại sản phẩm tên: " + name);
        }
    }
}
