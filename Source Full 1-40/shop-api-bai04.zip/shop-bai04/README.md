# shop-api — trạng thái sau Bài 4: DTO và Validation

## Chạy

```bash
mvn spring-boot:run
```

Cổng 8081. Mở `requests.http`, chạy lần lượt.

## Cấu trúc

```
src/main/java/com/example/shop/
├── ShopApiApplication.java
├── dto/
│   ├── CreateProductRequest.java   @NotBlank @Size @NotNull @Positive @Min — kiểu wrapper
│   ├── PriceUpdateRequest.java
│   ├── ProductResponse.java
│   └── ProductMapper.java          viết tay, cố tình nhàm chán (Bài 14 → MapStruct)
├── model/
│   └── Product.java                thêm stock
├── repository/                     giữ nguyên Bài 3
├── service/
│   └── ProductService.java         nhận trường rời, không biết DTO
├── validation/
│   ├── ValidSku.java               annotation tự viết (nâng cao)
│   └── SkuValidator.java           null → true
└── web/
    ├── HelloController.java
    ├── KetQua.java
    └── ProductController.java      @Valid @RequestBody
```

## Hai loại lỗi 400

| Gửi | Chặn ở | Exception |
|---|---|---|
| `"price": "abc"` | Jackson (trạm 1) | `HttpMessageNotReadableException` |
| `"name": ""`, `"price": -5` | Validation (trạm 2) | `MethodArgumentNotValidException` |

Body 400 hiện chưa nói trường nào sai — Bài 5 xử lý.

## Bốn cái bẫy

| Bẫy | Hậu quả |
|---|---|
| Thiếu `spring-boot-starter-validation` | `@Valid` bị bỏ qua im lặng |
| `double` thay vì `Double` trong DTO nhận vào | `@NotNull` không bao giờ bắt được |
| Thiếu `@Valid` cạnh `@RequestBody` | Annotation trên DTO chỉ là trang trí |
| Nhận / trả thẳng model qua API | Rò rỉ dữ liệu, mass assignment |

## Thí nghiệm

Đổi `Double price` thành `double price` trong `CreateProductRequest`, gửi request thiếu
price → nhận 201 với giá 0.0. Đổi lại.
