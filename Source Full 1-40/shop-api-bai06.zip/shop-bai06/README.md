# shop-api — trạng thái sau Bài 6: Cấu hình và Profile

> Mọi thứ thay đổi theo môi trường nằm **ngoài code**.
> Đổi môi trường không đụng tới một dòng logic nào.

## Chạy

```bash
# dev (mặc định) — cổng 8081
mvn spring-boot:run

# prod — cổng 8080, BẮT BUỘC có PAYMENT_API_KEY
PAYMENT_API_KEY=abc mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

Kiểm tra: `GET /api/config` và `GET /api/config/gateway`.

## Cấu trúc mới

```
src/main/
├── java/com/example/shop/
│   ├── config/
│   │   ├── ShopProperties.java       @ConfigurationProperties("shop") + @Validated
│   │   └── PaymentProperties.java    secret, tách riêng
│   ├── payment/
│   │   ├── PaymentGateway.java
│   │   ├── FakePaymentGateway.java   @Profile("!prod")
│   │   └── RealPaymentGateway.java   @Profile("prod")
│   └── web/ConfigController.java     chỉ để học
└── resources/
    ├── application.yml               chung — mặc định an toàn
    ├── application-dev.yml           chỉ phần khác biệt
    └── application-prod.yml          secret không mặc định
```

## Thứ tự ưu tiên (bậc sau đè bậc trước)

| Bậc | Nguồn | Ví dụ |
|---|---|---|
| 1 | `application.yml` | `currency: VND` |
| 2 | `application-{profile}.yml` | |
| 3 | Biến môi trường | `SHOP_CURRENCY=USD` |
| 4 | Tham số JVM | `-Dshop.currency=USD` |
| 5 | Tham số dòng lệnh | `--shop.currency=EUR` |

```bash
SHOP_CURRENCY=USD mvn spring-boot:run -Dspring-boot.run.arguments=--shop.currency=EUR
# → currency: EUR
```

## Ba thí nghiệm

1. Đặt `shop.max-items-per-page: 0` → app từ chối khởi động, nói rõ trường nào sai.
2. Đổi `FakePaymentGateway` thành `@Profile("dev")`, chạy
   `-Dspring-boot.run.profiles=test` → thiếu bean `PaymentGateway`. Đổi lại `"!prod"`.
3. Chạy prod **không** có `PAYMENT_API_KEY` → *Could not resolve placeholder*.

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Tab trong YAML | Chỉ dấu cách |
| Bean theo profile không phủ hết môi trường | `@Profile("!prod")` cho bản giả |
| Secret lọt vào git | `.env` trong `.gitignore`; lỡ commit thì **thu hồi khoá** |
