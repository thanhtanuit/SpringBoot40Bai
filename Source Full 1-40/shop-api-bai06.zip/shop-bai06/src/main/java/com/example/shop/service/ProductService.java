package com.example.shop.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Product;
import com.example.shop.repository.ProductRepository;

import jakarta.annotation.PostConstruct;

/**
 * Bài 5: service NÉM exception thay vì trả Optional.
 *
 * Optional hợp lý khi người gọi có PHƯƠNG ÁN B (tạo mới, dùng mặc định).
 * Ở đây không thấy sản phẩm thì câu trả lời LUÔN là 404 — bắt controller
 * tự mở Optional rồi dựng notFound() ở từng chỗ là lặp lại cùng một quyết định.
 */
@Service
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    @PostConstruct
    void logRepoDangDung() {
        log.info("ProductService đang dùng repository: {}", repo.getClass().getSimpleName());
    }

    public List<Product> findAll() {
        return repo.findAll();
    }

    public Product findById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sản phẩm", id));
    }

    public Product create(String name, double price, Integer stock) {
        kiemTraTrungTen(name, null);
        return repo.save(new Product(null, name, price, stock == null ? 0 : stock));
    }

    public Product update(Long id, String name, double price, Integer stock) {
        findById(id);   // không có → exception bay ra, dòng dưới không chạy
        kiemTraTrungTen(name, id);
        return repo.save(new Product(id, name, price, stock == null ? 0 : stock));
    }

    public Product updatePrice(Long id, double price) {
        Product cu = findById(id);
        return repo.save(new Product(cu.id(), cu.name(), price, cu.stock()));
    }

    public void delete(Long id) {
        findById(id);
        repo.deleteById(id);
    }

    /** Món nợ Bài 3: trùng tên giờ là 409, không còn 500. */
    private void kiemTraTrungTen(String name, Long boQuaId) {
        boolean trung = repo.findAll().stream()
                .anyMatch(p -> p.name() != null
                        && p.name().equalsIgnoreCase(name)
                        && !p.id().equals(boQuaId));
        if (trung) {
            throw new DuplicateResourceException("Đã tồn tại sản phẩm tên: " + name);
        }
    }
}
