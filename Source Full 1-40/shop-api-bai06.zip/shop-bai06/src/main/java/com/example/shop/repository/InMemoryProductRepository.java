package com.example.shop.repository;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.example.shop.model.Product;

/**
 * Bản cài đặt chính, dữ liệu nằm trong bộ nhớ.
 *
 * @Primary: khi có nhiều bean cùng kiểu ProductRepository, "phân vân thì chọn tôi".
 * Thí nghiệm: bỏ @Primary → app chết lúc khởi động vì Spring thấy HAI bean
 * (inMemoryProductRepository, fakeProductRepository) mà không biết chọn cái nào.
 *
 * Bean là SINGLETON, mọi request dùng chung → ConcurrentHashMap + AtomicLong.
 */
@Repository
@Primary
public class InMemoryProductRepository implements ProductRepository {

    private final Map<Long, Product> data = new ConcurrentHashMap<>();
    private final AtomicLong idSeq = new AtomicLong(0);

    @Override
    public List<Product> findAll() {
        return data.values().stream()
                .sorted(Comparator.comparing(Product::id))
                .toList();
    }

    @Override
    public Optional<Product> findById(Long id) {
        return Optional.ofNullable(data.get(id));
    }

    @Override
    public Product save(Product product) {
        Product luu = product.id() == null
                ? new Product(idSeq.incrementAndGet(), product.name(), product.price(), product.stock())
                : product;
        data.put(luu.id(), luu);
        return luu;
    }

    @Override
    public void deleteById(Long id) {
        data.remove(id);
    }
}
