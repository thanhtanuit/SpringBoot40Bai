package com.example.shop.model;

/**
 * Sản phẩm — model NỘI BỘ. Không bao giờ nhận vào hay trả thẳng ra API
 * (dùng DTO trong package dto). Bài 4 thêm trường stock.
 */
public record Product(Long id, String name, double price, int stock) {
}
