package com.example.shop.dto;

import java.util.List;

import com.example.shop.model.Product;

/**
 * Chuyển model → DTO. Lấy từng trường bên này gán sang bên kia.
 *
 * Code này nhàm chán, và CỐ TÌNH để nhàm chán như vậy.
 * Bài 14 thay bằng MapStruct — phải tự viết cái nhàm trước thì mới
 * cảm được công cụ kia tiết kiệm cho mình cái gì.
 */
public final class ProductMapper {

    private ProductMapper() {
    }

    public static ProductResponse toResponse(Product p) {
        return new ProductResponse(p.id(), p.name(), p.price(), p.stock());
    }

    public static List<ProductResponse> toResponseList(List<Product> list) {
        return list.stream().map(ProductMapper::toResponse).toList();
    }
}
