package com.example.shop.repository;

import java.util.List;
import java.util.Optional;

import com.example.shop.model.Product;

/**
 * Tầng lưu trữ.
 *
 * Tên bốn method CỐ TÌNH trùng với JpaRepository của Spring Data.
 * Bài 8 sẽ xoá interface này cùng mọi bản cài đặt, thay bằng một interface
 * kế thừa JpaRepository — và ProductService không phải sửa dòng nào.
 */
public interface ProductRepository {

    List<Product> findAll();

    /** Optional buộc người gọi nghĩ tới trường hợp không tìm thấy. */
    Optional<Product> findById(Long id);

    /** Chưa có id thì sinh id mới; có rồi thì ghi đè. */
    Product save(Product product);

    void deleteById(Long id);
}
