-- V12 — Bài 21: hai tài khoản mẫu. CHỈ CHO DEV — production không seed tài khoản có mật khẩu biết trước.
--   admin  / admin12345   → ADMIN
--   seller / seller12345  → SELLER
-- Hash BCrypt cost 12, sinh thật (không chép từ mạng). Mỗi hash có salt riêng nhúng bên trong.

INSERT INTO app_user (username, password, email, enabled, created_at, updated_at, created_by, updated_by) VALUES
  ('admin',  '$2a$12$d8YdmlETkXnQtheHDj3DcOd7ErrvcGyQVd.YpLl5M68xYRbPwHF.e', 'admin@shop.local',  true, now(), now(), 'system', 'system'),
  ('seller', '$2a$12$E/HzcRUo4yJjbgbj9Qjb5u3DT6FxbpkMUgFEhhESAm/dd.kj/VKpi', 'seller@shop.local', true, now(), now(), 'system', 'system');

INSERT INTO user_role (user_id, role) VALUES
  ((SELECT id FROM app_user WHERE username = 'admin'),  'ADMIN'),
  ((SELECT id FROM app_user WHERE username = 'seller'), 'SELLER');
