-- V2 — dữ liệu mẫu. KHÔNG cần ON CONFLICT DO NOTHING như Bài 11:
-- Flyway chạy file này ĐÚNG MỘT LẦN rồi ghi vào flyway_schema_history.

INSERT INTO category (name) VALUES
    ('Bàn phím'),
    ('Chuột'),
    ('Âm thanh & hình ảnh');

INSERT INTO product (name, price, stock, category_id, created_at) VALUES
    ('Bàn phím cơ',       1250000, 10, 1, CURRENT_TIMESTAMP),
    ('Chuột không dây',    350000, 25, 2, CURRENT_TIMESTAMP),
    ('Tai nghe chụp tai',  890000,  8, 3, CURRENT_TIMESTAMP),
    ('Màn hình 27 inch',  4500000,  4, 3, CURRENT_TIMESTAMP),
    ('Webcam Full HD',     650000, 15, 3, CURRENT_TIMESTAMP);
