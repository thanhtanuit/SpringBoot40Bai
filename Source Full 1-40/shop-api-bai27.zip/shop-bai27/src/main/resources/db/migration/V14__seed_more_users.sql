-- V14 — Bài 23: tài khoản USER để kiểm ma trận quyền. CHỈ CHO DEV.
--   user1 / user12345 → USER
INSERT INTO app_user (username, password, email, enabled, created_at, updated_at, created_by, updated_by) VALUES
  ('user1', '$2a$12$uC.Q.y48NebCvrJR2nZ3aOU4ptpVCe9OpO5XQMwkci.anpxm2AWUS', 'user1@shop.local', true, now(), now(), 'system', 'system');

INSERT INTO user_role (user_id, role) VALUES
  ((SELECT id FROM app_user WHERE username = 'user1'), 'USER');
