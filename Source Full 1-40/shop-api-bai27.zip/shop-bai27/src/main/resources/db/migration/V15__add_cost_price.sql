-- V15 — Bài 23: giá vốn — thông tin kinh doanh nội bộ, chỉ ADMIN thấy.
ALTER TABLE product ADD COLUMN cost_price DOUBLE PRECISION;
UPDATE product SET cost_price = ROUND((price * 0.7)::numeric, 0);
