-- V3 — thêm cột sku. MẪU BA BƯỚC khi bảng ĐÃ CÓ dữ liệu.
--
-- Gộp một bước (ADD COLUMN sku ... NOT NULL) lỗi ngay vì dòng cũ không có giá trị.
-- Trên bảng RỖNG thì gộp vẫn chạy — đó chính là cái bẫy: chạy trên máy dev vừa xoá
-- sạch, hỏng trên production có mười nghìn dòng.

-- Bước 1: thêm cột, CHO PHÉP null
ALTER TABLE product ADD COLUMN sku VARCHAR(20);

-- Bước 2: điền giá trị cho những dòng đã có (dạng SKU-0001, khớp @ValidSku)
UPDATE product SET sku = 'SKU-' || LPAD(id::text, 4, '0');

-- Bước 3: giờ mới siết ràng buộc
ALTER TABLE product ALTER COLUMN sku SET NOT NULL;
ALTER TABLE product ADD CONSTRAINT uk_product_sku UNIQUE (sku);
