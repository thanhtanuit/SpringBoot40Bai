-- V10 — Bài 20: bảng khoá của ShedLock.
-- Instance nào chạy trước INSERT/UPDATE một dòng; instance kia gặp khoá và bỏ qua lượt.
CREATE TABLE shedlock (
    name       VARCHAR(64)  NOT NULL PRIMARY KEY,
    lock_until TIMESTAMP    NOT NULL,
    locked_at  TIMESTAMP    NOT NULL,
    locked_by  VARCHAR(255) NOT NULL
);
