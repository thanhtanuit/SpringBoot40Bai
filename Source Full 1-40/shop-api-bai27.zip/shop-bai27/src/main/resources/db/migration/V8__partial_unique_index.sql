-- V8 — Bài 16: MẶT TRÁI của soft delete — unique bị vướng.
-- Xoá mềm "Bàn phím cơ" rồi tạo lại → dòng cũ vẫn nằm đó → vi phạm uk_product_name.
-- Tệ hơn: existsByNameIgnoreCase trả false (@SQLRestriction lọc mất) nên lỗi không bị
-- chặn ở service mà nổ ở database.
--
-- Postgres: PARTIAL unique index — chỉ ràng buộc dòng chưa xoá.
-- (MySQL không có — phải xoay sang cách khác, ví dụ đưa deleted_at vào khoá unique.)

ALTER TABLE product DROP CONSTRAINT uk_product_name;
ALTER TABLE product DROP CONSTRAINT uk_product_sku;

CREATE UNIQUE INDEX uk_product_name_active ON product (name) WHERE deleted = false;
CREATE UNIQUE INDEX uk_product_sku_active  ON product (sku)  WHERE deleted = false;
