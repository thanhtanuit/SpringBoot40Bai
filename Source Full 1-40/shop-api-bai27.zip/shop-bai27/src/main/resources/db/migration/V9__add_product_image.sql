-- V9 — Bài 17: ảnh sản phẩm.
-- Lưu TÊN FILE (UUID.png), KHÔNG lưu đường dẫn tuyệt đối: đổi máy, đổi thư mục,
-- chuyển sang S3 là dữ liệu cũ vô dụng.
ALTER TABLE product ADD COLUMN image_path VARCHAR(255);
