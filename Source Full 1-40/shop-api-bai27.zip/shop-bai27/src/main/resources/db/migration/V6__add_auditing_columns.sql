-- V6 — Bài 16: cột auditing cho product, category, orders.
-- Mẫu 3 bước của Bài 12: thêm nullable → điền dòng cũ → siết NOT NULL.
-- Kiểu TIMESTAMP WITH TIME ZONE khớp Instant (validate sẽ chặn nếu lệch).

ALTER TABLE product  ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE product  ADD COLUMN created_by VARCHAR(100);
ALTER TABLE product  ADD COLUMN updated_by VARCHAR(100);

ALTER TABLE category ADD COLUMN created_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE category ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE category ADD COLUMN created_by VARCHAR(100);
ALTER TABLE category ADD COLUMN updated_by VARCHAR(100);

ALTER TABLE orders   ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE orders   ADD COLUMN created_by VARCHAR(100);
ALTER TABLE orders   ADD COLUMN updated_by VARCHAR(100);

UPDATE product  SET updated_at = created_at WHERE updated_at IS NULL;
UPDATE category SET created_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE created_at IS NULL;
UPDATE orders   SET updated_at = created_at WHERE updated_at IS NULL;

ALTER TABLE product  ALTER COLUMN updated_at SET NOT NULL;
ALTER TABLE category ALTER COLUMN created_at SET NOT NULL;
ALTER TABLE category ALTER COLUMN updated_at SET NOT NULL;
ALTER TABLE orders   ALTER COLUMN updated_at SET NOT NULL;
