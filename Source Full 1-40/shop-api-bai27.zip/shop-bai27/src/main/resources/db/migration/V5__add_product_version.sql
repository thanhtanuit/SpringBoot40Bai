-- V5 — Bài 13 (nâng cao): optimistic locking cho product.
-- Mọi UPDATE của Hibernate thêm "AND version = ?"; ai sửa trước thì version tăng,
-- câu UPDATE của người sau khớp 0 dòng → OptimisticLockingFailureException → 409.

ALTER TABLE product ADD COLUMN version BIGINT NOT NULL DEFAULT 0;
