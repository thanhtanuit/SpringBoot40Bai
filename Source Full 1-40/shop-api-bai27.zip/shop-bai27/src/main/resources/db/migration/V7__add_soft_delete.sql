-- V7 — Bài 16: xoá mềm cho product.
ALTER TABLE product ADD COLUMN deleted BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX idx_product_deleted ON product (deleted);
