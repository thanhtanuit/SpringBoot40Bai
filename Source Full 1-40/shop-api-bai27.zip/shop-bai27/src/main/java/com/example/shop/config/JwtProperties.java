package com.example.shop.config;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/** Bài 22 — nhóm shop.jwt. */
@Validated
@ConfigurationProperties(prefix = "shop.jwt")
public record JwtProperties(

        @NotBlank
        String secret,

        @NotNull
        Duration accessTokenTtl,

        @NotNull
        Duration refreshTokenTtl,

        @NotBlank
        String issuer
) {
}
