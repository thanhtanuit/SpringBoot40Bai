package com.example.shop.dto;

import java.util.List;
import java.util.function.Function;

import org.springframework.data.domain.Slice;

/**
 * Cho giao diện CUỘN VÔ HẠN — không có "trang 5", chỉ có "tải thêm".
 * Không có totalElements/totalPages → không cần câu count.
 */
public record SliceResponse<T>(List<T> content, int page, int size, boolean hasNext) {

    public static <E, T> SliceResponse<T> from(Slice<E> slice, Function<E, T> mapper) {
        return new SliceResponse<>(
                slice.getContent().stream().map(mapper).toList(),
                slice.getNumber(),
                slice.getSize(),
                slice.hasNext());
    }
}
