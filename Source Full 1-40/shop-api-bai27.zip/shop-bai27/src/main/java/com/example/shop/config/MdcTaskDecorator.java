package com.example.shop.config;

import java.util.Map;

import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

/**
 * Bài 20 — món nợ từ Bài 7: MDC nằm trong ThreadLocal, KHÔNG tự đi theo sang thread khác.
 * Không có decorator này, log trong @Async mất requestId — không lần được từ request
 * sang việc nó sinh ra. Chép MDC khi GIAO việc, đặt lại trong thread mới, dọn khi xong.
 */
public class MdcTaskDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        Map<String, String> context = MDC.getCopyOfContextMap();
        return () -> {
            if (context != null) {
                MDC.setContextMap(context);
            }
            try {
                runnable.run();
            } finally {
                MDC.clear();
            }
        };
    }
}
