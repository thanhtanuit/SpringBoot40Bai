package com.example.shop.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;

/**
 * Bài 16 — bốn cột auditing, không một dòng service nào đụng tới.
 *
 * @MappedSuperclass: KHÔNG phải entity, không có bảng riêng — cột gộp vào bảng của class con.
 * (Khác @Inheritance, thứ tạo kế thừa thật trong database.)
 *
 * Import từ org.springframework.data.annotation, không phải Hibernate.
 * Cặp của Hibernate (@CreationTimestamp, @UpdateTimestamp) không có phần createdBy.
 *
 * AuditingEntityListener móc vào vòng đời: @PrePersist điền cả bốn, @PreUpdate điền hai.
 * updatable = false: Hibernate loại created_* khỏi mọi câu UPDATE.
 */
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class BaseEntity {

    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @CreatedBy
    @Column(name = "created_by", length = 100, updatable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "updated_by", length = 100)
    private String updatedBy;

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }
}
