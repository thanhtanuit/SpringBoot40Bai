package com.example.shop.model;

public enum Role {
    USER, SELLER, ADMIN
}
