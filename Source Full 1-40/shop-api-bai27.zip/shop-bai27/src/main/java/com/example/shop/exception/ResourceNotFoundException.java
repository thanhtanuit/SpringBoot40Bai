package com.example.shop.exception;

/**
 * Không tìm thấy tài nguyên → 404.
 *
 * Giữ resource và id thành FIELD riêng, không chỉ nhét vào message:
 * handler đưa chúng vào response dạng dữ liệu có cấu trúc (resourceId = 42)
 * thay vì bắt client tách chữ từ câu văn.
 *
 * BẪY 1: kế thừa RuntimeException, KHÔNG phải Exception.
 *  - checked exception bắt mọi method trên đường đi khai throws / try-catch
 *  - Spring CHỈ tự rollback transaction với RuntimeException (Bài 13)
 */
public class ResourceNotFoundException extends RuntimeException {

    private final String resource;
    private final Object id;

    public ResourceNotFoundException(String resource, Object id) {
        super("Không tìm thấy " + resource + " với id " + id);
        this.resource = resource;
        this.id = id;
    }

    public String getResource() {
        return resource;
    }

    public Object getId() {
        return id;
    }
}
