package com.example.shop.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Bài 20 — bật @Scheduled. Pool 5 thread cấu hình trong application.yml (spring.task.scheduling). */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}
