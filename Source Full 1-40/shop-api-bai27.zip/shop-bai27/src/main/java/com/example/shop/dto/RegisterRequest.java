package com.example.shop.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * max = 72 KHÔNG tuỳ tiện: BCrypt CẮT BỎ mọi thứ sau byte thứ 72. Không chặn thì hai mật
 * khẩu 100 ký tự có 72 byte đầu giống nhau được coi là trùng khớp.
 * (Ký tự tiếng Việt có dấu chiếm 2–3 byte UTF-8 — 72 ký tự có thể vượt 72 byte.)
 */
public record RegisterRequest(

        @NotBlank
        @Size(min = 3, max = 50)
        @Pattern(regexp = "^[a-zA-Z0-9._-]+$", message = "Username chỉ gồm chữ, số và . _ -")
        String username,

        @NotBlank
        @Size(min = 8, max = 72, message = "Mật khẩu phải từ 8 đến 72 ký tự")
        String password,

        @NotBlank
        @Email(message = "Email không hợp lệ")
        String email
) {
}
