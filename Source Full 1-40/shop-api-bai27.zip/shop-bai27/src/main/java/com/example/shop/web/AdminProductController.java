package com.example.shop.web;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.service.ProductService;

/**
 * Bài 16 — quản trị xoá mềm.
 *
 * CHƯA CÓ BẢO MẬT: ai cũng gọi được. Bài 21 dành /api/admin/** riêng cho ADMIN —
 * nhớ quay lại siết.
 */
@RestController
@RequestMapping("/api/admin/products")
public class AdminProductController {

    private final ProductService service;

    public AdminProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping("/deleted")
    public List<Map<String, Object>> daXoa() {
        return service.findDeleted().stream()
                .map(p -> Map.<String, Object>of(
                        "id", p.getId(),
                        "name", p.getName(),
                        "sku", p.getSku(),
                        "deletedAt", p.getUpdatedAt()))
                .toList();
    }

    @PostMapping("/{id}/restore")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void khoiPhuc(@PathVariable Long id) {
        service.restore(id);
    }
}
