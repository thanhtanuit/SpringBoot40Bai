package com.example.shop.client;

/** 4xx hoặc dữ liệu thiếu — thử lại vẫn sai y hệt. KHÔNG retry. */
public class ExchangeRateClientException extends RuntimeException {

    public ExchangeRateClientException(String message) {
        super(message);
    }
}
