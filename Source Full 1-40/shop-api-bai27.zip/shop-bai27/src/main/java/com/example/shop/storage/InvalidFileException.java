package com.example.shop.storage;

/** File không hợp lệ → 400. */
public class InvalidFileException extends RuntimeException {

    public InvalidFileException(String message) {
        super(message);
    }
}
