package com.example.shop.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

/**
 * Bài 18 — gọi API tỷ giá.
 *
 * Bài học chính không phải cách gọi HTTP — mà là KHÔNG để dịch vụ của người khác
 * kéo sập dịch vụ của bạn. Mọi lời gọi ra ngoài đều có thể chậm, lỗi, hoặc không bao
 * giờ trả về. Thiết kế cho tình huống đó ngay từ đầu.
 *
 * Ba cơ chế bổ sung nhau:
 *   timeout         chặn treo vô hạn                 (RestClientConfig)
 *   retry           vượt qua lỗi thoáng qua           (@Retryable)
 *   circuit breaker ngăn gõ cửa một cánh cửa đã khoá  (nâng cao — xem cuối file)
 *   (+ bulkhead: giới hạn số lời gọi đồng thời)
 */
@Component
public class ExchangeRateClient {

    private static final Logger log = LoggerFactory.getLogger(ExchangeRateClient.class);

    private final RestClient client;

    public ExchangeRateClient(RestClient exchangeRateRestClient) {
        this.client = exchangeRateRestClient;
    }

    /**
     * RANH GIỚI RETRY — quyết định quan trọng nhất: 4xx không đáng thử lại (sai là sai),
     * 5xx và lỗi mạng thì đáng. Retry mù quáng mọi lỗi là khuếch đại sự cố nhỏ thành lớn.
     *
     * @Backoff: chờ 500ms → 1s → 2s. Lũy tiến vì dịch vụ đang quá tải mà bắn lại ngay
     * chỉ làm tệ hơn. random = true: JITTER — 100 instance cùng lỗi không retry cùng lúc
     * (thundering herd).
     *
     * RETRY KHÔNG MIỄN PHÍ: nhân thời gian chờ tệ nhất lên. 3 lần × readTimeout 5s + backoff
     * ≈ 16 giây. Endpoint người dùng đang nhìn màn hình: 2 lần × 2s thường hợp lý hơn.
     *
     * Không có @Recover ở đây, CÓ CHỦ ĐÍCH: @Recover trả giá trị mặc định thì @Cacheable
     * sẽ CACHE luôn giá trị mặc định đó — và ConcurrentMapCacheManager không có TTL →
     * tỷ giá giả nằm đó tới khi restart. Để exception bay ra (không bị cache),
     * service bắt và dùng mặc định.
     *
     * Proxy: @Retryable, @Cacheable, @Transactional — gọi this.layTyGia(...) từ trong
     * cùng class thì cả ba vô hiệu (self-invocation, Bài 13).
     */
    @Cacheable(value = "exchangeRates", key = "#currency")
    @Retryable(
            retryFor = { ExchangeRateServerException.class, ResourceAccessException.class },
            noRetryFor = ExchangeRateClientException.class,
            maxAttempts = 3,
            backoff = @Backoff(delay = 500, multiplier = 2, maxDelay = 4000, random = true))
    public double layTyGia(String currency) {
        log.debug("Gọi API tỷ giá cho {}", currency);

        ExchangeRateResponse res = client.get()
                .uri("/latest/VND")
                .retrieve()
                .onStatus(status -> status.is4xxClientError(), (req, resp) -> {
                    throw new ExchangeRateClientException("Yêu cầu tỷ giá không hợp lệ: " + resp.getStatusCode());
                })
                .onStatus(status -> status.is5xxServerError(), (req, resp) -> {
                    throw new ExchangeRateServerException("Dịch vụ tỷ giá đang lỗi: " + resp.getStatusCode());
                })
                .body(ExchangeRateResponse.class);

        if (res == null || res.rates() == null || !res.rates().containsKey(currency)) {
            throw new ExchangeRateClientException("Không có tỷ giá cho " + currency);
        }

        double tyGia = res.rates().get(currency);
        log.info("Tỷ giá VND -> {} = {}", currency, tyGia);
        return tyGia;
    }

    /*
     * ===== NÂNG CAO — CIRCUIT BREAKER (Resilience4j) =====
     * Retry giải quyết lỗi thoáng qua, KHÔNG giải quyết dịch vụ chết hẳn 30 phút: mỗi request
     * vẫn chờ đủ timeout rồi retry — tự làm chậm mình và dội thêm tải vào hệ thống đang hấp hối.
     *
     * Circuit breaker đếm tỷ lệ lỗi, vượt ngưỡng thì MỞ MẠCH: lời gọi sau thất bại NGAY,
     * không chạm mạng. Sau một lúc cho vài request thử; thành công thì đóng lại.
     *   CLOSED (bình thường) → OPEN (fail nhanh) → HALF_OPEN (thử dè dặt)
     *
     * Bật: bỏ comment dependency trong pom.xml, thêm spring-boot-starter-aop, cấu hình:
     *   resilience4j.circuitbreaker.instances.exchangeRate:
     *     sliding-window-size: 10
     *     minimum-number-of-calls: 5
     *     failure-rate-threshold: 50
     *     wait-duration-in-open-state: 30s
     *     permitted-number-of-calls-in-half-open-state: 3
     * rồi gắn @CircuitBreaker(name = "exchangeRate") lên layTyGia.
     * Thử: URL sai, gọi 6 lần — 5 lần đầu chậm vì retry, từ lần 6 trả TỨC THÌ.
     */
}
