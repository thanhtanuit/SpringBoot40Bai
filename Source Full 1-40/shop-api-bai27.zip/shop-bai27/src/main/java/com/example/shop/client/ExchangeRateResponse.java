package com.example.shop.client;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Ánh xạ JSON vào record CÓ KIỂU, không dùng Map<String, Object> thô:
 * IDE gợi ý được, sai cấu trúc thì lỗi ngay chỗ parse — không phải ClassCastException
 * ở đâu đó sâu trong code.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ExchangeRateResponse(
        String result,
        @JsonProperty("base_code") String baseCode,
        Map<String, Double> rates
) {
}
