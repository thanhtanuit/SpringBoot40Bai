package com.example.shop.service;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.shop.client.ExchangeRateClient;
import com.example.shop.config.ExchangeRateProperties;
import com.example.shop.repository.ProductRepository;

/**
 * Bài 20 — @Async trả CompletableFuture. Class RIÊNG — gọi từ cùng class là self-invocation.
 */
@Service
public class AsyncQueryService {

    private static final Logger log = LoggerFactory.getLogger(AsyncQueryService.class);

    private final ExchangeRateClient exchangeRateClient;
    private final ExchangeRateProperties exchangeRateProps;
    private final ProductRepository productRepo;

    public AsyncQueryService(ExchangeRateClient exchangeRateClient,
                             ExchangeRateProperties exchangeRateProps,
                             ProductRepository productRepo) {
        this.exchangeRateClient = exchangeRateClient;
        this.exchangeRateProps = exchangeRateProps;
        this.productRepo = productRepo;
    }

    @Async("taskExecutor")
    public CompletableFuture<Double> layTyGiaAsync(String currency) {
        try {
            return CompletableFuture.completedFuture(exchangeRateClient.layTyGia(currency));
        } catch (RuntimeException ex) {
            log.warn("Tỷ giá lỗi ({}), dùng mặc định", ex.getMessage());
            return CompletableFuture.completedFuture(1.0 / exchangeRateProps.defaultUsdRate());
        }
    }

    @Async("taskExecutor")
    public CompletableFuture<Long> demTonKhoAsync() {
        return CompletableFuture.completedFuture(productRepo.tongTonKho());
    }
}
