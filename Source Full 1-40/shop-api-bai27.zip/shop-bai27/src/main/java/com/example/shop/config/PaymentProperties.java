package com.example.shop.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;

/**
 * Cấu hình cổng thanh toán — nhóm "shop.payment".
 *
 * apiKey là SECRET: ở prod đọc từ biến môi trường PAYMENT_API_KEY, KHÔNG có
 * giá trị mặc định. Thiếu biến → app chết lúc khởi động. Chết ngay lúc triển khai
 * tốt hơn nhiều so với âm thầm chạy với khoá rỗng.
 *
 * Tách riêng khỏi ShopProperties để ConfigController không bao giờ vô tình trả nó ra.
 */
@Validated
@ConfigurationProperties(prefix = "shop.payment")
public record PaymentProperties(

        @NotBlank
        String apiKey
) {
}
