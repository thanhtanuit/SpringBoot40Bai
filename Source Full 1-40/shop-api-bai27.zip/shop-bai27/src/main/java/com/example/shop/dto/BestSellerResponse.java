package com.example.shop.dto;

/** totalSold là Long vì SUM trả Long. */
public record BestSellerResponse(Long productId, String productName, Long totalSold) {
}
