package com.example.shop.dto;

/**
 * Bài 15 — gom mọi bộ lọc vào một record, nhận qua @ModelAttribute:
 * Spring dựng từ QUERY STRING (không phải body), không cần @RequestParam cho từng field.
 *
 *   GET /api/products/search?keyword=bàn&minPrice=500000&inStock=true
 *
 * Mọi trường tuỳ chọn. inStock: true = còn hàng, false = hết hàng, bỏ trống = không lọc.
 */
public record ProductFilter(
        String keyword,
        Double minPrice,
        Double maxPrice,
        Long categoryId,
        String categoryName,
        Boolean inStock
) {
}
