package com.example.shop.security;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.crypto.SecretKey;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.example.shop.config.JwtProperties;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

/**
 * Bài 22 — tạo và xác minh access token.
 *
 * ===== JWT KHÔNG ĐƯỢC MÃ HOÁ =====
 *   echo '<token>' | cut -d. -f2 | base64 -d
 * Payload chỉ là Base64URL — ai chặn được token đều ĐỌC được. Chữ ký bảo vệ TÍNH TOÀN VẸN
 * (không sửa được), KHÔNG bảo vệ tính bí mật.
 * → Không bao giờ đặt mật khẩu, số thẻ, CMND, khoá API, dữ liệu cá nhân nhạy cảm vào JWT.
 *   Chỉ những gì cần cho phân quyền: username, quyền, thời hạn.
 *
 * HS256 dùng khoá ĐỐI XỨNG — ai xác minh được cũng ký được. Nhiều dịch vụ xác minh, một
 * dịch vụ cấp → RS256.
 * Thuật toán "none" là lỗ hổng kinh điển ở thư viện cũ — jjwt 0.12 không chấp nhận.
 */
@Service
public class JwtService {

    private final JwtProperties props;
    private final SecretKey key;

    public JwtService(JwtProperties props) {
        this.props = props;
        byte[] bytes = props.secret().getBytes(StandardCharsets.UTF_8);
        // HS256 cần tối thiểu 256 bit. Kiểm tra NGAY: chết lúc boot, không phải lúc có người đăng nhập.
        if (bytes.length < 32) {
            throw new IllegalStateException("JWT secret phải dài tối thiểu 32 byte cho HS256");
        }
        this.key = Keys.hmacShaKeyFor(bytes);
    }

    public String generateToken(UserDetails user) {
        Instant now = Instant.now();
        List<String> roles = user.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();

        return Jwts.builder()
                .subject(user.getUsername())
                .issuer(props.issuer())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(props.accessTokenTtl())))
                .id(UUID.randomUUID().toString())
                .claim("roles", roles)
                .signWith(key)
                .compact();
    }

    public String extractUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    public boolean isValid(String token, UserDetails user) {
        try {
            Claims claims = extractAllClaims(token);
            return claims.getSubject().equals(user.getUsername())
                    && claims.getExpiration().after(new Date());
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * parseSignedClaims + verifyWith = CHỖ KIỂM TRA CHỮ KÝ.
     * Bỏ verifyWith thì ai cũng tự tạo token "roles": ["ROLE_ADMIN"] và bạn chấp nhận —
     * lỗ hổng JWT phổ biến nhất trong thực tế.
     */
    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(props.issuer())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
