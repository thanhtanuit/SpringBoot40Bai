package com.example.shop.exception;

/**
 * Dữ liệu bị trùng → 409 Conflict.
 * Request hợp lệ về hình thức, nhưng xung đột với trạng thái hiện tại.
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
