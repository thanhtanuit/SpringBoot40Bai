package com.example.shop.repository;

import java.time.Instant;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.shop.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * Nạp CÓ CHỦ ĐÍCH: một câu truy vấn lấy cả đơn, cả dòng hàng, cả sản phẩm.
     * Thí nghiệm Bài 9: đổi OrderService.findById sang repo.findById thường →
     * LazyInitializationException khi mapper chạm items ngoài giao dịch.
     */
    @Query("""
            SELECT DISTINCT o FROM Order o
            LEFT JOIN FETCH o.items i
            LEFT JOIN FETCH i.product
            WHERE o.id = :id
            """)
    Optional<Order> findByIdWithItems(@Param("id") Long id);

    /** Bài 20 — OrderStatsJob. createdAt nằm ở BaseEntity (Bài 16). */
    long countByCreatedAtAfter(Instant moc);
}
