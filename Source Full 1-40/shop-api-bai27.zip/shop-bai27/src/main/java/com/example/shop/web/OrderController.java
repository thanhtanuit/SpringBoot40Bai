package com.example.shop.web;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.OrderResponse;
import com.example.shop.model.Order;
import com.example.shop.mapper.OrderMapper;
import com.example.shop.model.AuditLog;
import com.example.shop.service.AuditService;
import com.example.shop.service.OrderService;

import java.util.List;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService service;
    private final AuditService auditService;
    private final OrderMapper mapper;

    public OrderController(OrderService service, AuditService auditService, OrderMapper mapper) {
        this.service = service;
        this.auditService = auditService;
        this.mapper = mapper;
    }

    /** Bài 13 — xem audit_log gần đây (CHỈ ĐỂ HỌC). */
    @GetMapping("/audit")
    public List<AuditLog> audit() {
        return auditService.ganDay();
    }

    /*
     * Bài 13 — THÍ NGHIỆM 3 (self-invocation). Bỏ comment khi thử, xoá sau khi quan sát.
     *
     * @PostMapping("/sai")
     * public OrderResponse datHangSai(@Valid @RequestBody CreateOrderRequest req) {
     *     return mapper.toResponse(service.datHangSai(req));
     * }
     */

    @PostMapping
    public ResponseEntity<OrderResponse> create(@Valid @RequestBody CreateOrderRequest req) {
        Order moi = service.datHang(req);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.getId())
                .toUri();
        return ResponseEntity.created(location).body(mapper.toResponse(moi));
    }

    /**
     * Bài 23 — chỉ CHỦ ĐƠN (createdBy) hoặc ADMIN.
     * #id: tham số method. authentication: biến có sẵn trong SpEL của Spring Security.
     *
     * @PostAuthorize("returnObject.createdBy == authentication.name") gọn hơn nhưng nguy hiểm:
     * method đã chạy xong, mọi tác dụng phụ đã xảy ra. Chỉ dùng cho method thuần đọc.
     */
    @GetMapping("/{id}")
    @PreAuthorize("@orderSecurity.isOwner(#id, authentication)")
    public OrderResponse findById(@PathVariable Long id) {
        return mapper.toResponse(service.findById(id));
    }

    /*
     * ===== THÍ NGHIỆM 1 — CỐ TÌNH SAI: trả thẳng entity =====
     * Bỏ comment, gọi GET /api/orders/1/raw → 500, log: Infinite recursion (StackOverflowError)
     *   Order["items"] → OrderItem["order"] → Order["items"] → ...
     * @JsonIgnore chỉ vá triệu chứng và bắt entity biết chuyện JSON. Cách đúng: DTO.
     * Quan sát xong XOÁ đi.
     *
     * @GetMapping("/{id}/raw")
     * public Order raw(@PathVariable Long id) {
     *     return service.findById(id);
     * }
     *
     * ===== THÍ NGHIỆM 2 — LazyInitializationException =====
     * Trong OrderService.findById đổi orderRepo.findByIdWithItems(id) thành orderRepo.findById(id).
     * Gọi GET /api/orders/1 → could not initialize proxy - no Session.
     * items là proxy LAZY; mapper chạm vào khi giao dịch đã đóng. open-in-view: false (Bài 8)
     * làm lỗi hiện ra — bật nó thì lỗi biến mất nhưng thành N+1 âm thầm. Trả lại như cũ.
     */
}
