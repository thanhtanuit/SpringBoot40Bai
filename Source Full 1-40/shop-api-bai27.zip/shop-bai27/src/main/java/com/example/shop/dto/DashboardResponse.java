package com.example.shop.dto;

public record DashboardResponse(double usdRate, long tongTonKho, long thoiGianMs) {
}
