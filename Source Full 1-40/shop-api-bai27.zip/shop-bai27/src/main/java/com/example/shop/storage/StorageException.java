package com.example.shop.storage;

/** Lỗi đọc/ghi đĩa → 500 (lưới an toàn của Bài 5). */
public class StorageException extends RuntimeException {

    public StorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
