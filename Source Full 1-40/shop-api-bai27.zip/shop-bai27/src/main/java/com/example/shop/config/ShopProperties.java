package com.example.shop.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/**
 * Nhóm cấu hình "shop" trong application.yml, gom thành MỘT object có kiểu.
 *
 * Hơn @Value rải rác ở ba điểm:
 *  1. Muốn biết app có cấu hình gì — mở đúng file này
 *  2. Gõ sai tên khoá — IDE báo ngay (nhờ configuration-processor)
 *  3. @Validated — cấu hình vô lý thì app CHẾT LÚC KHỞI ĐỘNG, nói rõ trường nào
 *     Thí nghiệm: đặt shop.max-items-per-page: 0 rồi chạy.
 *
 * Relaxed binding — ba cách viết cùng trỏ vào maxItemsPerPage:
 *   max-items-per-page (YAML)   maxItemsPerPage (Java)   SHOP_MAX_ITEMS_PER_PAGE (biến môi trường)
 */
@Validated
@ConfigurationProperties(prefix = "shop")
public record ShopProperties(

        @NotBlank
        String name,

        @Min(1) @Max(100)
        int maxItemsPerPage,

        @NotBlank
        String currency
) {
}
