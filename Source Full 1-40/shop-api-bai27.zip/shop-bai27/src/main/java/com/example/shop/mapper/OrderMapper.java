package com.example.shop.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.example.shop.dto.OrderItemResponse;
import com.example.shop.dto.OrderResponse;
import com.example.shop.model.Order;
import com.example.shop.model.OrderItem;

/**
 * Xoá OrderMapper viết tay của Bài 9.
 *
 * BẪY 2: toItemResponse chạm item.getProduct().getName(). product LAZY, chưa nạp,
 * phiên đã đóng → LazyInitializationException — ĐÚNG NHƯ BÀI 9.
 * MapStruct không đổi luật chơi của JPA. findByIdWithItems với JOIN FETCH vẫn lo nạp.
 */
@Mapper(componentModel = "spring")
public interface OrderMapper {

    /** Không khai gì cho items: List<OrderItem> → List<OrderItemResponse>, tự ghép qua toItemResponse. */
    OrderResponse toResponse(Order order);

    /**
     * lineTotal tự khớp với getLineTotal() của entity.
     * Nếu phải TÍNH: @Mapping(target = "lineTotal", expression = "java(...)") — nhưng
     * expression là CHUỖI: IDE không kiểm tra, không refactor. Dài thì dùng default method.
     */
    @Mapping(source = "product.id", target = "productId")
    @Mapping(source = "product.name", target = "productName")
    OrderItemResponse toItemResponse(OrderItem item);
}
