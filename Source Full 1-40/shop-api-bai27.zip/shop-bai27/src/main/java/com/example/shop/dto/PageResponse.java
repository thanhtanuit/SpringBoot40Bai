package com.example.shop.dto;

import java.util.List;
import java.util.function.Function;

import org.springframework.data.domain.Page;

/**
 * BẪY 2: KHÔNG trả thẳng Page<T> ra API.
 *  - JSON của Page rườm rà: lồng pageable → sort, offset, unpaged...
 *  - Cấu trúc đó ĐÃ TỪNG ĐỔI giữa các phiên bản Spring Data. Từ Boot 3.3 có hẳn
 *    cảnh báo serialize PageImpl không ổn định. Nâng Spring → JSON đổi → frontend vỡ.
 * Bảy trường phẳng = hợp đồng DO MÌNH kiểm soát. Tinh thần DTO của Bài 4.
 */
public record PageResponse<T>(
        List<T> content,
        int page,
        int size,
        long totalElements,
        int totalPages,
        boolean first,
        boolean last
) {

    public static <E, T> PageResponse<T> from(Page<E> page, Function<E, T> mapper) {
        return new PageResponse<>(
                page.getContent().stream().map(mapper).toList(),
                page.getNumber(),
                page.getSize(),
                page.getTotalElements(),
                page.getTotalPages(),
                page.isFirst(),
                page.isLast());
    }
}
