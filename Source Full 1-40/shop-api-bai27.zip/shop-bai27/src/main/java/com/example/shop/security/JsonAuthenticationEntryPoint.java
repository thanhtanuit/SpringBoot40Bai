package com.example.shop.security;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Bài 23 — món nợ Bài 21: lỗi từ filter chain KHÔNG tới @RestControllerAdvice.
 *
 * 401 "Unauthorized" — tên gọi sai lệch, đúng ra là UNAUTHENTICATED: tôi không biết bạn là ai.
 * Thiếu token, token sai, hết hạn. Client: đăng nhập lại hoặc refresh (Bài 40 tự động).
 */
@Component
public class JsonAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private static final Logger log = LoggerFactory.getLogger(JsonAuthenticationEntryPoint.class);

    private final ObjectMapper objectMapper;

    public JsonAuthenticationEntryPoint(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException ex) throws IOException {
        log.warn("401 {} {} — {}", request.getMethod(), request.getRequestURI(), ex.getMessage());
        ProblemResponses.ghi(objectMapper, request, response, HttpStatus.UNAUTHORIZED,
                "unauthorized", "Chưa xác thực", "Bạn cần đăng nhập để thực hiện thao tác này");
    }
}
