package com.example.shop.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.shop.dto.BestSellerResponse;
import com.example.shop.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    /**
     * JPQL làm việc trên ENTITY và FIELD, không phải bảng và cột:
     * "JOIN oi.product p" đi theo quan hệ khai ở Bài 9 — không cần ON.
     *
     * Constructor expression: tên class ĐẦY ĐỦ, constructor khớp đúng thứ tự và kiểu.
     * SUM trả Long — khai int là lỗi LÚC CHẠY (JPQL chỉ là chuỗi).
     *
     * JPQL không có LIMIT (mỗi DB viết một kiểu) → giới hạn qua Pageable.
     */
    @Query("""
            SELECT new com.example.shop.dto.BestSellerResponse(p.id, p.name, SUM(oi.quantity))
            FROM OrderItem oi
            JOIN oi.product p
            GROUP BY p.id, p.name
            ORDER BY SUM(oi.quantity) DESC
            """)
    List<BestSellerResponse> findBestSellers(Pageable pageable);
}
