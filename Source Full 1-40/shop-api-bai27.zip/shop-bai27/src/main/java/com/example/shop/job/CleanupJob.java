package com.example.shop.job;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.repository.ProductRepository;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

/**
 * Bài 20 — dọn sản phẩm soft-deleted quá 30 ngày (món nợ "bảng phình to" của Bài 16).
 *
 * zone = "Asia/Ho_Chi_Minh" — đặt NGAY TỪ ĐẦU. Không có nó, cron chạy theo múi giờ JVM,
 * mà JVM trong Docker mặc định UTC → job "2 giờ sáng" chạy lúc 9 giờ sáng giờ VN,
 * giữa giờ cao điểm.
 *
 * Cron trong cấu hình: đổi lịch không build lại; "-" để tắt.
 *
 * ShedLock:
 *   lockAtMostFor  — khoá tự hết hạn nếu instance giữ khoá bị kill. Phải DÀI HƠN thời gian
 *                    chạy tối đa, nếu không hai instance chạy chồng.
 *   lockAtLeastFor — giữ khoá tối thiểu dù job xong sớm, chống lệch đồng hồ.
 * Thử: hai instance (8081, 8082), cron "0 * * * * *" → chỉ một instance in log.
 *   SELECT * FROM shedlock;
 */
@Component
public class CleanupJob {

    private static final Logger log = LoggerFactory.getLogger(CleanupJob.class);

    private final ProductRepository repo;

    public CleanupJob(ProductRepository repo) {
        this.repo = repo;
    }

    @Scheduled(cron = "${shop.jobs.cleanup-cron:0 0 2 * * *}", zone = "Asia/Ho_Chi_Minh")
    @SchedulerLock(name = "donBanGhiDaXoa", lockAtLeastFor = "PT1M", lockAtMostFor = "PT15M")
    @Transactional
    public void donBanGhiDaXoa() {
        Instant moc = Instant.now().minus(30, ChronoUnit.DAYS);
        int soDong = repo.hardDeleteOldSoftDeleted(moc);
        log.info("[JOB] Đã xoá vĩnh viễn {} sản phẩm soft-deleted trước {}", soDong, moc);
    }
}
