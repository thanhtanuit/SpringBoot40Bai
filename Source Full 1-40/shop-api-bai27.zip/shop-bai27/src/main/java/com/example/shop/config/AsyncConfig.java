package com.example.shop.config;

import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Bài 20 — pool cho @Async.
 *
 * Thứ tự PHẢN TRỰC GIÁC: core bận hết → task vào HÀNG ĐỢI; chỉ khi hàng đợi ĐẦY mới tạo thêm
 * thread tới max. queueCapacity quá lớn thì maxPoolSize gần như không bao giờ dùng tới.
 *
 * CallerRunsPolicy: pool và hàng đợi đều đầy → chạy NGAY trên thread gọi. Request chậm lại —
 * và chính sự chậm đó là ÁP LỰC NGƯỢC. Mặc định AbortPolicy ném exception và MẤT VIỆC.
 *
 * threadNamePrefix: tên thread trong log là bằng chứng việc đã sang thread khác.
 */
@Configuration
@EnableAsync
public class AsyncConfig implements AsyncConfigurer {

    @Bean("taskExecutor")
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("shop-async-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.setTaskDecorator(new MdcTaskDecorator());
        executor.initialize();
        return executor;
    }

    /** Method @Async trả void mà ném exception → không ai bắt. Ít nhất phải được log. */
    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return (ex, method, params) -> LoggerFactory.getLogger(AsyncConfig.class)
                .error("Lỗi không bắt được trong @Async {}", method.getName(), ex);
    }
}
