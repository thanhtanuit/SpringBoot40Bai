package com.example.shop.security;

import java.io.IOException;
import java.net.URI;
import java.time.Instant;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/** Bài 23 — ghi ProblemDetail thẳng vào response (trong filter chain không có @RestControllerAdvice). */
final class ProblemResponses {

    private static final String TYPE_BASE = "https://shop-api.example.com/errors/";

    private ProblemResponses() {
    }

    static void ghi(ObjectMapper om, HttpServletRequest req, HttpServletResponse res,
                    HttpStatus status, String type, String title, String detail) throws IOException {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, detail);
        pd.setType(URI.create(TYPE_BASE + type));
        pd.setTitle(title);
        pd.setInstance(URI.create(req.getRequestURI()));
        pd.setProperty("timestamp", Instant.now());

        res.setStatus(status.value());
        res.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
        res.setCharacterEncoding("UTF-8");
        om.writeValue(res.getWriter(), pd);
    }
}
