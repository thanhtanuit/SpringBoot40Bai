package com.example.shop.config;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/** Bài 18 — nhóm shop.exchange-rate. "2s", "500ms" tự chuyển thành Duration. */
@Validated
@ConfigurationProperties(prefix = "shop.exchange-rate")
public record ExchangeRateProperties(

        @NotBlank
        String baseUrl,

        @NotNull
        Duration connectTimeout,

        @NotNull
        Duration readTimeout,

        @Positive
        double defaultUsdRate
) {
}
