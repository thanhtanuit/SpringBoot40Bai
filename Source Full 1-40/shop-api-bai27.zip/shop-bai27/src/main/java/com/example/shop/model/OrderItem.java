package com.example.shop.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/** Một dòng hàng trong đơn. Phía CHỦ của quan hệ với Order — giữ khoá ngoại order_id. */
@Entity
@Table(name = "order_item")
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(nullable = false)
    private int quantity;

    /**
     * CHỐT GIÁ lúc mua — SAO CHÉP, không tham chiếu product.getPrice().
     * Đơn hàng là BẢN GHI LỊCH SỬ. Chỉ tham chiếu thì tháng 6 tăng giá,
     * mọi hoá đơn tháng 1 cũng đổi theo: sổ sách sai, khiếu nại không chứng minh được.
     */
    @Column(nullable = false)
    private double unitPrice;

    protected OrderItem() {
    }

    public OrderItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.unitPrice = product.getPrice();
    }

    void setOrder(Order order) {
        this.order = order;
    }

    public double getLineTotal() {
        return unitPrice * quantity;
    }

    public Long getId() {
        return id;
    }

    public Order getOrder() {
        return order;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }
}
