package com.example.shop.config;

import java.time.Duration;

import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;

import com.example.shop.dto.ProductResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Bài 19 — cấu hình Redis cache. Thay ConcurrentMapCacheManager tạm của Bài 18.
 *
 * SERIALIZER JSON: mặc định JdkSerialization — nhị phân không đọc được, buộc
 * implements Serializable. JSON: debug được bằng mắt (redis-cli GET "products::1"),
 * dịch vụ ngôn ngữ khác đọc được.
 *
 * Serializer CỐ ĐỊNH KIỂU cho từng cache — KHÔNG dùng activateDefaultTyping (nhúng tên class
 * vào JSON, từng là nguồn nhiều lỗ hổng deserialization).
 *
 * Cache DTO, KHÔNG cache entity: entity mang proxy lazy, quan hệ, trạng thái Hibernate —
 * không thứ nào nên nằm trong cache.
 *
 * transactionAware(): put/evict chỉ thực hiện SAU KHI transaction commit.
 * BẪY 2: không có nó, @CacheEvict chạy khi method kết thúc nhưng commit xảy ra SAU đó.
 * Request khác đọc đúng khe đó → nạp lại DỮ LIỆU CŨ vào cache tới hết TTL.
 */
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public RedisCacheManagerBuilderCustomizer redisCacheCustomizer(ObjectMapper objectMapper) {
        RedisCacheConfiguration macDinh = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(10))
                .disableCachingNullValues();

        return builder -> builder
                .cacheDefaults(macDinh)
                .withCacheConfiguration("products", macDinh
                        .entryTtl(Duration.ofMinutes(10))
                        .serializeValuesWith(SerializationPair.fromSerializer(
                                new Jackson2JsonRedisSerializer<>(objectMapper, ProductResponse.class))))
                .withCacheConfiguration("exchangeRates", macDinh
                        .entryTtl(Duration.ofHours(1))
                        .serializeValuesWith(SerializationPair.fromSerializer(
                                new Jackson2JsonRedisSerializer<>(objectMapper, Double.class))))
                .transactionAware();
    }
}
