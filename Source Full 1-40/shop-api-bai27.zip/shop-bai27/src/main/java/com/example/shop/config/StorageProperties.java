package com.example.shop.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

/** Bài 17 — nhóm shop.storage. */
@Validated
@ConfigurationProperties(prefix = "shop.storage")
public record StorageProperties(

        @NotBlank
        String location,

        @NotEmpty
        List<String> allowedTypes,

        @NotEmpty
        List<String> allowedExtensions
) {
}
