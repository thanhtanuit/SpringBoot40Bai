package com.example.shop.exception;

/** Bài 22 — refresh token không hợp lệ, hết hạn, hoặc đã thu hồi → 401. */
public class InvalidTokenException extends RuntimeException {

    public InvalidTokenException(String message) {
        super(message);
    }
}
