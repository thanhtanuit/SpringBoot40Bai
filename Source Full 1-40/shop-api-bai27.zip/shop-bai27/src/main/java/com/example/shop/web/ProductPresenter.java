package com.example.shop.web;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.example.shop.dto.ProductResponse;

/**
 * Bài 23 — ẩn dữ liệu theo vai trò. Làm trên DTO (không phải entity) nên áp được cả cho
 * dữ liệu lấy từ cache Redis (Bài 19).
 *
 * LỌC Ở SERVER. Trả đủ rồi để frontend ẩn KHÔNG phải bảo mật — ai cũng mở DevTools xem response.
 *
 * Hướng khác: @JsonView (chọn view động theo vai trò thì vướng); DTO riêng cho từng vai trò
 * (dài dòng nhưng minh bạch nhất — hệ thống lớn thường chọn cách này).
 */
@Component
public class ProductPresenter {

    public ProductResponse present(ProductResponse dto, Authentication auth) {
        return laAdmin(auth) ? dto : dto.anGiaVon();
    }

    public List<ProductResponse> present(List<ProductResponse> ds, Authentication auth) {
        boolean admin = laAdmin(auth);
        return admin ? ds : ds.stream().map(ProductResponse::anGiaVon).toList();
    }

    private boolean laAdmin(Authentication auth) {
        return auth != null && auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
    }
}
