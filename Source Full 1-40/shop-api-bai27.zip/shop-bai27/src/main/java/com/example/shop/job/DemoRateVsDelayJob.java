package com.example.shop.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Bài 20 — THỰC NGHIỆM fixedRate vs fixedDelay. Chỉ chạy với profile "demo-job":
 *   mvn spring-boot:run -Dspring-boot.run.profiles=dev,demo-job
 *
 * Với pool 1 thread (mặc định): cả hai in cách nhau ~3s — GIỐNG NHAU, vì tranh một thread.
 * Với pool 5 (application.yml):
 *   [RATE]  bắt đầu 00:00 → kết thúc 00:03 → bắt đầu NGAY 00:03
 *   [DELAY] bắt đầu 00:00 → kết thúc 00:03 → chờ thêm 1s → bắt đầu 00:04
 * Quan sát xong xoá class này.
 */
@Component
@Profile("demo-job")
public class DemoRateVsDelayJob {

    private static final Logger log = LoggerFactory.getLogger(DemoRateVsDelayJob.class);

    @Scheduled(fixedRate = 1000)
    public void theoRate() throws InterruptedException {
        log.info("[RATE] bắt đầu");
        Thread.sleep(3000);
        log.info("[RATE] kết thúc");
    }

    @Scheduled(fixedDelay = 1000)
    public void theoDelay() throws InterruptedException {
        log.info("[DELAY] bắt đầu");
        Thread.sleep(3000);
        log.info("[DELAY] kết thúc");
    }
}
