package com.example.shop.repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.Nullable;

import com.example.shop.model.Product;

/**
 * Bài 10 — ba bậc viết truy vấn:
 *   1–2 điều kiện cố định          → derived query (tên method)
 *   phức tạp hơn nhưng vẫn cố định → @Query
 *   số điều kiện đổi theo request  → Specification (Bài 15) ← ĐÂY
 *
 * @EntityGraph(attributePaths = "category"): nạp luôn danh mục bằng LEFT JOIN trong
 * câu chính, thay vì LAZY rồi bắn thêm một truy vấn cho TỪNG sản phẩm (N+1).
 * Lấy 5 sản phẩm: KHÔNG có → 7 câu SQL (1 dữ liệu + 1 count + 5 category)
 *                 CÓ       → 2 câu SQL
 * An toàn với @ManyToOne. Với @OneToMany + phân trang → "applying in memory" (Bài 39).
 */
public interface ProductRepository extends JpaRepository<Product, Long>,
                                           JpaSpecificationExecutor<Product> {

    // ===== Bài 8 =====
    boolean existsByNameIgnoreCase(String name);

    boolean existsByNameIgnoreCaseAndIdNot(String name, Long id);

    // ===== Bài 12 =====
    boolean existsBySku(String sku);

    boolean existsBySkuAndIdNot(String sku, Long id);

    // ===== Bài 10: @EntityGraph đè lên method có sẵn, không phải viết JPQL =====
    @Override
    @EntityGraph(attributePaths = "category")
    Page<Product> findAll(Pageable pageable);

    @Override
    @EntityGraph(attributePaths = "category")
    Optional<Product> findById(Long id);

    /** Slice: lấy size + 1 bản ghi để biết còn trang sau — BỎ HẲN câu count. */
    @EntityGraph(attributePaths = "category")
    Slice<Product> findSliceBy(Pageable pageable);

    // ===== Bài 10: derived query — gọi thử rồi ĐỌC SQL trong log =====

    /** LOWER(name) LIKE LOWER('%?%') */
    @EntityGraph(attributePaths = "category")
    List<Product> findByNameContainingIgnoreCase(String keyword);

    /** price BETWEEN ? AND ? */
    @EntityGraph(attributePaths = "category")
    List<Product> findByPriceBetween(double min, double max);

    @EntityGraph(attributePaths = "category")
    List<Product> findByCategoryId(Long categoryId);

    /** SELECT COUNT(*) ... WHERE category_id = ? */
    long countByCategoryId(Long categoryId);

    /*
     * Giới hạn của derived query — đừng làm thế này:
     *   findByNameContainingIgnoreCaseAndPriceBetweenAndCategoryIdAndStockGreaterThanOrderByPriceDesc
     */

    // ===== Bài 15: search(...) với JPQL "IS NULL OR" của Bài 10 đã XOÁ =====

    /**
     * Từ JpaSpecificationExecutor, đè thêm @EntityGraph để nạp category (tránh N+1 như Bài 10).
     *
     * KHÔNG dùng root.fetch(...) trong Specification để nạp — Spring Data dùng CÙNG spec
     * cho câu count, và "fetch" trong câu count là lỗi. @EntityGraph chỉ áp cho câu dữ liệu.
     */
    @Override
    @EntityGraph(attributePaths = "category")
    Page<Product> findAll(@Nullable Specification<Product> spec, Pageable pageable);

    // ===== Bài 16: quản trị xoá mềm =====
    // PHẢI nativeQuery. @SQLRestriction áp ở tầng Hibernate nên JPQL không thoát được:
    // "WHERE p.deleted = true" bằng JPQL thành "deleted = true AND deleted = false" → luôn rỗng.
    // SQL thuần đi thẳng xuống database.

    @Query(value = "SELECT * FROM product WHERE deleted = true ORDER BY updated_at DESC",
           nativeQuery = true)
    List<Product> findDeleted();

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE product SET deleted = false, updated_at = now() WHERE id = :id AND deleted = true",
           nativeQuery = true)
    int restore(@Param("id") Long id);

    // ===== Bài 20 =====

    /**
     * Native vì @SQLRestriction lọc mất dòng deleted = true khi đi qua JPQL.
     * NOT EXISTS: sản phẩm đã nằm trong đơn hàng thì KHÔNG xoá vĩnh viễn được — khoá ngoại
     * order_item.product_id (món nợ "khoá ngoại nói dối" của Bài 16). Thiếu điều kiện này,
     * một dòng vi phạm là cả job rollback.
     */
    @Modifying
    @Query(value = """
            DELETE FROM product p
            WHERE p.deleted = true
              AND p.updated_at < :moc
              AND NOT EXISTS (SELECT 1 FROM order_item oi WHERE oi.product_id = p.id)
            """, nativeQuery = true)
    int hardDeleteOldSoftDeleted(@Param("moc") Instant moc);

    @Query("SELECT COALESCE(SUM(p.stock), 0) FROM Product p")
    Long tongTonKho();
}
