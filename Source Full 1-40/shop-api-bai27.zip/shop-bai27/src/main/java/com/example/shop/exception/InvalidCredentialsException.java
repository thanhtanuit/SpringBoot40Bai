package com.example.shop.exception;

/** Bài 22 — sai username HOẶC mật khẩu → 401. Một thông điệp chung cho cả hai. */
public class InvalidCredentialsException extends RuntimeException {

    public InvalidCredentialsException(String message) {
        super(message);
    }
}
