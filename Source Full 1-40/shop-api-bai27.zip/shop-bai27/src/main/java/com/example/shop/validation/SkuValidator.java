package com.example.shop.validation;

import java.util.regex.Pattern;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator tự viết luôn trả TRUE khi giá trị là null.
 * Bắt buộc có giá trị là việc của @NotBlank — mỗi annotation lo đúng một việc.
 * Muốn SKU vừa bắt buộc vừa đúng định dạng: gắn cả @NotBlank lẫn @ValidSku.
 */
public class SkuValidator implements ConstraintValidator<ValidSku, String> {

    private static final Pattern MAU = Pattern.compile("^[A-Z]{3}-\\d{4}$");

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value == null || MAU.matcher(value).matches();
    }
}
