package com.example.shop.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.model.AuditLog;
import com.example.shop.repository.AuditLogRepository;

/**
 * Bài 13 — REQUIRES_NEW: đơn hàng rollback nhưng VẪN giữ vết "đã thử đặt".
 *
 * Cơ chế: TẠM DỪNG transaction đang chạy → mở transaction MỚI → commit → trả lại cái cũ.
 * Hai transaction độc lập — cái ngoài rollback không kéo cái trong theo.
 *
 * PHẢI là class RIÊNG. Để chung trong OrderService thì gọi qua this
 * → self-invocation → REQUIRES_NEW mất tác dụng.
 *
 * BẪY 3: transaction lồng chiếm HAI connection cùng lúc. Pool 10 (Bài 11),
 * dùng bừa trong vòng lặp → pool cạn, app ĐỨNG HÌNH. Dùng có chọn lọc.
 *
 * REQUIRED (mặc định) phủ 95% trường hợp. SUPPORTS, MANDATORY, NOT_SUPPORTED, NEVER:
 * biết để nhận ra khi đọc code người khác.
 */
@Service
public class AuditService {

    private final AuditLogRepository repo;

    public AuditService(AuditLogRepository repo) {
        this.repo = repo;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void ghi(String action, String entity, Long entityId, String detail) {
        repo.save(new AuditLog(action, entity, entityId, detail));
    }

    @Transactional(readOnly = true)
    public List<AuditLog> ganDay() {
        return repo.findTop20ByOrderByIdDesc();
    }
}
