package com.example.shop.security;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Bài 23 — 403 Forbidden: tôi BIẾT bạn là ai, và câu trả lời là KHÔNG.
 * Client không nên thử lại; đăng nhập lại cũng vô ích → hiện "không đủ quyền".
 */
@Component
public class JsonAccessDeniedHandler implements AccessDeniedHandler {

    private static final Logger log = LoggerFactory.getLogger(JsonAccessDeniedHandler.class);

    private final ObjectMapper objectMapper;

    public JsonAccessDeniedHandler(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
                       AccessDeniedException ex) throws IOException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        log.warn("403 {} {} — user={}", request.getMethod(), request.getRequestURI(),
                auth != null ? auth.getName() : "?");
        ProblemResponses.ghi(objectMapper, request, response, HttpStatus.FORBIDDEN,
                "forbidden", "Không đủ quyền", "Bạn không có quyền thực hiện thao tác này");
    }
}
