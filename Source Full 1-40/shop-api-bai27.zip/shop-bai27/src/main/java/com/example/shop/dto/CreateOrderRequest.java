package com.example.shop.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public record CreateOrderRequest(

        @NotBlank(message = "Tên khách hàng không được để trống")
        @Size(max = 100, message = "Tên khách hàng tối đa {max} ký tự")
        String customerName,

        /*
         * @NotEmpty chỉ bảo đảm danh sách không rỗng.
         * @Valid BẮT BUỘC để validate lan xuống từng phần tử —
         * thiếu nó, quantity = -5 lọt qua hoàn toàn.
         */
        @NotEmpty(message = "Đơn hàng phải có ít nhất một sản phẩm")
        @Valid
        List<OrderItemRequest> items
) {
}
