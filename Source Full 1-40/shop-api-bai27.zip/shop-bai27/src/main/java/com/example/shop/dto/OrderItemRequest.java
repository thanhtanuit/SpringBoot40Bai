package com.example.shop.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record OrderItemRequest(

        @NotNull(message = "Thiếu mã sản phẩm")
        Long productId,

        @NotNull(message = "Thiếu số lượng")
        @Min(value = 1, message = "Số lượng phải từ 1 trở lên")
        Integer quantity
) {
}
