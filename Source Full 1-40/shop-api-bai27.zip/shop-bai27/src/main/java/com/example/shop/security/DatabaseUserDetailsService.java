package com.example.shop.security;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.repository.UserRepository;

/**
 * Bài 21 — Spring Security hỏi "user này là ai", class này đọc từ database.
 *
 * TIỀN TỐ "ROLE_": hasRole("ADMIN") tự thêm tiền tố khi so sánh, hasAuthority("ADMIN") thì không.
 * Lưu authority "ADMIN" rồi dùng hasRole("ADMIN") → LUÔN TỪ CHỐI, không báo lỗi gì.
 *
 * Thông báo CỐ TÌNH MƠ HỒ: nói rõ username nào có thật là cho kẻ tấn công danh sách để dò mật khẩu.
 */
@Service
public class DatabaseUserDetailsService implements UserDetailsService {

    private final UserRepository repo;

    public DatabaseUserDetailsService(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        var user = repo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Không tìm thấy tài khoản"));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword())
                .disabled(!user.isEnabled())
                .authorities(user.getRoles().stream()
                        .map(r -> new SimpleGrantedAuthority("ROLE_" + r.name()))
                        .toList())
                .build();
    }
}
