package com.example.shop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shop.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
