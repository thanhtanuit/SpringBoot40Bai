package com.example.shop.client;

/** 5xx — máy kia có thể vừa quá tải, lần sau có cơ hội thành công. ĐÁNG retry. */
public class ExchangeRateServerException extends RuntimeException {

    public ExchangeRateServerException(String message) {
        super(message);
    }
}
