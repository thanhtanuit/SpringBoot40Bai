package com.example.shop.exception;

import java.net.URI;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.mapping.PropertyReferenceException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.example.shop.storage.InvalidFileException;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Một nơi duy nhất bắt mọi lỗi, áp cho MỌI controller.
 * Response theo chuẩn RFC 7807 (Problem Details) — Content-Type: application/problem+json.
 *
 *   type      URI định danh LOẠI lỗi — frontend dựa vào đây
 *   title     mô tả ngắn của loại lỗi, không đổi
 *   status    trùng mã HTTP
 *   detail    mô tả cụ thể LẦN lỗi này
 *   instance  đường dẫn request gặp lỗi
 *
 * Handler CỤ THỂ luôn thắng handler TỔNG QUÁT: ResourceNotFoundException vào
 * handleNotFound, không rơi xuống handleAll.
 *
 * BẪY 3 — phân mức log:
 *   4xx = client gửi sai, chuyện thường ngày → log.warn, một dòng
 *   500 = hệ thống hỏng, cần người sửa      → log.error, kèm stack trace
 * Ghi mọi thứ ở mức error thì cảnh báo reo liên tục, người trực tắt đi,
 * rồi bỏ lỡ đúng cái lỗi thật.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static final String TYPE_BASE = "https://shop-api.example.com/errors/";

    @ExceptionHandler(ResourceNotFoundException.class)
    public ProblemDetail handleNotFound(ResourceNotFoundException ex, HttpServletRequest req) {
        log.warn("404 {} {} — {}", req.getMethod(), req.getRequestURI(), ex.getMessage());
        ProblemDetail pd = taoProblem(HttpStatus.NOT_FOUND, "not-found",
                "Không tìm thấy tài nguyên", ex.getMessage(), req);
        pd.setProperty("resource", ex.getResource());
        pd.setProperty("resourceId", ex.getId());
        return pd;
    }

    @ExceptionHandler(DuplicateResourceException.class)
    public ProblemDetail handleDuplicate(DuplicateResourceException ex, HttpServletRequest req) {
        log.warn("409 {} {} — {}", req.getMethod(), req.getRequestURI(), ex.getMessage());
        return taoProblem(HttpStatus.CONFLICT, "duplicate",
                "Dữ liệu bị trùng", ex.getMessage(), req);
    }

    /** Bài 13: hai người sửa cùng lúc, người sau thua. */
    @ExceptionHandler(OptimisticLockingFailureException.class)
    public ProblemDetail handleOptimisticLock(OptimisticLockingFailureException ex, HttpServletRequest req) {
        log.warn("409 {} {} — xung đột phiên bản", req.getMethod(), req.getRequestURI());
        return taoProblem(HttpStatus.CONFLICT, "concurrent-modification",
                "Dữ liệu vừa bị thay đổi",
                "Dữ liệu vừa bị thay đổi bởi người khác, vui lòng thử lại", req);
    }

    /**
     * Bài 16: vi phạm ràng buộc DB (ví dụ khôi phục sản phẩm trùng tên đang hoạt động).
     * KHÔNG trả message gốc — chứa tên bảng, tên index (Bài 5).
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ProblemDetail handleIntegrity(DataIntegrityViolationException ex, HttpServletRequest req) {
        log.warn("409 {} {} — vi phạm ràng buộc: {}", req.getMethod(), req.getRequestURI(),
                ex.getMostSpecificCause().getMessage());
        return taoProblem(HttpStatus.CONFLICT, "constraint-violation",
                "Dữ liệu vi phạm ràng buộc", "Dữ liệu xung đột với bản ghi đang có", req);
    }

    /** Bài 17: vượt max-file-size / max-request-size. */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ProblemDetail handleMaxSize(MaxUploadSizeExceededException ex, HttpServletRequest req) {
        log.warn("413 {} {} — file quá lớn", req.getMethod(), req.getRequestURI());
        return taoProblem(HttpStatus.PAYLOAD_TOO_LARGE, "file-too-large",
                "File quá lớn", "File vượt quá dung lượng cho phép (tối đa 2MB)", req);
    }

    /** Bài 17: sai kiểu, sai đuôi, rỗng, đường dẫn lạ. */
    @ExceptionHandler(InvalidFileException.class)
    public ProblemDetail handleInvalidFile(InvalidFileException ex, HttpServletRequest req) {
        log.warn("400 {} {} — file không hợp lệ: {}", req.getMethod(), req.getRequestURI(), ex.getMessage());
        return taoProblem(HttpStatus.BAD_REQUEST, "invalid-file",
                "File không hợp lệ", ex.getMessage(), req);
    }

    /** Bài 9: không đủ hàng — xung đột với trạng thái hiện tại, như trùng tên. */
    @ExceptionHandler(IllegalStateException.class)
    public ProblemDetail handleConflictState(IllegalStateException ex, HttpServletRequest req) {
        log.warn("409 {} {} — {}", req.getMethod(), req.getRequestURI(), ex.getMessage());
        return taoProblem(HttpStatus.CONFLICT, "insufficient-stock",
                "Không đủ hàng", ex.getMessage(), req);
    }

    /**
     * Trạm chặn 2 của Bài 4: validation.
     * putIfAbsent: một trường vi phạm nhiều ràng buộc → chỉ giữ lỗi đầu tiên,
     * người dùng không bị dội nhiều thông báo cho cùng một ô nhập.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(MethodArgumentNotValidException ex, HttpServletRequest req) {
        Map<String, String> errors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(fe -> errors.putIfAbsent(fe.getField(), fe.getDefaultMessage()));

        log.warn("400 {} {} — dữ liệu không hợp lệ: {}", req.getMethod(), req.getRequestURI(), errors.keySet());
        ProblemDetail pd = taoProblem(HttpStatus.BAD_REQUEST, "validation",
                "Dữ liệu không hợp lệ", "Có " + errors.size() + " trường không hợp lệ", req);
        pd.setProperty("errors", errors);
        return pd;
    }

    /**
     * Trạm chặn 1 của Bài 4: Jackson không đọc được body ("price": "abc").
     *
     * BẪY 2: KHÔNG đưa ex.getMessage() ra ngoài. Message gốc của Jackson chứa
     * tên class đầy đủ, package, dòng cột — bản đồ nội bộ cho kẻ tấn công.
     * Chi tiết kỹ thuật chỉ vào log; client nhận câu chung.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ProblemDetail handleUnreadable(HttpMessageNotReadableException ex, HttpServletRequest req) {
        log.warn("400 {} {} — body không đọc được: {}", req.getMethod(), req.getRequestURI(), ex.getMessage());
        return taoProblem(HttpStatus.BAD_REQUEST, "malformed-body",
                "Body không hợp lệ", "Body không đúng định dạng JSON hoặc sai kiểu dữ liệu", req);
    }

    /** GET /api/products/abc — không ép "abc" thành Long cho @PathVariable. */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleTypeMismatch(MethodArgumentTypeMismatchException ex, HttpServletRequest req) {
        log.warn("400 {} {} — tham số '{}' sai kiểu", req.getMethod(), req.getRequestURI(), ex.getName());
        return taoProblem(HttpStatus.BAD_REQUEST, "type-mismatch",
                "Tham số không hợp lệ", "Tham số '" + ex.getName() + "' không đúng kiểu dữ liệu", req);
    }

    /** Bài 10: ?sort=khongTonTai,asc — sắp xếp theo trường không có. */
    @ExceptionHandler(PropertyReferenceException.class)
    public ProblemDetail handleBadSort(PropertyReferenceException ex, HttpServletRequest req) {
        log.warn("400 {} {} — sort không hợp lệ: {}", req.getMethod(), req.getRequestURI(), ex.getPropertyName());
        return taoProblem(HttpStatus.BAD_REQUEST, "invalid-sort",
                "Tham số sắp xếp không hợp lệ", "Không thể sắp xếp theo '" + ex.getPropertyName() + "'", req);
    }

    /**
     * Lưới an toàn: NullPointerException, mất kết nối database, mọi thứ ngoài dự kiến.
     * Client KHÔNG BAO GIỜ thấy stack trace hay tên class.
     */
    @ExceptionHandler(Exception.class)
    public ProblemDetail handleAll(Exception ex, HttpServletRequest req) {
        log.error("500 {} {}", req.getMethod(), req.getRequestURI(), ex);
        return taoProblem(HttpStatus.INTERNAL_SERVER_ERROR, "internal",
                "Lỗi hệ thống", "Đã có lỗi xảy ra. Vui lòng thử lại sau.", req);
    }

    private ProblemDetail taoProblem(HttpStatus status, String type, String title,
                                     String detail, HttpServletRequest req) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, detail);
        pd.setType(URI.create(TYPE_BASE + type));
        pd.setTitle(title);
        pd.setInstance(URI.create(req.getRequestURI()));
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }
}
