package com.example.shop.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

/** Bài 18 — bật @Retryable. */
@Configuration
@EnableRetry
public class RetryConfig {
}
