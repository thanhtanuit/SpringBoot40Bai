package com.example.shop.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.Duration;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.shop.config.JwtProperties;

/**
 * Bài 25 — JwtService không phụ thuộc gì ngoài JwtProperties → test bằng new, không cần mock.
 * Khoá lại những luật an ninh của Bài 22.
 */
@DisplayName("JwtService")
class JwtServiceTest {

    private static final String SECRET = "test-only-secret-key-at-least-32-bytes-long-xx";

    private final JwtService jwt = new JwtService(
            new JwtProperties(SECRET, Duration.ofMinutes(15), Duration.ofDays(7), "shop-api"));

    private final UserDetails admin = User.withUsername("admin").password("x").roles("ADMIN").build();
    private final UserDetails seller = User.withUsername("seller").password("x").roles("SELLER").build();

    @Test
    void should_HopLe_When_TokenVuaCap() {
        String token = jwt.generateToken(admin);

        assertThat(jwt.extractUsername(token)).isEqualTo("admin");
        assertThat(jwt.isValid(token, admin)).isTrue();
    }

    @Test
    void should_KhongHopLe_When_TokenBiSuaMotKyTu() {
        String token = jwt.generateToken(admin);
        // Sửa một ký tự GIỮA phần chữ ký. (Ký tự CUỐI của base64url có thể chỉ mang bit đệm —
        // sửa nó có khi không đổi byte nào, test sẽ xanh sai.)
        int i = token.lastIndexOf('.') + 5;
        char moi = token.charAt(i) == 'A' ? 'B' : 'A';
        String biSua = token.substring(0, i) + moi + token.substring(i + 1);

        assertThat(jwt.isValid(biSua, admin)).isFalse();
    }

    @Test
    void should_KhongHopLe_When_TokenCuaNguoiKhac() {
        String token = jwt.generateToken(seller);

        assertThat(jwt.isValid(token, admin)).isFalse();
    }

    @Test
    void should_KhongHopLe_When_KyBangSecretKhac() {
        JwtService keGiaMao = new JwtService(new JwtProperties(
                "secret-cua-ke-tan-cong-cung-dai-hon-32-byte!!", Duration.ofMinutes(15), Duration.ofDays(7), "shop-api"));

        String tokenGia = keGiaMao.generateToken(admin);

        assertThat(jwt.isValid(tokenGia, admin)).isFalse();
    }

    @Test
    void should_KhongHopLe_When_TokenHetHan() {
        JwtService ttlAm = new JwtService(
                new JwtProperties(SECRET, Duration.ofSeconds(-1), Duration.ofDays(7), "shop-api"));

        String token = ttlAm.generateToken(admin);

        assertThat(jwt.isValid(token, admin)).isFalse();
    }

    @Test
    void should_ChetLucKhoiDong_When_SecretNganHon32Byte() {
        assertThatThrownBy(() -> new JwtService(
                new JwtProperties("qua-ngan", Duration.ofMinutes(15), Duration.ofDays(7), "shop-api")))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("32 byte");
    }
}
