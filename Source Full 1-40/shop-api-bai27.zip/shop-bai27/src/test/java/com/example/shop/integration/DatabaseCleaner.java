package com.example.shop.integration;

import org.springframework.boot.test.context.TestComponent;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Bài 27 — dọn dữ liệu giữa các test.
 *
 * TRUNCATE ... RESTART IDENTITY CASCADE: nhanh hơn DELETE, reset sequence về 1 (viết assertion
 * theo id cụ thể được), CASCADE lo thứ tự khoá ngoại.
 *
 * KHÔNG truncate flyway_schema_history — xoá nó là lần sau Flyway chạy lại toàn bộ và hỏng.
 *
 * Vì sao không dùng @Transactional trên test:
 *  - với RANDOM_PORT, HTTP request chạy ở THREAD KHÁC → không thấy transaction của test,
 *    dữ liệu chuẩn bị sẵn "không tồn tại" với server
 *  - mọi thứ nằm trong một transaction → KHÔNG kiểm chứng được commit/rollback thật (lý do chính của bài)
 */
@TestComponent
public class DatabaseCleaner {

    private final JdbcTemplate jdbc;

    public DatabaseCleaner(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void clean() {
        jdbc.execute("""
                TRUNCATE TABLE order_item, orders, refresh_token, user_role, app_user,
                               product, category, audit_log, shedlock
                RESTART IDENTITY CASCADE
                """);
    }
}
