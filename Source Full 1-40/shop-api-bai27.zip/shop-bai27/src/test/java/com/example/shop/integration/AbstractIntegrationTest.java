package com.example.shop.integration;

import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;

/**
 * Bài 27 — SINGLETON CONTAINER dùng chung cho MỌI class test.
 *
 * KHÔNG dùng @Testcontainers + @Container: cặp đó khởi động/dừng container theo TỪNG CLASS —
 * 10 class là 10 lần khởi động PostgreSQL. Khối static chạy đúng MỘT lần khi class được nạp;
 * container sống tới khi JVM tắt, Ryuk (container phụ của Testcontainers) tự dọn.
 *
 * withReuse(true): giữ container sống GIỮA CÁC LẦN CHẠY. Bật trong ~/.testcontainers.properties:
 *   testcontainers.reuse.enable=true
 * Máy dev: đáng bật. CI: tắt (runner luôn sạch; container sót giữa job là nguồn lỗi khó hiểu).
 *
 * @DynamicPropertySource chạy TRƯỚC khi Spring context khởi tạo, bơm URL/cổng Docker vừa cấp.
 */
@ActiveProfiles("it")
public abstract class AbstractIntegrationTest {

    static final PostgreSQLContainer<?> POSTGRES =
            new PostgreSQLContainer<>("postgres:16-alpine")      // CÙNG phiên bản với docker-compose
                    .withDatabaseName("shop_test")
                    .withUsername("test")
                    .withPassword("test")
                    .withReuse(true);

    /** Nâng cao — Redis thật để test cái bẫy cache của Bài 19. */
    static final GenericContainer<?> REDIS =
            new GenericContainer<>("redis:7-alpine")
                    .withExposedPorts(6379)
                    .withReuse(true);

    static {
        POSTGRES.start();
        REDIS.start();
    }

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
        registry.add("spring.datasource.username", POSTGRES::getUsername);
        registry.add("spring.datasource.password", POSTGRES::getPassword);

        registry.add("spring.data.redis.host", REDIS::getHost);
        registry.add("spring.data.redis.port", () -> REDIS.getMappedPort(6379));
    }
}
