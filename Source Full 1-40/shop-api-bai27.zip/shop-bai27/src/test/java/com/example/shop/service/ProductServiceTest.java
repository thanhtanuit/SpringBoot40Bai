package com.example.shop.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.shop.client.ExchangeRateClient;
import com.example.shop.config.ExchangeRateProperties;
import com.example.shop.dto.UpdateProductRequest;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.repository.OrderItemRepository;
import com.example.shop.repository.ProductRepository;
import com.example.shop.storage.FileStorageService;

/**
 * Bài 25 — unit test tầng service.
 *
 * MockitoExtension tạo mock và tiêm — KHÔNG khởi động Spring context. Cả class chạy dưới
 * 1 giây; @SpringBootTest mất 5–15 giây. Khác biệt này quyết định bạn có chạy test sau
 * MỖI thay đổi hay không.
 *
 * Strict stubs (mặc định): stub mà không dùng tới → UnnecessaryStubbingException. Chỉ stub
 * đúng thứ method thật sự gọi.
 *
 * Kiểm tra HÀNH VI, không phải cách cài đặt: verify(repo).save(...) hợp lý; kiểm thứ tự gọi
 * năm method nội bộ thì test đỏ mỗi lần refactor dù code vẫn đúng.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductService")
class ProductServiceTest {

    @Mock private ProductRepository repo;
    @Mock private OrderItemRepository orderItemRepo;
    @Mock private ProductMapper mapper;
    @Mock private FileStorageService storage;
    @Mock private ExchangeRateClient exchangeRateClient;
    @Mock private ExchangeRateProperties exchangeRateProps;

    @InjectMocks
    private ProductService service;

    @Nested
    @DisplayName("Tạo sản phẩm")
    class TaoSanPham {

        @Test
        void should_LuuSanPham_When_DuLieuHopLe() {
            // Given
            when(repo.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

            // When
            Product ketQua = service.create("Bàn phím", "BPH-0001", 1_250_000, 15);

            // Then
            assertThat(ketQua.getName()).isEqualTo("Bàn phím");
            assertThat(ketQua.getPrice()).isEqualTo(1_250_000);
            assertThat(ketQua.getStock()).isEqualTo(15);
            verify(repo).save(any(Product.class));
        }

        @Test
        void should_ThrowDuplicate_When_TenDaTonTai() {
            when(repo.existsByNameIgnoreCase("Bàn phím")).thenReturn(true);

            assertThatThrownBy(() -> service.create("Bàn phím", "BPH-0001", 1_250_000, 15))
                    .isInstanceOf(DuplicateResourceException.class)
                    .hasMessageContaining("Bàn phím");

            // Không chỉ có exception — còn KHÔNG có tác dụng phụ nào
            verify(repo, never()).save(any());
        }

        @Test
        void should_ThrowDuplicate_When_SkuDaTonTai() {
            when(repo.existsBySku("BPH-0001")).thenReturn(true);

            assertThatThrownBy(() -> service.create("Bàn phím mới", "BPH-0001", 1_250_000, 15))
                    .isInstanceOf(DuplicateResourceException.class)
                    .hasMessageContaining("BPH-0001");

            verify(repo, never()).save(any());
        }

        @Test
        void should_MacDinhStockBangKhong_When_StockLaNull() {
            when(repo.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

            Product ketQua = service.create("Chuột", "CHU-0001", 350_000, null);

            assertThat(ketQua.getStock()).isZero();
        }

        /** ArgumentCaptor: kiểm NỘI DUNG object truyền vào mock, không chỉ "có được gọi". */
        @Test
        void should_LuuDungDuLieu_When_TaoSanPham() {
            when(repo.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

            service.create("Tai nghe", "TAI-0001", 890_000, 25);

            ArgumentCaptor<Product> captor = ArgumentCaptor.forClass(Product.class);
            verify(repo).save(captor.capture());

            Product daLuu = captor.getValue();
            assertThat(daLuu.getName()).isEqualTo("Tai nghe");
            assertThat(daLuu.getSku()).isEqualTo("TAI-0001");
            assertThat(daLuu.getPrice()).isEqualTo(890_000);
            // Khoá lại quyết định thiết kế Bài 8: id do DATABASE cấp, không phải service
            assertThat(daLuu.getId()).isNull();
            assertThat(daLuu.isDeleted()).isFalse();
        }
    }

    @Nested
    @DisplayName("Tìm theo id")
    class TimTheoId {

        @Test
        void should_TraVeSanPham_When_IdTonTai() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));

            assertThat(service.findById(1L)).isSameAs(p);
        }

        @Test
        void should_ThrowNotFound_When_ProductIdMissing() {
            when(repo.findById(9999L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.findById(9999L))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("9999");
        }
    }

    @Nested
    @DisplayName("Cập nhật")
    class CapNhat {

        /**
         * Không stub repo.save — update dùng DIRTY CHECKING (Bài 8), không gọi save.
         * Stub thừa sẽ bị strict stubs báo lỗi — Mockito đang nói cho bạn biết code thật chạy thế nào.
         */
        @Test
        void should_CapNhatThanhCong_When_DoiTenSangTenChuaTonTai() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));

            Product ketQua = service.update(1L, "Bàn phím Pro", "BPH-0001", 1_890_000, 20);

            assertThat(ketQua.getName()).isEqualTo("Bàn phím Pro");
            assertThat(ketQua.getPrice()).isEqualTo(1_890_000);
            assertThat(ketQua.getStock()).isEqualTo(20);
            verify(repo, never()).save(any());
        }

        @Test
        void should_ChoPhepGiuNguyenTen_When_CapNhatChinhNo() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));
            // existsByNameIgnoreCaseAndIdNot("Bàn phím", 1L) — mặc định false: không trùng với chính mình

            assertThatNoException()
                    .isThrownBy(() -> service.update(1L, "Bàn phím", "BPH-0001", 999_000, 15));
        }

        @Test
        void should_ThrowDuplicate_When_DoiTenTrungSanPhamKhac() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));
            when(repo.existsByNameIgnoreCaseAndIdNot("Chuột", 1L)).thenReturn(true);

            assertThatThrownBy(() -> service.update(1L, "Chuột", "BPH-0001", 1, 1))
                    .isInstanceOf(DuplicateResourceException.class);

            assertThat(p.getName()).isEqualTo("Bàn phím");   // entity KHÔNG bị sửa
        }

        @Test
        void should_GoiMapper_When_PatchHopLe() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));
            UpdateProductRequest req = new UpdateProductRequest(null, null, 990_000.0, null);

            service.patch(1L, req);

            verify(mapper).updateFromRequest(req, p);
        }
    }

    @Nested
    @DisplayName("Xoá")
    class Xoa {

        @Test
        void should_XoaSanPham_When_IdTonTai() {
            Product p = new Product("Bàn phím", "BPH-0001", 1_250_000, 15);
            when(repo.findById(1L)).thenReturn(Optional.of(p));

            service.delete(1L);

            verify(repo).delete(p);
        }

        @Test
        void should_ThrowNotFound_When_XoaIdKhongTonTai() {
            when(repo.findById(9999L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.delete(9999L))
                    .isInstanceOf(ResourceNotFoundException.class);

            verify(repo, never()).delete(any());
        }
    }
}
