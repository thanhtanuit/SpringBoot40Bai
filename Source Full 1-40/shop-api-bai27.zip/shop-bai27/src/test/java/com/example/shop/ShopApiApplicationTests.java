package com.example.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Test duy nhất có khởi động Spring — kiểm app lên được. So thời gian với các unit test:
 * vài giây so với vài chục mili giây. Đừng thêm @SpringBootTest vào unit test — mất đi
 * lý do tồn tại của nó.
 */
@SpringBootTest
@ActiveProfiles("test")
class ShopApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
