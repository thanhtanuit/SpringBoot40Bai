package com.example.shop.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.shop.dto.AuthResponse;
import com.example.shop.dto.CreateOrderRequest;
import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.LoginRequest;
import com.example.shop.dto.OrderItemRequest;
import com.example.shop.dto.OrderResponse;
import com.example.shop.dto.ProductResponse;
import com.example.shop.dto.RegisterRequest;
import com.example.shop.dto.UserResponse;
import com.example.shop.repository.OrderRepository;
import com.example.shop.repository.ProductRepository;
import com.example.shop.repository.UserRepository;

/**
 * Bài 27 — kịch bản đầu-cuối qua ĐÚNG đường production:
 * HTTP → filter JWT → controller → service → transaction → Hibernate → PostgreSQL (+ Redis).
 *
 * TestRestTemplate gửi HTTP THẬT tới cổng ngẫu nhiên — đi qua servlet container, header thật,
 * serialize/deserialize hai chiều (thứ MockMvc bỏ qua).
 *
 * @TestMethodOrder(Random): test phụ thuộc thứ tự là test dối trá — xanh máy bạn, đỏ trên CI.
 * Chạy hai lần liên tiếp phải cùng kết quả; đỏ lần hai = DatabaseCleaner còn sót bảng.
 */
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(DatabaseCleaner.class)
@TestMethodOrder(MethodOrderer.Random.class)
@DisplayName("Luồng đặt hàng đầu-cuối")
class OrderFlowIntegrationTest extends AbstractIntegrationTest {

    @Autowired private TestRestTemplate rest;
    @Autowired private DatabaseCleaner cleaner;
    @Autowired private CacheManager cacheManager;
    @Autowired private ProductRepository productRepo;
    @Autowired private OrderRepository orderRepo;
    @Autowired private UserRepository userRepo;
    @Autowired private JdbcTemplate jdbc;

    private String tokenAdmin;
    private String tokenUser;

    @BeforeEach
    void setUp() {
        cleaner.clean();
        // Không dọn cache thì test trước để lại dữ liệu cho test sau
        cacheManager.getCacheNames().forEach(n -> Objects.requireNonNull(cacheManager.getCache(n)).clear());

        tokenAdmin = dangKyVaDangNhap("admin_test", "ADMIN");
        tokenUser = dangKyVaDangNhap("user_test", "USER");
    }

    @Test
    void should_TruTonKhoDung_When_DatHangThanhCong() {
        Long productId = taoSanPham("Bàn phím cơ", "BPH-0001", 1_000_000, 10);
        assertThat(productRepo.findById(productId).orElseThrow().getStock()).isEqualTo(10);

        var req = new CreateOrderRequest("Nguyễn Văn A", List.of(new OrderItemRequest(productId, 3)));
        ResponseEntity<OrderResponse> res = rest.exchange("/api/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenUser)), OrderResponse.class);

        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(res.getHeaders().getLocation()).isNotNull();
        assertThat(res.getBody().totalAmount()).isEqualTo(3_000_000);
        assertThat(res.getBody().items()).hasSize(1);

        // Kiểm TRONG DATABASE — điều @WebMvcTest không làm được
        assertThat(productRepo.findById(productId).orElseThrow().getStock()).isEqualTo(7);
        assertThat(orderRepo.count()).isEqualTo(1);
    }

    /**
     * CHỈ integration test làm được. Bài 25: tồn kho là 8 sau lỗi (Mockito không mô phỏng
     * transaction). Ở đây là 10 — PostgreSQL THẬT SỰ rollback.
     * Thử: tạm bỏ @Transactional khỏi OrderService → test này ĐỎ, đúng cái nó phải bắt.
     */
    @Test
    @DisplayName("Đơn có 1 dòng hết hàng → toàn bộ đơn không được lưu")
    void should_RollbackToanBo_When_MotDongHetHang() {
        Long sp1 = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);
        Long sp2 = taoSanPham("Chuột", "CHU-0001", 300_000, 2);

        var req = new CreateOrderRequest("Nguyễn Văn A", List.of(
                new OrderItemRequest(sp1, 5),      // hợp lệ
                new OrderItemRequest(sp2, 99)));   // hết hàng

        ResponseEntity<String> res = rest.exchange("/api/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenUser)), String.class);

        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(orderRepo.count()).isZero();
        assertThat(productRepo.findById(sp1).orElseThrow().getStock()).isEqualTo(10);
        assertThat(productRepo.findById(sp2).orElseThrow().getStock()).isEqualTo(2);

        // Bài 13: dòng ATTEMPT ghi bằng REQUIRES_NEW — SỐNG SÓT qua rollback của đơn
        Integer attempt = jdbc.queryForObject(
                "SELECT COUNT(*) FROM audit_log WHERE action = 'ATTEMPT'", Integer.class);
        assertThat(attempt).isEqualTo(1);
    }

    @Test
    void should_ChanTruyCap_When_KhongPhaiChuDon() {
        Long productId = taoSanPham("Chuột", "CHU-0001", 300_000, 20);
        Long orderId = datHang(tokenUser, productId, 1);
        String tokenNguoiKhac = dangKyVaDangNhap("user_khac", "USER");

        ResponseEntity<String> res = rest.exchange("/api/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenNguoiKhac)), String.class);

        // Đi qua OrderSecurity THẬT — Bài 26 chỉ mock nó
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }

    @Test
    void should_ChoPhepChuDonVaAdminXem() {
        Long productId = taoSanPham("Chuột", "CHU-0001", 300_000, 20);
        Long orderId = datHang(tokenUser, productId, 1);

        assertThat(rest.exchange("/api/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenUser)), OrderResponse.class).getStatusCode())
                .isEqualTo(HttpStatus.OK);
        assertThat(rest.exchange("/api/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenAdmin)), OrderResponse.class).getStatusCode())
                .isEqualTo(HttpStatus.OK);
    }

    @Test
    void should_GhiCreatedByLaNguoiDangNhap_When_TaoSanPham() {
        Long productId = taoSanPham("Đế tản nhiệt", "DTN-0001", 450_000, 5);

        String createdBy = jdbc.queryForObject(
                "SELECT created_by FROM product WHERE id = ?", String.class, productId);
        assertThat(createdBy).isEqualTo("admin_test");   // Bài 16 + Bài 22
    }

    /**
     * Nâng cao — CÁI BẪY CACHE Bài 19 trên Redis thật.
     * Bỏ @CacheEvict khỏi ProductService.patch → test ĐỎ. Loại lỗi không exception, không log.
     */
    @Test
    void should_TraVeGiaMoi_When_CapNhatSauKhiDaCache() {
        Long id = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);

        var lan1 = rest.getForEntity("/api/products/" + id, ProductResponse.class);
        assertThat(lan1.getBody().price()).isEqualTo(1_000_000);   // → vào cache

        rest.exchange("/api/products/" + id, HttpMethod.PATCH,
                new HttpEntity<>(Map.of("price", 999_000), headers(tokenAdmin)), ProductResponse.class);

        var lan2 = rest.getForEntity("/api/products/" + id, ProductResponse.class);
        assertThat(lan2.getBody().price()).isEqualTo(999_000);
    }

    @Test
    void should_TraVeTonKhoMoi_When_DatHangSauKhiDaCache() {
        Long id = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);
        rest.getForEntity("/api/products/" + id, ProductResponse.class);   // → vào cache

        datHang(tokenUser, id, 4);

        var sau = rest.getForEntity("/api/products/" + id, ProductResponse.class);
        assertThat(sau.getBody().stock()).isEqualTo(6);   // OrderService cũng phải dọn cache
    }

    // ---------- helper ----------

    private HttpHeaders headers(String token) {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        if (token != null) {
            h.setBearerAuth(token);
        }
        return h;
    }

    private String dangKyVaDangNhap(String username, String role) {
        rest.postForEntity("/api/auth/register",
                new RegisterRequest(username, "matkhau12345", username + "@test.local"), UserResponse.class);

        if (!"USER".equals(role)) {
            capQuyen(username, role);
        }

        ResponseEntity<AuthResponse> res = rest.postForEntity("/api/auth/login",
                new LoginRequest(username, "matkhau12345"), AuthResponse.class);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.OK);
        return res.getBody().accessToken();
    }

    /**
     * Không có endpoint cấp quyền ADMIN → JDBC thô. Hợp lý cho chuẩn bị dữ liệu: KHÔNG đi qua
     * logic nghiệp vụ, không tạo phụ thuộc vòng giữa test và thứ đang được test.
     */
    private void capQuyen(String username, String role) {
        Long id = userRepo.findByUsername(username).orElseThrow().getId();
        jdbc.update("INSERT INTO user_role (user_id, role) VALUES (?, ?)", id, role);
    }

    private Long taoSanPham(String ten, String sku, double gia, int ton) {
        var req = new CreateProductRequest(ten, sku, gia, ton);
        ResponseEntity<ProductResponse> res = rest.exchange("/api/products", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenAdmin)), ProductResponse.class);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return res.getBody().id();
    }

    private Long datHang(String token, Long productId, int soLuong) {
        var req = new CreateOrderRequest("Khách test", List.of(new OrderItemRequest(productId, soLuong)));
        ResponseEntity<OrderResponse> res = rest.exchange("/api/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(token)), OrderResponse.class);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return res.getBody().id();
    }
}
