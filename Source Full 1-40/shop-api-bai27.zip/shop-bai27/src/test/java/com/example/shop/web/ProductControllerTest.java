package com.example.shop.web;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.shop.config.SecurityConfig;
import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.ProductResponse;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.security.JsonAccessDeniedHandler;
import com.example.shop.security.JsonAuthenticationEntryPoint;
import com.example.shop.security.JwtService;
import com.example.shop.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Bài 26 — @WebMvcTest test HỢP ĐỒNG HTTP: URL, mã trạng thái, hình dạng JSON, ai được phép.
 *
 * Chỉ nạp tầng web: DispatcherServlet, controller chỉ định, @RestControllerAdvice, Filter,
 * converter JSON. KHÔNG service, repository, datasource, Flyway, cache.
 * → Mọi bean controller cần phải cung cấp: @MockitoBean (mock ĐẶT VÀO Spring context — khác
 *   @Mock rời của Bài 25; thay @MockBean đã deprecated từ Boot 3.4) hoặc @Import bean thật.
 *
 * @Import(SecurityConfig): mặc định @WebMvcTest dùng security TỰ ĐỘNG chứ không phải của bạn.
 * Không import thì test phân quyền SAI LỆCH — và vẫn XANH. Loại sai lệch nguy hiểm nhất.
 *
 * ProductPresenter @Import bản THẬT — để kiểm luôn việc ẩn costPrice theo vai trò.
 *
 * Debug: thêm .andDo(print()) — xem Handler (vào đúng controller không?), Resolved Exception
 * (handler nào bắt?), Body (JSON thật). Chỉ bật khi đang tìm lỗi.
 */
@WebMvcTest(ProductController.class)
@Import({SecurityConfig.class, JsonAuthenticationEntryPoint.class, JsonAccessDeniedHandler.class,
         ProductPresenter.class})
@ActiveProfiles("test")
@DisplayName("ProductController")
class ProductControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;

    @MockitoBean private ProductService service;
    @MockitoBean private ProductMapper mapper;
    @MockitoBean private JwtService jwtService;
    @MockitoBean private UserDetailsService userDetailsService;

    private static ProductResponse dto(Long id, String name, Double costPrice) {
        return new ProductResponse(id, name, "BPH-0001", 1_250_000, 15, "Bàn phím",
                Instant.now(), Instant.now(), costPrice);
    }

    /** ObjectMapper thay chuỗi tay: đổi tên field trong DTO thì KHÔNG compile — thay vì lỗi khó hiểu. */
    private String json(Object o) throws Exception {
        return objectMapper.writeValueAsString(o);
    }

    @Nested
    @DisplayName("GET /api/products/{id}")
    class LayTheoId {

        @Test
        void should_TraVe200VaJson_When_IdTonTai() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "Bàn phím cơ", 875_000.0));

            mockMvc.perform(get("/api/products/1"))
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                    .andExpect(jsonPath("$.id").value(1))
                    .andExpect(jsonPath("$.name").value("Bàn phím cơ"))
                    .andExpect(jsonPath("$.price").value(1_250_000.0))
                    // Ẩn danh → presenter ẩn giá vốn, @JsonInclude(NON_NULL) xoá hẳn khỏi JSON
                    .andExpect(jsonPath("$.costPrice").doesNotExist());
        }

        @Test
        @WithMockUser(roles = "ADMIN")
        void should_HienGiaVon_When_LaAdmin() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "Bàn phím cơ", 875_000.0));

            mockMvc.perform(get("/api/products/1"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.costPrice").value(875_000.0));
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_AnGiaVon_When_LaSeller() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "Bàn phím cơ", 875_000.0));

            mockMvc.perform(get("/api/products/1"))
                    .andExpect(jsonPath("$.costPrice").doesNotExist());
        }

        /** Chỗ @WebMvcTest chứng minh giá trị: GlobalExceptionHandler (Bài 5) biến exception thành ProblemDetail. */
        @Test
        void should_TraVe404_When_KhongTimThay() throws Exception {
            when(service.findResponseById(9999L)).thenThrow(new ResourceNotFoundException("Sản phẩm", 9999L));

            mockMvc.perform(get("/api/products/9999"))
                    .andExpect(status().isNotFound())
                    .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
                    .andExpect(jsonPath("$.title").value("Không tìm thấy tài nguyên"))
                    .andExpect(jsonPath("$.status").value(404))
                    .andExpect(jsonPath("$.detail").value(containsString("9999")))
                    .andExpect(jsonPath("$.instance").value("/api/products/9999"))
                    .andExpect(jsonPath("$.resourceId").value(9999));
        }

        @Test
        void should_TraVe400_When_IdSaiKieu() throws Exception {
            mockMvc.perform(get("/api/products/abc"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.title").value("Tham số không hợp lệ"));
        }
    }

    @Nested
    @DisplayName("POST /api/products")
    class TaoSanPham {

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe201VaLocation_When_DuLieuHopLe() throws Exception {
            var req = new CreateProductRequest("Chuột", "CHU-0001", 350_000.0, 40);
            var product = new Product("Chuột", "CHU-0001", 350_000, 40);
            when(service.create(anyString(), anyString(), anyDouble(), any())).thenReturn(product);
            when(mapper.toResponse(product)).thenReturn(dto(5L, "Chuột", null));

            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json(req)))
                    .andExpect(status().isCreated())
                    .andExpect(header().exists("Location"))
                    .andExpect(jsonPath("$.id").value(5));
        }

        /**
         * Chỉ @WebMvcTest làm được: @Valid là cơ chế TẦNG WEB — gọi thẳng service.create() ở
         * Bài 25 thì không validate nào chạy.
         */
        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe400VaLietKeField_When_DuLieuSai() throws Exception {
            String body = """
                    { "name": "A", "sku": "sai-dinh-dang", "price": -5, "stock": -1 }
                    """;

            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(body))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.title").value("Dữ liệu không hợp lệ"))
                    .andExpect(jsonPath("$.errors.name").exists())
                    .andExpect(jsonPath("$.errors.sku").value("SKU phải có dạng ABC-1234"))
                    .andExpect(jsonPath("$.errors.price").value("Giá phải lớn hơn 0"))
                    .andExpect(jsonPath("$.errors.stock").exists());

            // Bị chặn TRƯỚC KHI chạm tới service
            verify(service, never()).create(any(), any(), anyDouble(), any());
        }

        /** JSON cố tình SAI thì text block là đúng công cụ. */
        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe400_When_BodyHong() throws Exception {
            String bodyHong = """
                    { "name": "X", "sku": "XXX-0001", "price": "khong-phai-so" }
                    """;

            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(bodyHong))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.title").value("Body không hợp lệ"))
                    // Bài 5: KHÔNG lộ tên class Java
                    .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.not(containsString("java"))));
        }

        @Test
        @WithMockUser(roles = "SELLER")
        void should_TraVe409_When_TenTrung() throws Exception {
            when(service.create(anyString(), anyString(), anyDouble(), any()))
                    .thenThrow(new DuplicateResourceException("Đã tồn tại sản phẩm tên: Chuột"));

            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json(new CreateProductRequest("Chuột", "CHU-0001", 350_000.0, 40))))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.title").value("Dữ liệu bị trùng"));
        }
    }

    /**
     * Ma trận quyền Bài 23 trở thành TEST THẬT. Bảo mật là chỗ dễ vô tình nới lỏng nhất khi
     * refactor — một requestMatchers sai thứ tự là cả hệ thống mở toang mà không ai biết.
     *
     * @WithMockUser(roles = "USER") TỰ THÊM "ROLE_". Viết roles = "ROLE_USER" thành ROLE_ROLE_USER.
     * Authority thô: authorities = "...".
     */
    @Nested
    @DisplayName("Phân quyền")
    class PhanQuyen {

        private final CreateProductRequest req = new CreateProductRequest("X", "XXX-0001", 1000.0, 1);

        @Test
        void should_TraVe200_When_GETKhongCanDangNhap() throws Exception {
            when(service.findResponseById(1L)).thenReturn(dto(1L, "X", null));

            mockMvc.perform(get("/api/products/1")).andExpect(status().isOk());
        }

        @Test
        void should_TraVe401ProblemDetail_When_POSTKhongDangNhap() throws Exception {
            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json(req)))
                    .andExpect(status().isUnauthorized())
                    .andExpect(content().contentType(MediaType.APPLICATION_PROBLEM_JSON))
                    .andExpect(jsonPath("$.title").value("Chưa xác thực"));
        }

        @Test
        @WithMockUser(roles = "USER")
        void should_TraVe403ProblemDetail_When_USERGoiPOST() throws Exception {
            mockMvc.perform(post("/api/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json(req)))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.title").value("Không đủ quyền"));

            verify(service, never()).create(any(), any(), anyDouble(), any());
        }

        @Test
        @WithMockUser(roles = "USER")
        void should_TraVe403_When_USERGoiPATCH() throws Exception {
            mockMvc.perform(patch("/api/products/1")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{ \"price\": 1 }"))
                    .andExpect(status().isForbidden());
        }

        /**
         * Cả ma trận DELETE gọn bằng @ParameterizedTest. @WithMockUser là annotation nên không
         * nhận tham số — dùng .with(user(...).roles(role)).
         */
        @ParameterizedTest(name = "{0} gọi DELETE → {1}")
        @CsvSource({
                "USER,   403",
                "SELLER, 403",
                "ADMIN,  204"
        })
        void should_PhanQuyenDung_When_GoiDELETE(String role, int ma) throws Exception {
            mockMvc.perform(delete("/api/products/1").with(user("test").roles(role)))
                    .andExpect(status().is(ma));
        }

        @Test
        void should_TraVe401_When_DELETEKhongDangNhap() throws Exception {
            mockMvc.perform(delete("/api/products/1"))
                    .andExpect(status().isUnauthorized());

            verify(service, never()).delete(any());
        }

        @ParameterizedTest(name = "{0} gọi POST → {1}")
        @CsvSource({
                "USER,   403",
                "SELLER, 201",
                "ADMIN,  201"
        })
        void should_PhanQuyenDung_When_GoiPOST(String role, int ma) throws Exception {
            var product = new Product("X", "XXX-0001", 1000, 1);
            when(service.create(anyString(), anyString(), anyDouble(), any())).thenReturn(product);
            when(mapper.toResponse(any())).thenReturn(dto(9L, "X", null));

            mockMvc.perform(post("/api/products")
                            .with(user("test").roles(role))
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json(req)))
                    .andExpect(status().is(ma));
        }
    }
}
