package com.example.shop.web;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Instant;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.shop.config.SecurityConfig;
import com.example.shop.dto.OrderResponse;
import com.example.shop.mapper.OrderMapper;
import com.example.shop.model.Order;
import com.example.shop.security.JsonAccessDeniedHandler;
import com.example.shop.security.JsonAuthenticationEntryPoint;
import com.example.shop.security.JwtService;
import com.example.shop.security.OrderSecurity;
import com.example.shop.service.AuditService;
import com.example.shop.service.OrderService;

/**
 * Bài 26 — quyền sở hữu. OrderSecurity bị MOCK → logic bên trong nó KHÔNG được test ở đây;
 * nó cần test riêng, hoặc tốt hơn integration test với dữ liệu thật (Bài 27).
 *
 * name = "orderSecurity": SpEL "@orderSecurity" tìm bean theo TÊN.
 */
@WebMvcTest(OrderController.class)
@Import({SecurityConfig.class, JsonAuthenticationEntryPoint.class, JsonAccessDeniedHandler.class})
@ActiveProfiles("test")
@DisplayName("OrderController")
class OrderControllerTest {

    @Autowired private MockMvc mockMvc;

    @MockitoBean private OrderService service;
    @MockitoBean private AuditService auditService;
    @MockitoBean private OrderMapper mapper;
    @MockitoBean(name = "orderSecurity") private OrderSecurity orderSecurity;
    @MockitoBean private JwtService jwtService;
    @MockitoBean private UserDetailsService userDetailsService;

    @Test
    @WithMockUser(username = "user1", roles = "USER")
    void should_TraVe200_When_LaChuDon() throws Exception {
        when(orderSecurity.isOwner(eq(1L), any())).thenReturn(true);
        Order order = new Order("User Một");
        when(service.findById(1L)).thenReturn(order);
        when(mapper.toResponse(order)).thenReturn(
                new OrderResponse(1L, "User Một", 350_000, Instant.now(), List.of()));

        mockMvc.perform(get("/api/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customerName").value("User Một"));
    }

    @Test
    @WithMockUser(username = "user2", roles = "USER")
    void should_TraVe403_When_KhongPhaiChuDon() throws Exception {
        when(orderSecurity.isOwner(eq(1L), any())).thenReturn(false);

        mockMvc.perform(get("/api/orders/1"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.title").value("Không đủ quyền"));

        verify(service, never()).findById(any());
    }

    @Test
    void should_TraVe401_When_KhongDangNhap() throws Exception {
        mockMvc.perform(get("/api/orders/1"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(roles = "USER")
    void should_TraVe400_When_DonKhongCoDong() throws Exception {
        mockMvc.perform(post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                { "customerName": "A", "items": [] }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.items").value("Đơn hàng phải có ít nhất một sản phẩm"));
    }

    /** @Valid trên List (Bài 9) — thiếu thì quantity âm lọt qua. */
    @Test
    @WithMockUser(roles = "USER")
    void should_TraVe400_When_SoLuongAm() throws Exception {
        mockMvc.perform(post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                { "customerName": "A", "items": [ { "productId": 1, "quantity": -5 } ] }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors['items[0].quantity']").exists());

        verify(service, never()).datHang(any());
    }
}
