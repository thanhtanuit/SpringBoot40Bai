# shop-api — trạng thái sau Bài 27: Integration test với Testcontainers

> Loại test duy nhất chứng minh được thứ Bài 25, 26 không với tới: **transaction có rollback
> thật không, migration có chạy được không, truy vấn có đúng trên PostgreSQL không**.

## Chạy

```bash
mvn test       # unit + @WebMvcTest — nhanh, KHÔNG cần Docker
mvn verify     # + mọi *IntegrationTest — cần Docker Desktop đang chạy
```

Tăng tốc máy dev — `~/.testcontainers.properties`:
```properties
testcontainers.reuse.enable=true
```
Lần đầu ~8 giây khởi động container, các lần sau gần như tức thì. Tắt trên CI.

## Test mới

```
src/test/
├── java/com/example/shop/integration/
│   ├── AbstractIntegrationTest.java          singleton PostgreSQL 16 + Redis 7
│   ├── DatabaseCleaner.java                  TRUNCATE ... RESTART IDENTITY CASCADE
│   ├── OrderFlowIntegrationTest.java         đầu-cuối, rollback thật, quyền sở hữu thật, cache Redis
│   └── ProductRepositoryIntegrationTest.java @DataJpaTest: 15 migration, soft delete, partial index
└── resources/application-it.yml              validate + Flyway bật
```

## Hai profile test

| Profile | DB | Dùng cho |
|---|---|---|
| `test` | H2, `create-drop`, Flyway tắt | Smoke test, `@WebMvcTest` — không cần Docker |
| `it` | PostgreSQL container, `validate`, **Flyway bật** | `*IntegrationTest` |

## So với Bài 25

| | Bài 25 (Mockito) | Bài 27 (PostgreSQL) |
|---|---|---|
| Tồn kho sau đơn có dòng hết hàng | **8** — không có transaction | **10** — rollback thật |

## Kim tự tháp test

| Loại | Thời gian | Số lượng |
|---|---|---|
| Unit (Bài 25) | ~50ms/test | Nhiều nhất |
| `@WebMvcTest` (Bài 26) | ~150ms/test | Vừa |
| Testcontainers | ~300ms/test + ~10s khởi động | **Ít nhất** — luồng quan trọng |

Viết integration test khi câu hỏi liên quan **sự phối hợp nhiều tầng**: transaction, migration,
phân quyền đầu-cuối, cache. Logic thuần → unit test.

## Bẫy

| Bẫy | |
|---|---|
| `@Testcontainers` + `@Container` mỗi class | Khởi động PostgreSQL lại cho từng class |
| `@DataJpaTest` thiếu `replace = NONE` | Lặng lẽ chạy trên H2 |
| `@Transactional` trên test + `RANDOM_PORT` | Server ở thread khác không thấy dữ liệu; không test được commit |
| Truncate `flyway_schema_history` | Flyway chạy lại và hỏng |
| Quên dọn cache giữa test | Test trước để dữ liệu cho test sau |

Bài 28: OpenAPI và Swagger UI.
