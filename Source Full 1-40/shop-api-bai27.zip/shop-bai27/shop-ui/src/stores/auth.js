import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { api } from '../api/client'

// localStorage: miễn nhiễm CSRF nhưng dễ bị đánh cắp qua XSS.
// Cookie HttpOnly + SameSite an toàn hơn trước XSS nhưng phải bật lại CSRF (Bài 21).
// Không có lựa chọn hoàn hảo — biết mình đang chọn gì là đủ.
export const useAuthStore = defineStore('auth', () => {
  const accessToken = ref(localStorage.getItem('accessToken'))
  const refreshToken = ref(localStorage.getItem('refreshToken'))
  const user = ref(null)

  const isLoggedIn = computed(() => !!accessToken.value)
  const isAdmin = computed(() => user.value?.roles?.includes('ADMIN') ?? false)
  const canEdit = computed(() =>
    user.value?.roles?.some((r) => r === 'ADMIN' || r === 'SELLER') ?? false)

  function setTokens(access, refresh) {
    accessToken.value = access
    refreshToken.value = refresh
    localStorage.setItem('accessToken', access)
    localStorage.setItem('refreshToken', refresh)
  }

  async function login(username, password) {
    const res = await api.post('/auth/login', { username, password })
    setTokens(res.data.accessToken, res.data.refreshToken)
    await loadMe()
  }

  async function loadMe() {
    if (!localStorage.getItem('accessToken')) return
    const res = await api.get('/auth/me')
    user.value = res.data
  }

  async function logout() {
    const rt = localStorage.getItem('refreshToken')
    if (rt) {
      try { await api.post('/auth/logout', { refreshToken: rt }) } catch { /* bỏ qua */ }
    }
    accessToken.value = null
    refreshToken.value = null
    user.value = null
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
  }

  return { accessToken, refreshToken, user, isLoggedIn, isAdmin, canEdit, login, loadMe, logout, setTokens }
})
