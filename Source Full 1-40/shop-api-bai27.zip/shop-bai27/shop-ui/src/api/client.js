import axios from 'axios'

// Mặc định gọi thẳng backend khác origin → CORS. Dùng proxy Vite: VITE_API_URL=/api
const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8081/api'

export const api = axios.create({ baseURL: BASE_URL, timeout: 10000 })

// Gắn token vào mọi request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Tự refresh khi gặp 401
let dangRefresh = null

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config

    // _daThu: refresh xong vẫn 401 thì KHÔNG thử lại — chặn vòng lặp vô hạn
    if (error.response?.status !== 401 || original._daThu) {
      return Promise.reject(error)
    }
    // 401 từ chính /auth/login (sai mật khẩu) KHÔNG phải token hết hạn
    if (original.url.includes('/auth/')) {
      return Promise.reject(error)
    }
    original._daThu = true

    try {
      // GỘP mọi lần refresh đồng thời vào MỘT lời gọi.
      // Không có: 5 request cùng 401 → 5 lần refresh → với xoay vòng token (Bài 22), 4 lần
      // sau dùng token đã thu hồi → server THU HỒI TOÀN BỘ PHIÊN → người dùng bị đá ra.
      dangRefresh ??= axios
        .post(`${BASE_URL}/auth/refresh`, { refreshToken: localStorage.getItem('refreshToken') })
        .finally(() => { dangRefresh = null })

      const res = await dangRefresh
      localStorage.setItem('accessToken', res.data.accessToken)
      localStorage.setItem('refreshToken', res.data.refreshToken)

      original.headers.Authorization = `Bearer ${res.data.accessToken}`
      return api(original)
    } catch (e) {
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
      window.location.href = '/login'
      return Promise.reject(e)
    }
  },
)

// Lỗi ProblemDetail (Bài 5) có trường detail — một đoạn code xử lý mọi lỗi
export function thongBaoLoi(e, macDinh = 'Đã có lỗi xảy ra') {
  const data = e.response?.data
  if (data?.errors) {
    return Object.entries(data.errors).map(([k, v]) => `${k}: ${v}`).join(' · ')
  }
  return data?.detail ?? e.message ?? macDinh
}
