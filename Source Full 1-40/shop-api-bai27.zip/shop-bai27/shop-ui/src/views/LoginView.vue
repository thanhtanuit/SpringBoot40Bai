<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { thongBaoLoi } from '../api/client'

const auth = useAuthStore()
const router = useRouter()
const username = ref('')
const password = ref('')
const loi = ref(null)
const dangTai = ref(false)

async function submit() {
  loi.value = null
  dangTai.value = true
  try {
    await auth.login(username.value, password.value)
    router.push('/')
  } catch (e) {
    // e.response.data.detail — trường "detail" của ProblemDetail (Bài 5)
    loi.value = thongBaoLoi(e, 'Đăng nhập thất bại')
  } finally {
    dangTai.value = false
  }
}

function dien(u, p) {
  username.value = u
  password.value = p
}
</script>

<template>
  <section class="card">
    <h1>Đăng nhập</h1>
    <form @submit.prevent="submit">
      <input v-model="username" placeholder="Tên đăng nhập" autocomplete="username" />
      <input v-model="password" type="password" placeholder="Mật khẩu" autocomplete="current-password" />
      <button :disabled="dangTai">{{ dangTai ? 'Đang xử lý...' : 'Đăng nhập' }}</button>
      <p v-if="loi" class="loi">{{ loi }}</p>
    </form>
    <p class="goi-y">
      Tài khoản mẫu:
      <a href="#" @click.prevent="dien('user1', 'user12345')">user1</a> ·
      <a href="#" @click.prevent="dien('seller', 'seller12345')">seller</a> ·
      <a href="#" @click.prevent="dien('admin', 'admin12345')">admin</a>
    </p>
  </section>
</template>
