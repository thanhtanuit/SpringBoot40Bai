<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from './stores/auth'

const auth = useAuthStore()
const router = useRouter()

onMounted(() => auth.loadMe().catch(() => {}))

async function dangXuat() {
  await auth.logout()
  router.push('/login')
}
</script>

<template>
  <header>
    <RouterLink to="/" class="logo">shop-ui</RouterLink>
    <nav>
      <template v-if="auth.user">
        <span>{{ auth.user.username }} · {{ auth.user.roles.join(', ') }}</span>
        <button class="phu" @click="dangXuat">Đăng xuất</button>
      </template>
      <RouterLink v-else to="/login">Đăng nhập</RouterLink>
    </nav>
  </header>
  <main>
    <RouterView />
  </main>
</template>
