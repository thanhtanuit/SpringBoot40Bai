# shop-api — trạng thái sau Bài 20: Tác vụ nền (hết Phần 2)

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V10 (shedlock)
```

Log có thêm tên thread `[shop-sched-1]`, `[shop-async-1]`, `[http-nio-8081-exec-1]`.

## Thay đổi so với Bài 19

| | |
|---|---|
| `pom.xml` | + `shedlock-spring`, `shedlock-provider-jdbc-template` |
| `V10__create_shedlock.sql` | Bảng khoá |
| `application.yml` | Scheduler pool 5, `shop.jobs.cleanup-cron`, pattern log có `%t` |
| `config/SchedulingConfig`, `AsyncConfig`, `MdcTaskDecorator`, `ShedLockConfig` | |
| `job/OrderStatsJob` | `fixedDelay` mỗi phút |
| `job/CleanupJob` | cron + `zone` + `@SchedulerLock` — xoá cứng soft-deleted > 30 ngày |
| `job/DemoRateVsDelayJob` | Profile `demo-job` — thực nghiệm rồi xoá |
| `service/NotificationService` | `@Async` giả lập gửi email 3s |
| `service/AsyncQueryService`, `web/DashboardController` | `CompletableFuture` song song |
| `OrderService` | Gọi thông báo async sau khi lưu |

## Bẫy

| Bẫy | |
|---|---|
| Scheduler mặc định **1 thread** | Một job chậm làm trễ mọi job |
| Cron chép từ crontab | Spring 6 trường, Unix 5 |
| Không đặt `zone` | Docker = UTC → "2 giờ sáng" chạy lúc 9 giờ sáng |
| `@Async` + `@Transactional` | Transaction không lan sang thread mới — gốc rollback, việc async vẫn commit |
| Truyền entity qua `@Async` | `LazyInitializationException` — chỉ truyền ID |
| Quên `TaskDecorator` | Log async mất `requestId` (nợ từ Bài 7) |
| `AbortPolicy` mặc định | Pool đầy là **mất việc** — dùng `CallerRunsPolicy` |
| Nhiều instance không ShedLock | Job chạy nhiều lần |

## Hết Phần 2

PostgreSQL trong Docker · Flyway · transaction đúng ranh giới · MapStruct · Specification ·
audit + soft delete · upload an toàn · gọi API ngoài có timeout/retry/fallback · cache Redis ·
tác vụ nền có khoá phân tán.

**Nhưng toàn bộ API vẫn mở toang** — kể cả `/api/admin/**`. Bài 21 đóng nó lại, và mọi
endpoint sẽ trả 401. Đó là chuyện bình thường — đừng tắt bảo mật đi cho dễ.
