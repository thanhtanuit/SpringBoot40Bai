# shop-api — trạng thái sau Bài 3: Tách tầng Service và Dependency Injection

## Chạy

```bash
mvn spring-boot:run
```

Cổng 8081. Log khởi động có dòng:
`ProductService đang dùng repository: InMemoryProductRepository`

Chạy lại `requests.http` của Bài 2 — kết quả phải **y hệt**.

## Cấu trúc

```
src/main/java/com/example/shop/
├── ShopApiApplication.java
├── model/
│   └── Product.java                     chuyển từ web sang
├── repository/
│   ├── ProductRepository.java           interface, tên trùng JpaRepository
│   ├── InMemoryProductRepository.java   @Repository @Primary
│   └── FakeProductRepository.java       bản thứ hai, cho thí nghiệm DI
├── service/
│   └── ProductService.java              luật "không trùng tên", @PostConstruct
└── web/
    ├── HelloController.java             Bài 1
    ├── KetQua.java                      Bài 1
    ├── PriceUpdate.java                 Bài 2
    └── ProductController.java           chỉ gọi service
```

Controller → Service → Repository. Controller **không bao giờ** gọi thẳng Repository.

## Thí nghiệm

**Hai bean cùng kiểu:** xoá `@Primary` trong `InMemoryProductRepository` → app chết lúc
khởi động: *expected single matching bean but found 2*. Gắn lại `@Primary`.

**Chỉ định bằng @Qualifier:** trong constructor của `ProductService`:

```java
public ProductService(@Qualifier("fakeProductRepository") ProductRepository repo)
```

Log đổi thành `FakeProductRepository`, `GET /api/products` ra hai sản phẩm demo.
Xong nhớ bỏ `@Qualifier`.

**Singleton và prototype:** tạm thêm class `@Component @Scope("prototype") PrototypeDemo`,
xin Spring hai lần mỗi bean và in `hashCode()` — hai mã của `ProductService` luôn bằng
nhau, của `PrototypeDemo` luôn khác nhau. Quan sát xong xoá đi.

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| `@Autowired` trên field | Tiêm qua constructor |
| Hai bean cùng interface | `@Primary` hoặc `@Qualifier` |
| Dữ liệu request trong field của singleton | Không bao giờ — mọi người dùng chung một object |
