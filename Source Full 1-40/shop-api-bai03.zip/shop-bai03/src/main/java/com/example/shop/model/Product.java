package com.example.shop.model;

/**
 * Sản phẩm. Bài 3 chuyển từ package web sang model — nó không còn là
 * chuyện riêng của tầng web nữa. Bài 8 sẽ đổi thành @Entity.
 */
public record Product(Long id, String name, double price) {
}
