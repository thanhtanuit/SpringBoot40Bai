package com.example.shop.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.shop.model.Product;
import com.example.shop.repository.ProductRepository;

import jakarta.annotation.PostConstruct;

/**
 * Tầng nghiệp vụ: nơi giữ luật của cửa hàng.
 *
 * BẪY 1: tiêm qua CONSTRUCTOR, không dùng @Autowired trên field.
 *  - field final, không ai đổi được sau khi tạo
 *  - object luôn hợp lệ, repo không bao giờ null
 *  - test được bằng new ProductService(repoGia) — Bài 25
 *  - constructor phình ra là tín hiệu class ôm quá nhiều việc
 * Class chỉ có một constructor thì không cần annotation gì.
 *
 * BẪY 3: bean mặc định là SINGLETON. Không bao giờ để dữ liệu riêng của
 * từng request vào field — người A ghi, người B đọc được.
 */
@Service
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    /** Chạy một lần ngay sau khi Spring tạo xong bean — in ra repo thực sự được tiêm. */
    @PostConstruct
    void logRepoDangDung() {
        log.info("ProductService đang dùng repository: {}", repo.getClass().getSimpleName());
    }

    public List<Product> findAll() {
        return repo.findAll();
    }

    public Optional<Product> findById(Long id) {
        return repo.findById(id);
    }

    public Product create(String name, double price) {
        kiemTraTrungTen(name, null);
        return repo.save(new Product(null, name, price));
    }

    public Optional<Product> update(Long id, String name, double price) {
        if (repo.findById(id).isEmpty()) {
            return Optional.empty();
        }
        kiemTraTrungTen(name, id);
        return Optional.of(repo.save(new Product(id, name, price)));
    }

    public Optional<Product> updatePrice(Long id, double price) {
        return repo.findById(id)
                .map(cu -> repo.save(new Product(cu.id(), cu.name(), price)));
    }

    public boolean delete(Long id) {
        if (repo.findById(id).isEmpty()) {
            return false;
        }
        repo.deleteById(id);
        return true;
    }

    /**
     * Luật nghiệp vụ đầu tiên: không cho hai sản phẩm trùng tên (không phân biệt hoa thường).
     * Khi sửa, loại chính sản phẩm đang sửa ra khỏi phép kiểm tra.
     *
     * Hiện ném IllegalArgumentException → client nhận 500. Exception đã ném ĐÚNG CHỖ,
     * chỉ là chưa ai dịch nó thành mã trạng thái tử tế. Bài 5 sẽ biến thành 409.
     */
    private void kiemTraTrungTen(String name, Long boQuaId) {
        boolean trung = repo.findAll().stream()
                .anyMatch(p -> p.name() != null
                        && p.name().equalsIgnoreCase(name)
                        && !p.id().equals(boQuaId));
        if (trung) {
            throw new IllegalArgumentException("Đã tồn tại sản phẩm tên: " + name);
        }
    }
}
