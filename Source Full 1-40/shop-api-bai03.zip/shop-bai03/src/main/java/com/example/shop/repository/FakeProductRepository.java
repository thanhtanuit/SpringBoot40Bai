package com.example.shop.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.example.shop.model.Product;

/**
 * Bản cài đặt thứ hai của CÙNG interface — dùng cho thí nghiệm DI.
 * Trả về hai sản phẩm demo cố định, không cho ghi.
 *
 * Muốn dùng bản này: trong constructor của ProductService thêm
 *   @Qualifier("fakeProductRepository")
 * Không sửa dòng logic nào mà nguồn dữ liệu đổi hẳn. Xong nhớ trả về như cũ.
 */
@Repository("fakeProductRepository")
public class FakeProductRepository implements ProductRepository {

    private static final List<Product> DEMO = List.of(
            new Product(1L, "Sản phẩm demo A", 100000),
            new Product(2L, "Sản phẩm demo B", 200000));

    @Override
    public List<Product> findAll() {
        return DEMO;
    }

    @Override
    public Optional<Product> findById(Long id) {
        return DEMO.stream().filter(p -> p.id().equals(id)).findFirst();
    }

    @Override
    public Product save(Product product) {
        throw new UnsupportedOperationException("FakeProductRepository chỉ đọc");
    }

    @Override
    public void deleteById(Long id) {
        throw new UnsupportedOperationException("FakeProductRepository chỉ đọc");
    }
}
