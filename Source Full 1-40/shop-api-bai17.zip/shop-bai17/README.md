# shop-api — trạng thái sau Bài 17: Upload và download file

> Hai lỗ hổng bảo mật kinh điển ẩn trong một tính năng trông vô hại.

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V9
```

File mẫu trong `test-files/`: `anh.png`, `tailieu.pdf` (→ 400), `lon.png` 3MB (→ 413).

```bash
curl -F "file=@test-files/anh.png" http://localhost:8081/api/products/1/image
curl -o tai-ve.png http://localhost:8081/api/products/1/image
curl -F "file=@test-files/tailieu.pdf" http://localhost:8081/api/products/1/image   # 400
curl -F "file=@test-files/lon.png"     http://localhost:8081/api/products/1/image   # 413

# Tấn công path traversal — tự thấy phòng thủ hoạt động
curl -F 'file=@test-files/anh.png;filename=../../../tmp/hack.png' \
     http://localhost:8081/api/products/1/image
ls /tmp/hack.png            # không có gì
ls uploads/                 # tên UUID
```

## Thay đổi so với Bài 16

| | |
|---|---|
| `V9__add_product_image.sql` | Cột `image_path` — lưu **tên**, không lưu đường dẫn |
| `application.yml` | `multipart` 2MB/10MB, `shop.storage` whitelist |
| `config/StorageProperties.java` | |
| `storage/FileStorageService.java` | **Interface** — thay bằng S3 không đụng controller |
| `storage/LocalFileStorage.java` | UUID + kiểm tra đường dẫn cuối cùng |
| `web/ProductImageController.java` | POST, POST /batch, GET, DELETE |
| `ProductService` | `capNhatAnh`, `xoaAnh` |
| `ProductMapper` | + ignore `imagePath` (ERROR policy bắt buộc) |
| `GlobalExceptionHandler` | + 413, + `InvalidFileException` 400 |

## Hai lỗ hổng

| Lỗ hổng | Phòng thủ |
|---|---|
| **Path traversal** — `root.resolve(originalFilename)` | Server sinh UUID · `normalize()` + so `getParent()` với root, ở cả `store`, `load`, `delete` |
| **Tin Content-Type / đuôi file** | Chỉ chặn người bất cẩn. Làm đúng: đọc magic bytes (Apache Tika). Và không phục vụ file người dùng từ cùng domain mà không phòng bị |

## Ba điều đọng lại

1. Đĩa cục bộ **không dùng được khi chạy nhiều instance** — đó là lý do interface tồn tại.
2. Mọi thứ client gửi là dữ liệu không tin được — kể cả tên file và content type.
3. App thật: **presigned URL** — client tải thẳng lên S3, server không chuyển tiếp megabyte.

## Còn nợ

- File và transaction không đi cùng nhau: xoá file cũ sau commit — Bài 32.
- Thumbnail tốn CPU — đẩy sang `@Async` (Bài 20) hoặc queue (Bài 34).
