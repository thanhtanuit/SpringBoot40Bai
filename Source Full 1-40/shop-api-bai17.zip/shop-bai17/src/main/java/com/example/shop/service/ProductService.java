package com.example.shop.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.domain.Specification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.shop.dto.BestSellerResponse;
import com.example.shop.dto.ProductFilter;
import com.example.shop.dto.UpdateProductRequest;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.repository.OrderItemRepository;
import com.example.shop.repository.ProductRepository;
import com.example.shop.repository.spec.ProductSpecs;
import com.example.shop.storage.FileStorageService;

/**
 * Bài 13 — mẫu hay dùng: readOnly = true ở CẤP CLASS, đè bằng @Transactional thường
 * cho method GHI. Method đọc tự thừa hưởng, không phải nhớ gắn từng cái.
 *
 * readOnly làm ba việc: Hibernate bỏ dirty checking (không chụp bản sao entity);
 * driver báo DB giao dịch chỉ đọc; tín hiệu định tuyến sang bản sao chỉ đọc.
 * KHÔNG phải rào chắn bảo mật — SQL thuần vẫn ghi được.
 */
@Service
@Transactional(readOnly = true)
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;
    private final OrderItemRepository orderItemRepo;
    private final ProductMapper mapper;
    private final FileStorageService storage;

    public ProductService(ProductRepository repo, OrderItemRepository orderItemRepo,
                          ProductMapper mapper, FileStorageService storage) {
        this.repo = repo;
        this.orderItemRepo = orderItemRepo;
        this.mapper = mapper;
        this.storage = storage;
    }

    /** Hai câu SQL: một lấy dữ liệu trang (offset/fetch first), một SELECT count. */
    public Page<Product> findAll(Pageable pageable) {
        Page<Product> trang = repo.findAll(pageable);
        log.debug("Trang {} — {} / {} sản phẩm", pageable.getPageNumber(),
                trang.getNumberOfElements(), trang.getTotalElements());
        return trang;
    }

    /** Một câu SQL — Slice bỏ câu count. */
    public Slice<Product> scroll(Pageable pageable) {
        return repo.findSliceBy(pageable);
    }

    /**
     * Bài 15 — so với Bài 10: không if/else, không sáu tham số, không hai khối JPQL
     * phải giữ đồng bộ tay. Bộ lọc không gửi → spec null → biến mất khỏi SQL.
     *
     * AND: Specification.allOf(...) · OR: Specification.anyOf(...), ví dụ
     *   Specification.anyOf(ProductSpecs.hasKeyword(kw), ProductSpecs.skuLike(kw))
     */
    public Page<Product> search(ProductFilter filter, Pageable pageable) {
        Specification<Product> spec = Specification.allOf(
                ProductSpecs.hasKeyword(filter.keyword()),
                ProductSpecs.priceGte(filter.minPrice()),
                ProductSpecs.priceLte(filter.maxPrice()),
                ProductSpecs.inCategory(filter.categoryId()),
                ProductSpecs.categoryNameLike(filter.categoryName()),
                ProductSpecs.inStock(filter.inStock()));
        return repo.findAll(spec, pageable);
    }

    public List<BestSellerResponse> bestSellers(int limit) {
        return orderItemRepo.findBestSellers(PageRequest.of(0, limit));
    }

    public Product findById(Long id) {
        log.debug("Tìm sản phẩm id={}", id);
        return repo.findById(id).orElseThrow(() -> {
            log.warn("Không tìm thấy sản phẩm id={}", id);
            return new ResourceNotFoundException("Sản phẩm", id);
        });
    }

    @Transactional
    public Product create(String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu tạo sản phẩm name={} sku={} price={} stock={}", name, sku, price, stock);
        if (repo.existsByNameIgnoreCase(name)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySku(sku)) {
            tuChoiTrungSku(sku);
        }
        Product moi = repo.save(new Product(name, sku, price, stock == null ? 0 : stock));
        log.info("Đã tạo sản phẩm id={} name={}", moi.getId(), moi.getName());
        return moi;
    }

    /**
     * DIRTY CHECKING: không có repo.save() ở đâu cả, dữ liệu vẫn được lưu.
     *
     * Entity lấy ra BÊN TRONG giao dịch ở trạng thái managed. Hibernate giữ bản chụp
     * giá trị lúc nạp; tới lúc commit so sánh, thấy khác thì tự sinh UPDATE.
     *
     * BẪY: hệ quả ngược cũng đúng — sửa một entity managed mà KHÔNG định lưu
     * (ví dụ đổi giá tạm để tính toán) thì tới lúc commit nó VẪN bị lưu.
     */
    @Transactional
    public Product update(Long id, String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu sửa sản phẩm id={}", id);
        Product p = findById(id);
        if (repo.existsByNameIgnoreCaseAndIdNot(name, id)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySkuAndIdNot(sku, id)) {
            tuChoiTrungSku(sku);
        }
        p.setName(name);
        p.setSku(sku);
        p.setPrice(price);
        p.setStock(stock == null ? 0 : stock);
        log.info("Đã sửa sản phẩm id={}", id);
        return p;
    }

    /**
     * Bài 14 — PATCH tổng quát. Chỉ trường nào gửi mới đổi.
     * Không save — dirty checking. Thay cho updatePrice của Bài 2.
     */
    @Transactional
    public Product patch(Long id, UpdateProductRequest req) {
        Product p = findById(id);
        if (req.name() != null && repo.existsByNameIgnoreCaseAndIdNot(req.name(), id)) {
            tuChoiTrungTen(req.name());
        }
        if (req.sku() != null && repo.existsBySkuAndIdNot(req.sku(), id)) {
            tuChoiTrungSku(req.sku());
        }
        mapper.updateFromRequest(req, p);
        log.info("Đã cập nhật một phần sản phẩm id={}", id);
        return p;
    }

    /** Bài 16: repo.delete → @SQLDelete → UPDATE deleted = true. Dòng vẫn còn trong DB. */
    @Transactional
    public void delete(Long id) {
        repo.delete(findById(id));
        log.info("Đã xoá sản phẩm id={}", id);
    }

    /**
     * Bài 17 — thao tác file KHÔNG nằm trong transaction database.
     * Rollback sau khi file đã ghi → file MỒ CÔI trên đĩa. Xoá file trước khi commit mà
     * transaction hỏng → mất file trong khi DB vẫn trỏ tới.
     * Cách thực tế: ghi file mới trước, xoá file cũ SAU KHI COMMIT
     * (@TransactionalEventListener(AFTER_COMMIT) — Bài 32), cộng job dọn mồ côi định kỳ.
     */
    @Transactional
    public String capNhatAnh(Long id, MultipartFile file) {
        Product p = findById(id);
        String cu = p.getImagePath();
        String moi = storage.store(file);
        p.setImagePath(moi);
        if (cu != null) {
            storage.delete(cu);
        }
        return moi;
    }

    @Transactional
    public void xoaAnh(Long id) {
        Product p = findById(id);
        if (p.getImagePath() != null) {
            storage.delete(p.getImagePath());
            p.setImagePath(null);
        }
    }

    /** Bài 16 — danh sách đã xoá mềm (native query, không qua @SQLRestriction). */
    public List<Product> findDeleted() {
        return repo.findDeleted();
    }

    /**
     * Bài 16 — khôi phục. Nếu trong lúc đó đã có sản phẩm cùng tên/sku đang hoạt động
     * → vi phạm partial unique index → DataIntegrityViolationException → 409.
     */
    @Transactional
    public void restore(Long id) {
        if (repo.restore(id) == 0) {
            throw new ResourceNotFoundException("Sản phẩm đã xoá", id);
        }
        log.info("Đã khôi phục sản phẩm id={}", id);
    }

    private void tuChoiTrungSku(String sku) {
        log.warn("Từ chối vì trùng SKU: {}", sku);
        throw new DuplicateResourceException("Đã tồn tại sản phẩm SKU: " + sku);
    }

    private void tuChoiTrungTen(String name) {
        log.warn("Từ chối vì trùng tên: {}", name);
        throw new DuplicateResourceException("Đã tồn tại sản phẩm tên: " + name);
    }
}
