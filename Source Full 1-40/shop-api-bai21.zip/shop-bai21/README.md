# shop-api — trạng thái sau Bài 21: Spring Security căn bản (mở đầu Phần 3)

> Thêm một dependency là **toàn bộ API khoá lại**. Mặc định "chặn hết, mở dần có ý thức"
> — ngược với "mở hết, chặn dần" vốn dẫn tới quên chặn một endpoint nào đó.

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V11 (app_user, user_role), V12 (tài khoản mẫu)
```

| Tài khoản | Mật khẩu | Role |
|---|---|---|
| `admin` | `admin12345` | ADMIN |
| `seller` | `seller12345` | SELLER |

Chỉ cho dev. Production không seed tài khoản có mật khẩu biết trước.

```bash
curl -i http://localhost:8081/api/orders/1                        # 401
curl -u seller:seller12345 -X DELETE http://localhost:8081/api/products/2   # 403
curl -u admin:admin12345   -X DELETE http://localhost:8081/api/products/2   # 204
```

## Luật truy cập

| | |
|---|---|
| `/api/auth/**`, `/api/hello/**`, `/api/tinh` | Công khai |
| `GET /api/products/**`, `GET /api/categories/**` | Công khai |
| `/api/admin/**`, `/api/config/**`, `/api/cache/**`, `/api/orders/audit` | ADMIN |
| `DELETE /api/products/**` | ADMIN |
| `POST/PUT/PATCH /api/products/**`, `/api/orders/**`, `/api/dashboard` | Đăng nhập |

## Thay đổi so với Bài 20

| | |
|---|---|
| `pom.xml` | + `spring-boot-starter-security`, `spring-security-test` |
| `V11`, `V12` | `app_user` (không phải `user`), `user_role`, seed BCrypt thật |
| `model/User`, `Role` | `@ElementCollection(fetch = EAGER)` cho roles |
| `security/DatabaseUserDetailsService` | Tiền tố `ROLE_` |
| `config/SecurityConfig` | Luật theo thứ tự, stateless, CSRF tắt, HTTP Basic, BCrypt 12 |
| `AuthService`, `AuthController`, `RegisterRequest`, `UserResponse` | `POST /api/auth/register` |
| `requests.http` | Request ghi đã gắn `Authorization: Basic admin admin12345` |

## 401 và 403

| | |
|---|---|
| **401** | Chưa xác thực — "bạn là ai?" |
| **403** | Đã xác thực nhưng **không đủ quyền** — "bạn được làm gì?" |

Hai response này **chưa** theo ProblemDetail: lỗi ném từ filter chain không tới
`@RestControllerAdvice`. Bài 23 sửa.

## Bẫy

| Bẫy | |
|---|---|
| Thứ tự `requestMatchers` | Khớp luật **đầu tiên** — cụ thể trước, tổng quát sau |
| Lưu `"ADMIN"`, kiểm `hasRole("ADMIN")` | Luôn từ chối — cần `"ROLE_ADMIN"` |
| Mật khẩu > 72 byte | BCrypt cắt bỏ phần thừa |
| Trả entity `User` | Lộ hash mật khẩu |
| Tắt CSRF khi dùng cookie | Chỉ tắt được vì token nằm trong header |

Bài 22 thay Basic Auth bằng JWT.
