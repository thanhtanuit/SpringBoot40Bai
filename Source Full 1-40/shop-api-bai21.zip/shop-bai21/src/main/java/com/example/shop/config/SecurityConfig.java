package com.example.shop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Bài 21 — mở ra TỪNG PHẦN một cách có ý thức (secure by default).
 *
 * THỨ TỰ requestMatchers QUAN TRỌNG: duyệt từ trên xuống, dừng ở luật khớp ĐẦU TIÊN.
 * Cụ thể trước, tổng quát sau. anyRequest() đặt lên đầu là mọi luật sau vô nghĩa.
 *
 * Luồng: RequestIdFilter (Bài 7) → SecurityFilterChain [BasicAuthenticationFilter →
 * AuthenticationManager → DaoAuthenticationProvider → UserDetailsService + PasswordEncoder
 * → ExceptionTranslationFilter → AuthorizationFilter] → DispatcherServlet → Controller.
 * Security chạy HOÀN TOÀN TRƯỚC controller → GlobalExceptionHandler KHÔNG bắt được lỗi
 * 401/403 từ đây. Bài 23: AuthenticationEntryPoint + AccessDeniedHandler.
 * Xem đủ ~15 filter: logging.level.org.springframework.security: DEBUG (xem một lần rồi tắt).
 *
 * CSRF TẮT vì API stateless, token trong header Authorization — trình duyệt tự gửi cookie
 * nhưng KHÔNG tự gửi header. Dùng session/cookie (kể cả JWT trong cookie) thì PHẢI bật.
 */
@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // công khai
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/api/hello", "/api/hello/**", "/api/tinh").permitAll()   // Bài 1
                        .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()
                        .requestMatchers("/error").permitAll()

                        // chỉ ADMIN
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/config/**", "/api/cache/**", "/api/orders/audit").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/products/**").hasRole("ADMIN")

                        // đăng nhập là được
                        .requestMatchers(HttpMethod.POST, "/api/products/**").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/products/**").authenticated()
                        .requestMatchers(HttpMethod.PATCH, "/api/products/**").authenticated()

                        .anyRequest().authenticated())
                .httpBasic(Customizer.withDefaults())   // Bài 22 thay bằng JWT
                .build();
    }

    /**
     * Cost 12: mỗi đơn vị tăng gấp đôi thời gian băm. 12 ≈ 200–300ms — đủ chậm để dò hàng loạt
     * tốn kém, đủ nhanh để người dùng không phiền. Mặc định 10.
     * BCrypt tự sinh salt ngẫu nhiên và nhúng vào kết quả — cùng mật khẩu vẫn khác hash.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }
}
