package com.example.shop.service;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.dto.RegisterRequest;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.model.Role;
import com.example.shop.model.User;
import com.example.shop.repository.UserRepository;

@Service
@Transactional
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository repo;
    private final PasswordEncoder encoder;

    public AuthService(UserRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    /** Người tự đăng ký luôn là USER — không bao giờ nhận role từ request (mass assignment, Bài 4). */
    public User dangKy(RegisterRequest req) {
        if (repo.existsByUsername(req.username())) {
            throw new DuplicateResourceException("Tên đăng nhập đã tồn tại");
        }
        if (repo.existsByEmail(req.email())) {
            throw new DuplicateResourceException("Email đã được sử dụng");
        }

        User user = new User(
                req.username(),
                encoder.encode(req.password()),   // HASH — KHÔNG BAO GIỜ lưu mật khẩu gốc
                req.email(),
                Set.of(Role.USER));

        User daLuu = repo.save(user);
        // KHÔNG BAO GIỜ log mật khẩu, kể cả DEBUG (Bài 7)
        log.info("Đã đăng ký tài khoản id={} username={}", daLuu.getId(), daLuu.getUsername());
        return daLuu;
    }
}
