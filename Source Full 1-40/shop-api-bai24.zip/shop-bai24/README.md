# shop-api — trạng thái sau Bài 24: CORS và frontend Vue

```
shop-bai24/
├── (backend Spring Boot — như các bài trước)
└── shop-ui/           frontend Vue 3 + Vite + Pinia + axios
```

## Chạy

```bash
docker compose up -d
mvn spring-boot:run                  # backend :8081

cd shop-ui && npm install && npm run dev   # frontend :5173
```

Mở http://localhost:5173. Kịch bản kiểm thử trong `shop-ui/README.md`.

## Thay đổi backend so với Bài 23

| | |
|---|---|
| `config/CorsProperties.java` | `shop.cors.allowed-origins` |
| `SecurityConfig` | `CorsConfigurationSource` + `.cors(...)` trong security chain |
| `application-dev.yml` | `localhost:5173`, `localhost:4173` |
| `application-prod.yml` | `${FRONTEND_URL}` — **không** localhost |

## Ba điều đọng lại

1. **CORS bảo vệ người dùng, không bảo vệ server.** Server vẫn trả 200; trình duyệt mới là
   bên từ chối đưa dữ liệu cho JavaScript.
2. Nó là **luật của trình duyệt** — `curl` và mobile app không bị ảnh hưởng.
3. Danh sách origin **tường minh**, đọc từ cấu hình, khác nhau giữa môi trường.

## Bẫy

| Bẫy | |
|---|---|
| `allowedOrigins("*")` + credentials | Đặc tả cấm — bất kỳ trang nào cũng gọi được API bằng quyền người dùng |
| CORS bằng `WebMvcConfigurer` khi có Spring Security | Preflight bị chặn 401 |
| Quên `exposedHeaders` | Frontend không đọc được `Location` |
| Frontend refresh token song song | Bị coi là tái sử dụng → thu hồi toàn phiên. `shop-ui/src/api/client.js` gộp về một lời gọi |
| Để frontend ẩn `costPrice` | Không phải bảo mật — server đã lọc (Bài 23) |

## CORS hay proxy

| | CORS | Proxy Vite |
|---|---|---|
| Cấu hình | Backend | Frontend |
| Preflight | Có | Không |
| Giống production | Khi prod khác origin | Khi prod cùng Nginx (Bài 37) |

Làm cả hai: CORS đúng ở backend (cần cho mobile, bên thứ ba), proxy ở dev cho tiện.

Bài 25: kiểm thử — sau 24 bài chưa có một dòng test nào.
