package com.example.shop.web;

import java.net.URI;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.shop.config.ShopProperties;
import com.example.shop.dto.BestSellerResponse;
import com.example.shop.dto.CreateProductRequest;
import com.example.shop.dto.PageResponse;
import com.example.shop.dto.ProductFilter;
import com.example.shop.dto.ProductPriceResponse;
import com.example.shop.dto.ProductResponse;
import com.example.shop.dto.SliceResponse;
import com.example.shop.dto.UpdateProductRequest;
import com.example.shop.mapper.ProductMapper;
import com.example.shop.model.Product;
import com.example.shop.service.ProductService;

import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ProblemDetail;

/**
 * Bài 23 — @PreAuthorize ở controller cho luật đơn giản theo vai trò.
 * Đặt ở service thì an toàn hơn (chặn MỌI đường vào) nhưng trộn bảo mật vào nghiệp vụ.
 * Chọn một cách và làm NHẤT QUÁN.
 *
 * Authentication auth: ẩn danh thì null. ProductPresenter ẩn costPrice nếu không phải ADMIN.
 */
@RestController
@RequestMapping("/api/products")
@Tag(name = "Products")
// Mẹo: response lỗi dùng chung khai MỘT lần ở cấp class
@ApiResponses({
        @ApiResponse(responseCode = "401", description = "Chưa đăng nhập",
                content = @Content(mediaType = "application/problem+json",
                        schema = @Schema(implementation = ProblemDetail.class))),
        @ApiResponse(responseCode = "403", description = "Không đủ quyền",
                content = @Content(mediaType = "application/problem+json",
                        schema = @Schema(implementation = ProblemDetail.class)))
})
public class ProductController {

    private final ProductService service;
    private final ShopProperties props;
    private final ProductMapper mapper;
    private final ProductPresenter presenter;

    /**
     * Bài 14: mapper giờ là BEAN — tiêm qua constructor (Bài 3), không còn method tĩnh.
     * Lần thứ tư thay ruột mà hợp đồng không đổi: Bài 3 tầng, Bài 8 JPA,
     * Bài 11 Postgres, Bài 14 cách chuyển đổi.
     */
    public ProductController(ProductService service, ShopProperties props, ProductMapper mapper,
                             ProductPresenter presenter) {
        this.service = service;
        this.props = props;
        this.mapper = mapper;
        this.presenter = presenter;
    }

    /**
     * Chỉ khai Pageable — Spring tự dựng từ ?page=&size=&sort=.
     * Sắp xếp nhiều cấp: ?sort=price,desc&sort=name,asc
     */
    @GetMapping
    @SecurityRequirements   // rỗng = không cần xác thực
    @Operation(summary = "Danh sách sản phẩm có phân trang",
               description = "`size` bị giới hạn bởi `shop.max-items-per-page`. Sắp xếp nhiều cấp: `sort=price,desc&sort=name,asc`.")
    public PageResponse<ProductResponse> findAll(
            @PageableDefault(size = 10, sort = "id") Pageable pageable, Authentication auth) {
        return PageResponse.from(service.findAll(chuanHoa(pageable)),
                p -> presenter.present(mapper.toResponse(p), auth));
    }

    /** Cuộn vô hạn — Slice, một câu SQL. So log với GET /api/products. */
    @GetMapping("/scroll")
    @SecurityRequirements
    @Operation(summary = "Cuộn vô hạn (Slice)", description = "Không có tổng số trang — bỏ câu COUNT.")
    public SliceResponse<ProductResponse> scroll(
            @PageableDefault(size = 10, sort = "id") Pageable pageable, Authentication auth) {
        return SliceResponse.from(service.scroll(chuanHoa(pageable)),
                p -> presenter.present(mapper.toResponse(p), auth));
    }

    /** Bài 15 — Specification. Mọi bộ lọc tuỳ chọn, gom trong ProductFilter. */
    @GetMapping("/search")
    @SecurityRequirements
    @Operation(summary = "Tìm kiếm động", description = "Mọi bộ lọc tuỳ chọn; bộ lọc không gửi biến mất khỏi câu SQL.")
    public PageResponse<ProductResponse> search(
            @ModelAttribute ProductFilter filter,
            @PageableDefault(size = 10, sort = "id") Pageable pageable, Authentication auth) {
        return PageResponse.from(service.search(filter, chuanHoa(pageable)),
                p -> presenter.present(mapper.toResponse(p), auth));
    }

    @GetMapping("/best-sellers")
    @SecurityRequirements
    public List<BestSellerResponse> bestSellers(@RequestParam(defaultValue = "5") int limit) {
        return service.bestSellers(Math.min(Math.max(limit, 1), props.maxItemsPerPage()));
    }

    /** Bài 18 — giá quy đổi USD qua API tỷ giá bên ngoài. */
    @GetMapping("/{id}/price-usd")
    @SecurityRequirements
    @Operation(summary = "Giá quy đổi USD",
               description = "Gọi API tỷ giá bên ngoài. `nguonTyGia = MAC_DINH` khi API lỗi — suy giảm có kiểm soát.")
    public ProductPriceResponse giaUsd(@PathVariable Long id) {
        return service.giaQuyDoi(id);
    }

    /** Bài 19 — đọc qua cache. */
    @GetMapping("/{id}")
    @SecurityRequirements
    @Operation(summary = "Lấy chi tiết một sản phẩm",
               description = "Trường `costPrice` chỉ hiện với vai trò ADMIN.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Thành công"),
            @ApiResponse(responseCode = "404", description = "Không tìm thấy sản phẩm",
                    content = @Content(mediaType = "application/problem+json",
                            schema = @Schema(implementation = ProblemDetail.class)))
    })
    public ProductResponse findById(@Parameter(description = "Id sản phẩm", example = "1")
                                    @PathVariable Long id, Authentication auth) {
        // Cache (Bài 19) giữ bản ĐẦY ĐỦ; presenter lọc theo người đang xem
        return presenter.present(service.findResponseById(id), auth);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Tạo sản phẩm mới",
               description = "Yêu cầu SELLER hoặc ADMIN. Trả header `Location` trỏ tới tài nguyên vừa tạo.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Đã tạo"),
            @ApiResponse(responseCode = "400", description = "Dữ liệu không hợp lệ"),
            @ApiResponse(responseCode = "409", description = "Tên hoặc SKU đã tồn tại")
    })
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody CreateProductRequest req,
                                                  Authentication auth) {
        Product moi = service.create(req.name(), req.sku(), req.price(), req.stock());
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.getId())
                .toUri();
        return ResponseEntity.created(location).body(presenter.present(mapper.toResponse(moi), auth));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    public ProductResponse update(@PathVariable Long id, @Valid @RequestBody CreateProductRequest req,
                                  Authentication auth) {
        return presenter.present(
                mapper.toResponse(service.update(id, req.name(), req.sku(), req.price(), req.stock())), auth);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Xoá sản phẩm (xoá mềm)",
               description = "Chỉ ADMIN. Bản ghi đánh dấu `deleted = true`, không xoá vật lý.")
    @ApiResponse(responseCode = "204", description = "Đã xoá")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    /** Bài 14: PATCH tổng quát — thay endpoint /{id}/price của Bài 2. */
    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Cập nhật một phần",
               description = "Chỉ trường nào gửi mới đổi. Không đặt được `costPrice` qua đây.")
    public ProductResponse patch(@PathVariable Long id, @Valid @RequestBody UpdateProductRequest req,
                                 Authentication auth) {
        return presenter.present(mapper.toResponse(service.patch(id, req)), auth);
    }

    /**
     * BẪY 1: không chặn trần size → ?size=1000000 nạp cả bảng vào RAM, một request hạ server.
     * Không cần là tấn công — chỉ cần frontend "lấy hết cho tiện".
     * Trần lấy từ shop.max-items-per-page của Bài 6 — giá trị đó cuối cùng cũng có việc.
     * (spring.data.web.pageable.max-page-size trong application.yml là lưới an toàn thứ hai.)
     */
    private Pageable chuanHoa(Pageable p) {
        int max = props.maxItemsPerPage();
        if (p.getPageSize() <= max) {
            return p;
        }
        return PageRequest.of(p.getPageNumber(), max, p.getSort());
    }
}
