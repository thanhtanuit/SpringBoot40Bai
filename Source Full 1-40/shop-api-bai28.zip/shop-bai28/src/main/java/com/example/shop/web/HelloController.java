package com.example.shop.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Hidden;

/**
 * Ba endpoint đầu tiên của shop-api.
 *
 * @RestController = @Controller + @ResponseBody.
 * BẪY 2: chỉ viết @Controller thì Spring hiểu chuỗi trả về là TÊN TRANG HTML
 * và đi tìm file giao diện tên đó → lỗi. Làm REST API: luôn @RestController.
 *
 * @RequestMapping("/api") là tiền tố chung cho mọi endpoint trong class.
 */
@RestController
@Hidden   // Bài 28: endpoint học của Bài 1 — ẩn khỏi tài liệu
@RequestMapping("/api")
public class HelloController {

    /**
     * GET /api/hello → "Xin chào Spring Boot"
     *
     * Trả String → StringHttpMessageConverter nhận việc → Content-Type: text/plain.
     */
    @GetMapping("/hello")
    public String hello() {
        return "Xin chào Spring Boot";
    }

    /**
     * GET /api/hello/Nam → "Xin chào, Nam"
     *
     * @PathVariable lấy dữ liệu TỪ ĐƯỜNG DẪN. Tên biến "ten" trùng với {ten}
     * nên Spring tự ghép; khác tên thì phải ghi rõ @PathVariable("ten").
     */
    @GetMapping("/hello/{ten}")
    public String helloTen(@PathVariable String ten) {
        return "Xin chào, " + ten;
    }

    /**
     * GET /api/tinh?a=3&b=5 → {"a":3,"b":5,"tong":8}
     *
     * @RequestParam lấy dữ liệu SAU DẤU "?".
     *
     * Trả về OBJECT, không tự ghép chuỗi JSON.
     * Spring duyệt danh sách HttpMessageConverter, chọn bộ ĐẦU TIÊN xử lý được kiểu
     * trả về: KetQua không phải String → tới lượt MappingJackson2HttpMessageConverter
     * → Content-Type: application/json. Jackson đi kèm Spring Web, auto-configuration
     * thấy nó trong classpath và tự đăng ký.
     *
     * BẪY 3: ĐỪNG viết  return "{\"a\":" + a + ...;
     * Chỉ cần dữ liệu có một dấu nháy kép là JSON tự ghép vỡ ngay.
     * Trả object để Jackson lo escape.
     */
    @GetMapping("/tinh")
    public KetQua tinh(@RequestParam int a, @RequestParam int b) {
        return new KetQua(a, b, a + b);
    }
}
