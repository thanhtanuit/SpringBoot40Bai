package com.example.shop.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record OrderItemRequest(

        @Schema(example = "1")
        @NotNull(message = "Thiếu mã sản phẩm")
        Long productId,

        @Schema(example = "2")
        @NotNull(message = "Thiếu số lượng")
        @Min(value = 1, message = "Số lượng phải từ 1 trở lên")
        Integer quantity
) {
}
