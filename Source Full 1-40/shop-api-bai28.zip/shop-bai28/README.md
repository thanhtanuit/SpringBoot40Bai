# shop-api — trạng thái sau Bài 28: Tài liệu API với OpenAPI

## Chạy

```bash
docker compose up -d
mvn spring-boot:run
```

- **Swagger UI:** http://localhost:8081/swagger-ui.html (chỉ profile dev)
- **Đặc tả:** http://localhost:8081/v3/api-docs/all · `/public` · `/admin`

**Thử API cần quyền ngay trên trình duyệt:** `POST /api/auth/login` → Try it out → Execute →
copy `accessToken` → **Authorize** → dán (không kèm chữ `Bearer`).

## Thay đổi so với Bài 27

| | |
|---|---|
| `pom.xml` | + `springdoc-openapi-starter-webmvc-ui` 2.7.0 |
| `config/OpenApiConfig.java` | Info, server, tag theo thứ tự, security scheme Bearer, 3 nhóm |
| `SecurityConfig` | Mở `/swagger-ui/**`, `/v3/api-docs/**` **chỉ khi profile dev** |
| `application-dev.yml` | `springdoc.*` |
| `application-prod.yml` | `springdoc.api-docs.enabled: false`, `swagger-ui.enabled: false` |
| Controller | `@Tag`, `@Operation`, `@ApiResponses` (lỗi chung ở cấp class), `@SecurityRequirements` cho endpoint công khai, `@Hidden` cho `HelloController` |
| DTO | `@Schema(example = ...)` — điền sẵn form Try it out |
| `docs/` | Hướng dẫn xuất `openapi.json` để commit |
| `shop-ui/package.json` | `npm run api:types` sinh kiểu TypeScript |

## Ba điều đọng lại

1. Tài liệu **sinh từ code** thì không bao giờ lỗi thời.
2. `example` giá trị hơn `description` — biến Swagger UI từ tài liệu đọc thành công cụ thử.
3. **Tắt hẳn ở production** — tiện cho dev cũng là tiện cho người đang dò endpoint của bạn.

## Đừng

- Mô tả thứ code đã nói rõ: `summary = "Lấy sản phẩm theo id"` cho `findById` là tiếng ồn.
  Chỉ viết luật nghiệp vụ, điều kiện đặc biệt, tác dụng phụ, quyền cần có.
- Tin tài liệu về phân quyền — nguồn sự thật là **test Bài 26**.

Bài 29: Actuator, health check, metric nghiệp vụ.
