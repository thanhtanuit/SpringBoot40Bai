package com.example.shop.dto;

import java.util.List;

import com.example.shop.model.Product;

/** Vẫn viết tay, vẫn cố tình nhàm chán — Bài 14 thay bằng MapStruct. */
public final class ProductMapper {

    private ProductMapper() {
    }

    public static ProductResponse toResponse(Product p) {
        return new ProductResponse(
                p.getId(),
                p.getName(),
                p.getPrice(),
                p.getStock(),
                p.getCategory() != null ? p.getCategory().getName() : null);
    }

    public static List<ProductResponse> toResponseList(List<Product> list) {
        return list.stream().map(ProductMapper::toResponse).toList();
    }
}
