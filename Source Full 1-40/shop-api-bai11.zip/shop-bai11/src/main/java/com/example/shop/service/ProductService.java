package com.example.shop.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.dto.BestSellerResponse;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Product;
import com.example.shop.repository.OrderItemRepository;
import com.example.shop.repository.ProductRepository;

/**
 * Bài 8: thêm @Transactional ở cấp class — mỗi method public chạy trong một
 * giao dịch: vào method mở, xong bình thường commit, ném exception rollback.
 * readOnly = true cho method chỉ đọc: Hibernate bỏ qua bước so sánh thay đổi.
 * (Bài 13 mổ xẻ đầy đủ.)
 */
@Service
@Transactional
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;
    private final OrderItemRepository orderItemRepo;

    public ProductService(ProductRepository repo, OrderItemRepository orderItemRepo) {
        this.repo = repo;
        this.orderItemRepo = orderItemRepo;
    }

    /** Hai câu SQL: một lấy dữ liệu trang (offset/fetch first), một SELECT count. */
    @Transactional(readOnly = true)
    public Page<Product> findAll(Pageable pageable) {
        Page<Product> trang = repo.findAll(pageable);
        log.debug("Trang {} — {} / {} sản phẩm", pageable.getPageNumber(),
                trang.getNumberOfElements(), trang.getTotalElements());
        return trang;
    }

    /** Một câu SQL — Slice bỏ câu count. */
    @Transactional(readOnly = true)
    public Slice<Product> scroll(Pageable pageable) {
        return repo.findSliceBy(pageable);
    }

    @Transactional(readOnly = true)
    public Page<Product> search(String keyword, Double minPrice, Double maxPrice,
                                Long categoryId, Pageable pageable) {
        String kw = (keyword == null || keyword.isBlank()) ? null : keyword.trim();
        return repo.search(kw, minPrice, maxPrice, categoryId, pageable);
    }

    @Transactional(readOnly = true)
    public List<BestSellerResponse> bestSellers(int limit) {
        return orderItemRepo.findBestSellers(PageRequest.of(0, limit));
    }

    @Transactional(readOnly = true)
    public Product findById(Long id) {
        log.debug("Tìm sản phẩm id={}", id);
        return repo.findById(id).orElseThrow(() -> {
            log.warn("Không tìm thấy sản phẩm id={}", id);
            return new ResourceNotFoundException("Sản phẩm", id);
        });
    }

    public Product create(String name, double price, Integer stock) {
        log.debug("Yêu cầu tạo sản phẩm name={} price={} stock={}", name, price, stock);
        if (repo.existsByNameIgnoreCase(name)) {
            tuChoiTrungTen(name);
        }
        Product moi = repo.save(new Product(name, price, stock == null ? 0 : stock));
        log.info("Đã tạo sản phẩm id={} name={}", moi.getId(), moi.getName());
        return moi;
    }

    /**
     * DIRTY CHECKING: không có repo.save() ở đâu cả, dữ liệu vẫn được lưu.
     *
     * Entity lấy ra BÊN TRONG giao dịch ở trạng thái managed. Hibernate giữ bản chụp
     * giá trị lúc nạp; tới lúc commit so sánh, thấy khác thì tự sinh UPDATE.
     *
     * BẪY: hệ quả ngược cũng đúng — sửa một entity managed mà KHÔNG định lưu
     * (ví dụ đổi giá tạm để tính toán) thì tới lúc commit nó VẪN bị lưu.
     */
    public Product update(Long id, String name, double price, Integer stock) {
        log.debug("Yêu cầu sửa sản phẩm id={}", id);
        Product p = findById(id);
        if (repo.existsByNameIgnoreCaseAndIdNot(name, id)) {
            tuChoiTrungTen(name);
        }
        p.setName(name);
        p.setPrice(price);
        p.setStock(stock == null ? 0 : stock);
        log.info("Đã sửa sản phẩm id={}", id);
        return p;
    }

    public Product updatePrice(Long id, double price) {
        Product p = findById(id);
        double giaCu = p.getPrice();
        p.setPrice(price);
        log.info("Đã đổi giá sản phẩm id={} từ {} sang {}", id, giaCu, price);
        return p;
    }

    public void delete(Long id) {
        repo.delete(findById(id));
        log.info("Đã xoá sản phẩm id={}", id);
    }

    private void tuChoiTrungTen(String name) {
        log.warn("Từ chối vì trùng tên: {}", name);
        throw new DuplicateResourceException("Đã tồn tại sản phẩm tên: " + name);
    }
}
