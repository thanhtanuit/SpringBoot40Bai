-- Bài 11: data.sql chạy LẠI mỗi lần khởi động (ddl-auto: update giữ bảng).
-- Trục trặc 2: lần thứ hai lỗi trùng khoá → "sửa tạm" bằng ON CONFLICT DO NOTHING.
-- Hai lần "sửa tạm" (defer + ON CONFLICT) = cách làm này đã tới giới hạn.
-- Bài 12: Flyway chạy mỗi file ĐÚNG MỘT LẦN, có lịch sử — file này bị xoá.

INSERT INTO category (name) VALUES ('Bàn phím')            ON CONFLICT (name) DO NOTHING;
INSERT INTO category (name) VALUES ('Chuột')               ON CONFLICT (name) DO NOTHING;
INSERT INTO category (name) VALUES ('Âm thanh & hình ảnh') ON CONFLICT (name) DO NOTHING;

INSERT INTO product (name, price, stock, category_id, created_at)
SELECT 'Bàn phím cơ', 1250000, 10, id, CURRENT_TIMESTAMP FROM category WHERE name = 'Bàn phím'
ON CONFLICT (name) DO NOTHING;

INSERT INTO product (name, price, stock, category_id, created_at)
SELECT 'Chuột không dây', 350000, 25, id, CURRENT_TIMESTAMP FROM category WHERE name = 'Chuột'
ON CONFLICT (name) DO NOTHING;

INSERT INTO product (name, price, stock, category_id, created_at)
SELECT 'Tai nghe chụp tai', 890000, 8, id, CURRENT_TIMESTAMP FROM category WHERE name = 'Âm thanh & hình ảnh'
ON CONFLICT (name) DO NOTHING;

INSERT INTO product (name, price, stock, category_id, created_at)
SELECT 'Màn hình 27 inch', 4500000, 4, id, CURRENT_TIMESTAMP FROM category WHERE name = 'Âm thanh & hình ảnh'
ON CONFLICT (name) DO NOTHING;

INSERT INTO product (name, price, stock, category_id, created_at)
SELECT 'Webcam Full HD', 650000, 15, id, CURRENT_TIMESTAMP FROM category WHERE name = 'Âm thanh & hình ảnh'
ON CONFLICT (name) DO NOTHING;
