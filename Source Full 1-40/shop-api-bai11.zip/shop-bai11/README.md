# shop-api — trạng thái sau Bài 11: PostgreSQL bằng Docker

> Dữ liệu **lần đầu sống sót qua restart**.
> Đổi hẳn database mà service và controller không sửa dòng nào — lần nữa.

## Chạy

Cần **Docker Desktop** đang chạy.

```bash
cp .env.example .env               # một lần; kiểm tra git status không thấy .env
docker compose up -d
docker compose ps                  # phải là "healthy"
mvn spring-boot:run
```

Xem dữ liệu:

```bash
docker compose exec postgres psql -U shop -d shop
\dt                      -- liệt kê bảng
\d product               -- cấu trúc
SELECT id, name, stock FROM product;
```

Test (`mvn test`) chạy trên H2, không cần Docker.

## Thay đổi so với Bài 10

| File | Thay đổi |
|---|---|
| `docker-compose.yml` | **Mới** — postgres:16-alpine, named volume, healthcheck |
| `pom.xml` | + `postgresql` (runtime), `h2` → scope `test` |
| `application.yml` | Bỏ hết datasource — chỉ giữ thứ chung |
| `application-dev.yml` | Postgres localhost, HikariCP, `ddl-auto: update` (tạm), H2 console bỏ |
| `application-prod.yml` | `${DB_URL}` không mặc định, `validate`, `connection-timeout: 5000` |
| `data.sql` | `ON CONFLICT DO NOTHING` — "sửa tạm" |
| `src/test/resources/application-test.yml` | H2 cho test |

## Ba thí nghiệm

1. **Restart:** tạo sản phẩm → `docker compose restart postgres` → chạy lại app → dữ liệu còn.
2. **Pool cạn:** `maximum-pool-size: 2`, thêm `Thread.sleep(3000)` vào một endpoint,
   bắn 5 request cùng lúc → request thứ 3 trở đi phải đợi. Xoá `sleep` sau đó.
3. **Database chết:** `docker compose stop postgres` → API treo 30 giây rồi 500
   (JSON đúng định dạng nhờ Bài 5, log `error` đúng mức nhờ Bài 7).
   `docker compose start postgres` → API tự sống lại.

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Không có named volume | `docker compose down` là mất sạch |
| `connection-timeout` 30 giây ở prod | Treo thread — hạ xuống 5–10 giây |
| `depends_on` dạng danh sách | Chỉ đợi container lên — dùng `condition: service_healthy` |

## Còn "sửa tạm" — Bài 12 dọn

- `defer-datasource-initialization: true`
- `ON CONFLICT DO NOTHING` trong `data.sql`
- `ddl-auto: update`
