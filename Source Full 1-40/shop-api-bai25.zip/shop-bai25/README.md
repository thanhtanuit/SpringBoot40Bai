# shop-api — trạng thái sau Bài 25: Unit test tầng Service

> Sau 24 bài, `shop-api` có rất nhiều logic và chưa một dòng test nào.

## Chạy test

```bash
mvn test                               # không cần Docker
mvn test -Dtest=ProductServiceTest     # một class
mvn clean verify                       # + báo cáo JaCoCo
# mở target/site/jacoco/index.html
```

## Test đã có

```
src/test/java/com/example/shop/
├── service/
│   ├── ProductServiceTest.java    @Nested: tạo · tìm · cập nhật · xoá; ArgumentCaptor
│   └── OrderServiceTest.java      tính tiền, trừ kho, chốt giá, công tắc LOI, @ParameterizedTest giảm giá
├── security/
│   └── JwtServiceTest.java        token sửa 1 ký tự, secret khác, hết hạn, secret < 32 byte
├── validation/
│   └── SkuValidatorTest.java      @ValueSource, @NullSource
└── ShopApiApplicationTests.java   @SpringBootTest duy nhất — so thời gian
```

```
ProductService
├─ Tạo sản phẩm
│  ├─ ✓ should_LuuSanPham_When_DuLieuHopLe
│  ├─ ✓ should_ThrowDuplicate_When_TenDaTonTai
│  └─ ...
└─ Tìm theo id
   └─ ✓ should_ThrowNotFound_When_ProductIdMissing
```

## Thay đổi so với Bài 24

| | |
|---|---|
| `pom.xml` | + JaCoCo (report + check 80% cho `service`, `haltOnFailure=false`) |
| `OrderService.tinhGiamGia` | Quy tắc giảm giá để luyện test ranh giới (chưa áp vào đơn) |

## Ba điều đọng lại

1. Unit test nhanh vì **không Spring, không database**. Thêm `@SpringBootTest` là mất lý do tồn tại.
2. Kiểm **hành vi**, không phải cách cài đặt.
3. Test là **tài liệu sống**: `should_ThrowInsufficientStock_When_KhongDuHang` nói hệ thống phải
   cư xử thế nào — chính xác hơn mọi README.

## Giới hạn

`should_KhongLuuDon_When_DongSauHetHang`: tồn kho trong test là 8, không phải 10 — **Mockito không
mô phỏng transaction**. Kiểm rollback thật cần DB thật → Bài 27 (Testcontainers).

## Coverage

Thấp → tín hiệu đáng tin. Cao → không nói lên gì (test không assert vẫn phủ 100%).
Muốn đo chất lượng test: mutation testing (PIT).

Bài 26: `@WebMvcTest`, `MockMvc`, phủ ma trận quyền Bài 23.
