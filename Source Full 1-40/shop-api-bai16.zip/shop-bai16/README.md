# shop-api — trạng thái sau Bài 16: Auditing và soft delete

> Hai tính năng nghe đơn giản, nhưng cả hai đều **can thiệp ngầm vào mọi truy vấn**.

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V6, V7, V8
```

```bash
docker compose exec postgres psql -U shop -d shop
SELECT id, name, deleted, created_at, updated_at, created_by, updated_by FROM product ORDER BY id;
```

## Thay đổi so với Bài 15

| | |
|---|---|
| `V6__add_auditing_columns.sql` | 4 cột cho product, category, orders — mẫu 3 bước |
| `V7__add_soft_delete.sql` | `deleted BOOLEAN` + index |
| `V8__partial_unique_index.sql` | Unique chỉ trên dòng chưa xoá |
| `model/BaseEntity.java` | `@MappedSuperclass` + `AuditingEntityListener` |
| `config/JpaAuditingConfig.java` | `@EnableJpaAuditing` + `AuditorAware` → "system" |
| `Product`, `Category`, `Order` | `extends BaseEntity`, bỏ `createdAt`/`@PrePersist` tự viết |
| `Product` | `@SQLDelete` + `@SQLRestriction("deleted = false")` |
| `ProductResponse` | + `createdAt`, `updatedAt` |
| `AdminProductController` | `GET /api/admin/products/deleted`, `POST /{id}/restore` — **chưa bảo mật** |
| `GlobalExceptionHandler` | + `DataIntegrityViolationException` → 409 |

## Mặt trái của soft delete

| Vấn đề | |
|---|---|
| Unique bị vướng | Xoá rồi tạo lại cùng tên → vi phạm. Postgres: partial index (V8). MySQL không có |
| Bảng phình to | Chỉ tăng, không giảm — cần job dọn (Bài 20) |
| Khoá ngoại nói dối | `order_item.product_id` trỏ tới sản phẩm "đã xoá" |
| Dễ quên ở đường vòng | Native query, báo cáo BI, script tay đều thấy dữ liệu đã xoá |
| GDPR | Quyền được xoá **không** đáp ứng bằng soft delete |

> Soft delete **không phải mặc định**. Chỉ dùng khi cần khôi phục, lịch sử, truy vết.
> Dữ liệu tham chiếu như `Category`: cột `active` đúng ngữ nghĩa hơn — "ngừng dùng" ≠ "đã xoá".
> Hướng khác: xoá thật khỏi bảng chính, chép sang `product_archive`.

## Vì sao phải native query

`@SQLRestriction` áp ở tầng Hibernate. JPQL `WHERE p.deleted = true` thành
`deleted = true AND deleted = false` → luôn rỗng. SQL thuần đi thẳng xuống DB.
