package com.example.shop.health;

import java.time.Duration;
import java.time.Instant;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Bài 29 — health của API tỷ giá (Bài 18).
 *
 * Tên bean "exchangeRate" thành khoá trong JSON /actuator/health.
 *
 * Gọi THẲNG RestClient (có timeout), KHÔNG qua ExchangeRateClient: bản đó có @Cacheable (trả giá
 * trị cũ → health nói dối) và @Retryable (lỗi thì chờ ~16s → health chậm). Health phải NHANH và THẬT.
 *
 * API chết → DEGRADED, không phải DOWN: app vẫn chạy với tỷ giá mặc định — không đáng để load
 * balancer rút instance. http-mapping DEGRADED → 200 (application.yml). Không nằm trong readiness.
 *
 * Kiểm chứng: đổi shop.exchange-rate.base-url sang địa chỉ sai rồi gọi /actuator/health.
 */
@Component("exchangeRate")
public class ExchangeRateHealthIndicator implements HealthIndicator {

    static final Status DEGRADED = new Status("DEGRADED", "Dịch vụ phụ lỗi — đang dùng fallback");

    private final RestClient client;

    public ExchangeRateHealthIndicator(RestClient exchangeRateRestClient) {
        this.client = exchangeRateRestClient;
    }

    @Override
    public Health health() {
        Instant batDau = Instant.now();
        try {
            client.get().uri("/latest/VND").retrieve().toBodilessEntity();
            long ms = Duration.between(batDau, Instant.now()).toMillis();
            return (ms < 1000 ? Health.up() : Health.status(DEGRADED))
                    .withDetail("responseTimeMs", ms)
                    .build();
        } catch (Exception e) {
            return Health.status(DEGRADED)
                    .withDetail("error", e.getClass().getSimpleName())   // tên class, KHÔNG phải message đầy đủ
                    .withDetail("fallback", "đang dùng tỷ giá mặc định")
                    .build();
        }
    }
}
