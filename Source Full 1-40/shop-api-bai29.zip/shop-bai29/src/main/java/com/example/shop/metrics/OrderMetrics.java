package com.example.shop.metrics;

import java.util.function.Supplier;

import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

/**
 * Bài 29 — METRIC NGHIỆP VỤ. CPU, RAM bình thường không có nghĩa hệ thống làm đúng việc: một bug
 * làm MỌI đơn thất bại vẫn cho CPU thấp, độ trễ đẹp. shop.orders.created rơi về 0 lúc 10 giờ sáng
 * thứ Hai mới là tín hiệu thật.
 *
 *   Counter             chỉ tăng                           số đơn đã tạo
 *   Gauge               lên xuống, đo tại thời điểm        sản phẩm sắp hết (InventoryMetrics)
 *   Timer               thời lượng + số lần                thời gian xử lý đơn
 *   DistributionSummary phân phối giá trị không phải thời gian  giá trị đơn
 *
 * CARDINALITY: tag "reason" chỉ có vài giá trị cố định. KHÔNG BAO GIỜ tag bằng id đơn hay id người
 * dùng — mỗi giá trị một chuỗi metric, hệ thống giám sát nổ tung.
 *
 * Prometheus: shop.orders.created → shop_orders_created_total
 * Cách gọn hơn cho Timer: @Timed + bean TimedAspect — vẫn là bẫy proxy (Bài 13).
 */
@Component
public class OrderMetrics {

    private final MeterRegistry registry;
    private final Counter donTao;
    private final Timer thoiGianDatHang;
    private final DistributionSummary giaTriDon;

    public OrderMetrics(MeterRegistry registry) {
        this.registry = registry;
        this.donTao = Counter.builder("shop.orders.created")
                .description("Số đơn hàng được tạo thành công")
                .register(registry);
        this.thoiGianDatHang = Timer.builder("shop.orders.duration")
                .description("Thời gian xử lý một đơn hàng")
                .publishPercentiles(0.5, 0.95, 0.99)
                .register(registry);
        this.giaTriDon = DistributionSummary.builder("shop.orders.amount")
                .description("Giá trị đơn hàng")
                .baseUnit("VND")
                .register(registry);
    }

    public void ghiNhanThanhCong(double tongTien) {
        donTao.increment();
        giaTriDon.record(tongTien);
    }

    /** reason: insufficient_stock · product_not_found · other */
    public void ghiNhanThatBai(String reason) {
        Counter.builder("shop.orders.failed")
                .description("Số đơn hàng thất bại")
                .tag("reason", reason)
                .register(registry)
                .increment();
    }

    public <T> T doThoiGian(Supplier<T> viec) {
        return thoiGianDatHang.record(viec);
    }
}
