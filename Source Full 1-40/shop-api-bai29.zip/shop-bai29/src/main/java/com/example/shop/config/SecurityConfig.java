package com.example.shop.config;

import java.time.Duration;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.example.shop.security.JsonAccessDeniedHandler;
import com.example.shop.security.JsonAuthenticationEntryPoint;
import com.example.shop.security.JwtAuthenticationFilter;
import com.example.shop.security.JwtService;

/**
 * Bài 22 — JWT. Bài 23 — phân quyền HAI TẦNG, bổ sung nhau:
 *
 *  Tầng URL (authorizeHttpRequests) — hàng rào THÔ, chặn sớm trước controller. Luật rộng theo đường dẫn.
 *  Tầng phương thức (@PreAuthorize) — luật CHI TIẾT nằm cạnh code. Đọc method là biết ai được gọi,
 *  và áp cho MỌI đường gọi tới method đó.
 *
 * anyRequest().authenticated() là LƯỚI AN TOÀN: quên @PreAuthorize ở đâu thì ít nhất vẫn phải đăng nhập.
 *
 * STATELESS — instance nào cũng xử lý được request nào.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity           // prePostEnabled = true là mặc định
public class SecurityConfig {

    /** Bài 28 — chỉ mở ở profile dev. */
    private static final String[] SWAGGER_PATHS = {
            "/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs", "/v3/api-docs/**"
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, JwtService jwtService,
                                           UserDetailsService userDetailsService,
                                           JsonAuthenticationEntryPoint entryPoint,
                                           JsonAccessDeniedHandler accessDeniedHandler,
                                           CorsConfigurationSource corsSource,
                                           Environment env) throws Exception {
        // Tạo bằng new — KHÔNG để filter là bean (xem comment trong JwtAuthenticationFilter)
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtService, userDetailsService);

        return http
                // Bài 24: CORS trong SecurityFilterChain — CorsFilter chạy TRƯỚC xác thực nên
                // preflight OPTIONS (không mang token) không bị chặn 401. Cấu hình bằng
                // WebMvcConfigurer.addCorsMappings thì chạy muộn hơn và preflight thất bại.
                .cors(cors -> cors.configurationSource(corsSource))
                .csrf(csrf -> csrf.disable())
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> {
                    if (env.acceptsProfiles(Profiles.of("dev"))) {
                        auth.requestMatchers(SWAGGER_PATHS).permitAll();   // Bài 28
                    }
                    auth
                        .requestMatchers("/api/auth/login", "/api/auth/register",
                                "/api/auth/refresh", "/api/auth/logout").permitAll()
                        .requestMatchers("/api/hello", "/api/hello/**", "/api/tinh").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()
                        .requestMatchers("/error").permitAll()

                        // Bài 29 — load balancer / Kubernetes gọi không có token
                        .requestMatchers("/actuator/health", "/actuator/health/**",
                                "/internal/actuator/health", "/internal/actuator/health/**",
                                "/healthz", "/readyz").permitAll()
                        .requestMatchers("/actuator/info", "/internal/actuator/info").permitAll()
                        // Prometheus scrape không có token — CHỈ mở ở mạng nội bộ
                        .requestMatchers("/actuator/prometheus", "/internal/actuator/prometheus").permitAll()
                        .requestMatchers("/actuator/**", "/internal/actuator/**").hasRole("ADMIN")

                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/config/**", "/api/cache/**", "/api/orders/audit").hasRole("ADMIN")
                        // Bài 23: luật theo sản phẩm/đơn hàng chuyển xuống @PreAuthorize

                        .anyRequest().authenticated();
                })
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .httpBasic(basic -> basic.disable())
                .formLogin(form -> form.disable())
                .exceptionHandling(e -> e
                        .authenticationEntryPoint(entryPoint)        // 401 ProblemDetail
                        .accessDeniedHandler(accessDeniedHandler))   // 403 ProblemDetail
                .build();
    }

    /**
     * Bài 24 — CORS.
     *
     * CORS là cơ chế của TRÌNH DUYỆT, không phải server: request vẫn tới, server vẫn trả 200;
     * trình duyệt nhận rồi mới từ chối đưa cho JavaScript. curl và mobile app không bị ảnh hưởng.
     * CORS KHÔNG bảo vệ server — nó bảo vệ NGƯỜI DÙNG khỏi trang độc hại gọi API bằng quyền của họ.
     * Nới lỏng CORS là nới lỏng bảo vệ người dùng.
     *
     * KHÔNG "*" + credentials — đặc tả cấm: bất kỳ trang nào cũng gọi được API kèm quyền người dùng.
     * Cần linh hoạt: setAllowedOriginPatterns("https://*.shop.example") — cẩn thận "https://*" tệ ngang "*".
     *
     * exposedHeaders: mặc định JS chỉ đọc vài header cơ bản. Thiếu "Location" thì header mà
     * POST /api/products trả về (Bài 2) VÔ HÌNH với frontend.
     *
     * maxAge 1 giờ: trình duyệt cache kết quả preflight — không hỏi lại mỗi thao tác.
     * Preflight xảy ra khi: method ngoài GET/HEAD/POST, có header tuỳ chỉnh (Authorization,
     * X-Request-Id), hoặc Content-Type không đơn giản (application/json). Tức gần như mọi
     * request API có token.
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource(CorsProperties props) {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(props.allowedOrigins());
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Request-Id"));
        config.setExposedHeaders(List.of("Location", "X-Request-Id"));
        config.setAllowCredentials(true);
        config.setMaxAge(Duration.ofHours(1));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", config);
        return source;
    }

    /** AuthService cần để kiểm tra username/password lúc đăng nhập. */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }
}
