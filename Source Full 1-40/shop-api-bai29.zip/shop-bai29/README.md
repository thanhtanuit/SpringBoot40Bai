# shop-api — trạng thái sau Bài 29: Actuator và sức khoẻ hệ thống

> Làm sao biết hệ thống hỏng **trước khi** người dùng gọi điện báo.

## Chạy

```bash
docker compose up -d                    # postgres, redis, prometheus, grafana
mvn spring-boot:run
curl -s localhost:8081/actuator/health | jq
```

| | |
|---|---|
| Prometheus | http://localhost:9090 |
| Grafana | http://localhost:3000 (admin/admin) — datasource `http://prometheus:9090`, dashboard **4701** |

## Endpoint

| | dev | prod |
|---|---|---|
| `/actuator/health` (+ `/liveness`, `/readiness`) | công khai, chi tiết đầy đủ | công khai, chi tiết chỉ ADMIN |
| `/healthz`, `/readyz` | công khai | công khai |
| `/actuator/info` | công khai | công khai |
| `/actuator/prometheus` | công khai | chỉ mạng nội bộ |
| `metrics, env, beans, mappings, loggers, caches` | ADMIN | **không phơi** |

Prod dùng `base-path: /internal/actuator`.

## Thay đổi so với Bài 28

| | |
|---|---|
| `pom.xml` | + actuator, micrometer-prometheus; `build-info`; `git-commit-id-maven-plugin` |
| `application.yml` | probes, nhóm liveness/readiness, `DEGRADED` → 200, `info`, graceful shutdown |
| `health/ExchangeRateHealthIndicator` | API tỷ giá chết → `DEGRADED`, không `DOWN` |
| `metrics/OrderMetrics` | Counter, Timer (p50/p95/p99), DistributionSummary, failed theo `reason` |
| `metrics/InventoryMetrics` | Gauge sản phẩm sắp hết |
| `OrderService.datHang` | Bọc Timer + đếm |
| `SecurityConfig` | Luật cho `/actuator/**` |
| `docker-compose.yml`, `monitoring/` | Prometheus + Grafana, PromQL mẫu |

## Liveness và readiness

| | Hỏi | Fail thì |
|---|---|---|
| **Liveness** | Tiến trình còn sống? | **Restart** container |
| **Readiness** | Sẵn sàng nhận traffic? | **Rút khỏi LB**, đừng restart |

> Liveness chỉ kiểm tra **chính tiến trình**. Readiness kiểm tra **phụ thuộc**.
> Cho DB vào liveness = biến sự cố DB thoáng qua thành `CrashLoopBackOff` toàn hệ thống.

## Ba metric khi điều tra sự cố

| | |
|---|---|
| `http.server.requests` | Lưu lượng, độ trễ, tỷ lệ lỗi theo endpoint (uri là **mẫu**, không phải URL thật) |
| `jvm.memory.used{area=heap}` | Tăng đều không giảm = memory leak |
| `hikaricp.connections.pending` | Khác 0 kéo dài = pool nhỏ hoặc truy vấn chậm |

## Bẫy

| Bẫy | |
|---|---|
| Phơi `env`, `beans`, `heapdump` ở prod | Bản đồ + chìa khoá cho kẻ tấn công |
| Redis/dịch vụ phụ kéo health DOWN | LB rút mọi instance vì một cache |
| Tag chứa id | Cardinality explosion |
| Mock `OrderMetrics` trong unit test | `doThoiGian` trả null, logic không chạy — dùng `SimpleMeterRegistry` |

Bài 30 khép Phần 3: chuẩn hoá response, mã lỗi ổn định, đa ngôn ngữ.
