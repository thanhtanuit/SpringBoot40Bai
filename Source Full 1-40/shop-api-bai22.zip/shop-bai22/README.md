# shop-api — trạng thái sau Bài 22: Đăng nhập bằng JWT

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V13 (refresh_token)
```

```bash
TOKEN=$(curl -s -X POST localhost:8081/api/auth/login -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"admin12345"}' | jq -r .accessToken)
curl -H "Authorization: Bearer $TOKEN" localhost:8081/api/auth/me

# JWT KHÔNG được mã hoá — đọc payload không cần secret:
echo $TOKEN | cut -d. -f2 | base64 -d
```

## Endpoint

| | |
|---|---|
| `POST /api/auth/login` | → `accessToken` (15 phút) + `refreshToken` (7 ngày) |
| `POST /api/auth/refresh` | Xoay vòng: token cũ thu hồi, cấp cặp mới |
| `POST /api/auth/logout` | Thu hồi refresh token |
| `GET /api/auth/me` | Cần Bearer token |

## Thay đổi so với Bài 21

| | |
|---|---|
| `pom.xml` | + `jjwt-api`, `jjwt-impl`, `jjwt-jackson` 0.12.6 |
| `application*.yml` | `shop.jwt` — secret: dev có mặc định, **prod không** |
| `V13__create_refresh_token.sql` | |
| `security/JwtService` | Ký + **xác minh chữ ký**, kiểm tra ≥ 32 byte lúc boot |
| `security/JwtAuthenticationFilter` | `OncePerRequestFilter`, **không** là bean |
| `security/RefreshTokenService` | Chuỗi ngẫu nhiên, xoay vòng, phát hiện tái sử dụng |
| `SecurityConfig` | Bỏ Basic, thêm filter JWT, entry point 401 |
| `JpaAuditingConfig` | `created_by` = người đăng nhập |
| `requests.http` | Basic → `Bearer {{token}}` |

## Bẫy

| Bẫy | |
|---|---|
| Bỏ `verifyWith` | Ai cũng tự tạo token `ROLE_ADMIN` — lỗ hổng JWT phổ biến nhất |
| Đặt dữ liệu nhạy cảm vào JWT | Payload chỉ là Base64 — ai cũng đọc được |
| Refresh token là JWT | Tự bỏ khả năng thu hồi |
| Filter JWT là `@Component` | Boot đăng ký thêm lần nữa ngoài security chain → context bị ghi đè |
| Ném exception trong filter | Trang lỗi HTML thay vì JSON |
| Thu hồi phiên rồi ném exception | Rollback mất việc thu hồi — cần `noRollbackFor` (Bài 13) |
| Refresh song song từ frontend | Request thứ hai bị coi là tái sử dụng → đá người dùng ra |

## Đánh đổi của stateless

JWT **không thu hồi được**. Đuổi việc lúc 9:00, token dùng được tới 9:15. Giảm thiểu:
TTL ngắn; khẩn cấp thì blacklist trong Redis — nhưng lại bớt stateless.

Bài 23: `@PreAuthorize`, quyền sở hữu, 401/403 về đúng ProblemDetail.
