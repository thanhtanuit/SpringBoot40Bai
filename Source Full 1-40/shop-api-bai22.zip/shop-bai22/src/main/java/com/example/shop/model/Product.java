package com.example.shop.model;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

/**
 * Bài 8: record → CLASS. Entity KHÔNG THỂ là record:
 *  1. JPA cần constructor rỗng để dựng object rồi mới đổ dữ liệu vào
 *  2. JPA cần gán được vào field — record bất biến
 *  3. Hibernate cần tạo proxy KẾ THỪA class cho nạp trễ — record là final
 *
 * Lằn ranh cả khoá: ENTITY thay đổi được · DTO bất biến.
 * DTO của Bài 4 vẫn là record — đừng đổi theo.
 */
/*
 * Bài 16 — XOÁ MỀM.
 *
 * @SQLDelete: chặn DELETE, thay bằng UPDATE. Dấu ? khớp thứ tự Hibernate truyền —
 * có @Version thì là id rồi version.
 *
 * @SQLRestriction (Hibernate 6, thay @Where): chèn "deleted = false" vào MỌI truy vấn
 * sinh từ entity này — findAll, findById, derived query, Specification, JPQL.
 * Sức mạnh VÀ mối nguy: một luật ngầm áp cho toàn hệ thống mà không thấy trong code.
 *
 * uniqueConstraints đã bỏ khỏi @Table — V8 thay bằng partial unique index.
 */
@Entity
@Table(name = "product")
@SQLDelete(sql = "UPDATE product SET deleted = true, updated_at = now() WHERE id = ? AND version = ?")
@SQLRestriction("deleted = false")
public class Product extends BaseEntity {

    /** IDENTITY: cột tự tăng của database. Giá trị chỉ có SAU khi INSERT chạy. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    /** Bài 12: cột do migration V3 thêm — entity phải khớp, nếu không validate chặn lúc boot. */
    @Column(nullable = false, length = 20)
    private String sku;

    @Column(nullable = false)
    private double price;

    @Column(nullable = false)
    private int stock;

    /**
     * Bài 9 — BẪY 1: @ManyToOne mặc định là EAGER. fetch = LAZY phải VIẾT RA TAY.
     * EAGER: nạp Product là nạp luôn Category, rồi Category nạp tiếp... một findAll
     * đơn giản thành hàng chục JOIN. Quy tắc: mọi quan hệ để LAZY, khi cần thì nạp
     * CÓ CHỦ ĐÍCH bằng JOIN FETCH hoặc @EntityGraph.
     *
     * Phía "nhiều" giữ khoá ngoại: cột category_id nằm ở bảng product.
     * KHÔNG cascade — xoá sản phẩm không được kéo theo danh mục.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(nullable = false)
    private boolean deleted = false;

    /** Bài 17: tên file do server sinh, không phải đường dẫn. */
    @Column(name = "image_path", length = 255)
    private String imagePath;

    /**
     * Bài 13 — BẪY 4: LOST UPDATE. Hai request cùng đọc stock = 10, cùng trừ 1, cùng ghi 9
     * → hai đơn hàng, kho chỉ giảm một. Transaction thường KHÔNG ngăn được.
     *
     * @Version: UPDATE ... WHERE id = ? AND version = ? — khớp 0 dòng thì ném
     * OptimisticLockingFailureException → 409.
     * Xung đột hiếm → optimistic. Xung đột thường (hàng hot mùa sale) → pessimistic
     * (SELECT ... FOR UPDATE): an toàn tuyệt đối, nhưng xếp hàng, có nguy cơ deadlock.
     */
    @Version
    private Long version;

    /** protected: "cái này dành cho JPA, không phải cho bạn" — vẫn đủ quyền tạo proxy. */
    protected Product() {
    }

    /** Không nhận id — database cấp id, không phải code. */
    public Product(String name, String sku, double price, int stock) {
        this.name = name;
        this.sku = sku;
        this.price = price;
        this.stock = stock;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Long getVersion() {
        return version;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public boolean isDeleted() {
        return deleted;
    }
}
