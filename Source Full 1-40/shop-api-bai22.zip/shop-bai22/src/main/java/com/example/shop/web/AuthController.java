package com.example.shop.web;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.dto.AuthResponse;
import com.example.shop.dto.LoginRequest;
import com.example.shop.dto.RefreshRequest;
import com.example.shop.dto.RegisterRequest;
import com.example.shop.dto.UserResponse;
import com.example.shop.model.User;
import com.example.shop.service.AuthService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse dangKy(@Valid @RequestBody RegisterRequest req) {
        User user = service.dangKy(req);
        return new UserResponse(user.getId(), user.getUsername(), user.getEmail(),
                user.getRoles().stream().map(Enum::name).sorted().toList());
    }

    @PostMapping("/login")
    public AuthResponse dangNhap(@Valid @RequestBody LoginRequest req) {
        return service.dangNhap(req);
    }

    @PostMapping("/refresh")
    public AuthResponse lamMoi(@Valid @RequestBody RefreshRequest req) {
        return service.lamMoi(req.refreshToken());
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void dangXuat(@Valid @RequestBody RefreshRequest req) {
        service.dangXuat(req.refreshToken());
    }

    /** Cần access token hợp lệ. Dùng ở Bài 23, 24. */
    @GetMapping("/me")
    public UserResponse toi(@AuthenticationPrincipal UserDetails user) {
        return service.thongTinHienTai(user.getUsername());
    }
}
