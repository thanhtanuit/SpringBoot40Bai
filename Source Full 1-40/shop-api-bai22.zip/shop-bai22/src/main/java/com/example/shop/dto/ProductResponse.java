package com.example.shop.dto;

import java.time.Instant;

/**
 * Bài 16 thêm createdAt, updatedAt — MapStruct tự map từ BaseEntity vì tên trùng.
 * (unmappedTargetPolicy=ERROR sẽ báo nếu có gì không khớp.)
 */
public record ProductResponse(
        Long id,
        String name,
        String sku,
        double price,
        int stock,
        String categoryName,
        Instant createdAt,
        Instant updatedAt
) {
}
