package com.example.shop.mapper;

import java.util.List;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.example.shop.dto.ProductResponse;
import com.example.shop.dto.UpdateProductRequest;
import com.example.shop.model.Product;

/**
 * Bài 14: XOÁ ProductMapper viết tay của Bài 4, thay bằng INTERFACE.
 * Bạn khai báo chuyển cái gì sang cái gì — MapStruct viết code.
 *
 * ĐỌC CODE SINH RA (tập thành thói quen):
 *   mvn clean compile
 *   target/generated-sources/annotations/com/example/shop/mapper/ProductMapperImpl.java
 * Java thường, gọi getter trực tiếp — KHÔNG reflection, không proxy. Gần giống hệt bản
 * viết tay Bài 4, chỉ do máy gõ. Mapper cư xử lạ? Mở file đó ra — nó luôn trả lời được
 * "vì sao field này null".
 *
 * So với ModelMapper/Dozer: reflection lúc chạy, chậm hơn, lỗi lộ ra ở RUNTIME.
 * MapStruct: sai là build đỏ.
 */
@Mapper(componentModel = "spring")
public interface ProductMapper {

    /**
     * Trường trùng tên tự khớp. Chỉ khai phần LỆCH: categoryName ← category.name.
     * Đi sâu nhiều tầng được (category.parent.name); mỗi tầng tự chèn kiểm tra null —
     * đoạn "p.getCategory() != null ? ... : null" bạn tự viết ở Bài 10 giờ được lo hộ.
     */
    @Mapping(source = "category.name", target = "categoryName")
    ProductResponse toResponse(Product product);

    /** Không annotation: MapStruct thấy có toResponse(Product) và tự dùng cho từng phần tử. */
    List<ProductResponse> toResponseList(List<Product> products);

    /**
     * Nâng cao — PATCH tổng quát.
     *
     * @MappingTarget: đích ĐÃ TỒN TẠI — ghi đè lên nó, không tạo mới.
     * IGNORE: field null trong nguồn → bỏ qua, giữ giá trị cũ.
     * Gửi {"price": 990000} → chỉ giá đổi. Service không gọi save — dirty checking (Bài 8).
     *
     * GIỚI HẠN: "không gửi" và "gửi null để xoá" đều thành null → đều bị bỏ qua.
     * Cần phân biệt: bọc trường trong JsonNullable (thư viện riêng).
     *
     * CHẶN MASS ASSIGNMENT (Bài 4): với unmappedTargetPolicy=ERROR, mọi trường đích
     * không map đều phải TUYÊN BỐ. category không được client gán qua request này.
     * Thử xoá dòng ignore bên dưới rồi build:
     *   BUILD FAILURE — Unmapped target property: "category"
     * Lỗ hổng tiềm ẩn thành lỗi biên dịch. (id, createdAt, version không có setter
     * nên vốn không phải trường đích.)
     */
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "category", ignore = true)
    @Mapping(target = "imagePath", ignore = true)   // Bài 17: ảnh đổi qua endpoint riêng
    void updateFromRequest(UpdateProductRequest request, @MappingTarget Product entity);
}
