package com.example.shop.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Product;
import com.example.shop.repository.ProductRepository;

import jakarta.annotation.PostConstruct;

/**
 * Bài 7 — log đúng cách.
 *
 * static final: một logger cho cả class. Tên logger = tên class đầy đủ
 * (com.example.shop.service.ProductService) — chính là thứ logging.level áp theo
 * tiền tố package. Code chỉ import org.slf4j (giao diện), không bao giờ Logback.
 *
 * Năm mức — câu hỏi để chọn: "Chuyện này có cần đánh thức ai dậy lúc 2 giờ sáng?"
 *   error  hệ thống hỏng, cần người xử lý           (bật ở prod)
 *   warn   bất thường nhưng đã xử lý: 404, trùng tên (bật ở prod)
 *   info   sự kiện nghiệp vụ: tạo, xoá               (bật ở prod)
 *   debug  chi tiết để lần theo luồng                (tắt ở prod)
 *   trace  rất chi tiết                              (tắt ở prod)
 *
 * BẪY 1: dùng chỗ trống {}, KHÔNG nối chuỗi bằng dấu +.
 *   log.debug("Tạo {} giá {}", name, price)   debug tắt → một phép kiểm tra rồi thoát
 *   log.debug("Tạo " + name + " giá " + price) ghép chuỗi TRƯỚC khi gọi, trả giá mọi lần
 * Tham số cần tính toán nặng thì placeholder cũng không cứu — bọc if (log.isDebugEnabled()).
 *
 * BẪY 3: KHÔNG BAO GIỜ log mật khẩu, token, số thẻ. Log lưu lâu hơn database
 * và nhiều người đọc được hơn.
 */
@Service
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    @PostConstruct
    void logRepoDangDung() {
        log.info("ProductService đang dùng repository: {}", repo.getClass().getSimpleName());
    }

    public List<Product> findAll() {
        List<Product> ds = repo.findAll();
        log.debug("Trả về {} sản phẩm", ds.size());
        return ds;
    }

    public Product findById(Long id) {
        log.debug("Tìm sản phẩm id={}", id);
        return repo.findById(id).orElseThrow(() -> {
            // Trong lambda: chỉ chạy khi THẬT SỰ không tìm thấy
            log.warn("Không tìm thấy sản phẩm id={}", id);
            return new ResourceNotFoundException("Sản phẩm", id);
        });
    }

    public Product create(String name, double price, Integer stock) {
        log.debug("Yêu cầu tạo sản phẩm name={} price={} stock={}", name, price, stock);
        kiemTraTrungTen(name, null);
        Product moi = repo.save(new Product(null, name, price, stock == null ? 0 : stock));
        // Cặp trước–sau: thấy "Yêu cầu tạo" mà không thấy "Đã tạo" → biết ngay đứt ở giữa
        log.info("Đã tạo sản phẩm id={} name={}", moi.id(), moi.name());
        return moi;
    }

    public Product update(Long id, String name, double price, Integer stock) {
        log.debug("Yêu cầu sửa sản phẩm id={}", id);
        findById(id);
        kiemTraTrungTen(name, id);
        Product moi = repo.save(new Product(id, name, price, stock == null ? 0 : stock));
        log.info("Đã sửa sản phẩm id={}", id);
        return moi;
    }

    public Product updatePrice(Long id, double price) {
        Product cu = findById(id);
        Product moi = repo.save(new Product(cu.id(), cu.name(), price, cu.stock()));
        log.info("Đã đổi giá sản phẩm id={} từ {} sang {}", id, cu.price(), price);
        return moi;
    }

    public void delete(Long id) {
        findById(id);
        repo.deleteById(id);
        log.info("Đã xoá sản phẩm id={}", id);
    }

    /**
     * Lưu ý: GlobalExceptionHandler (Bài 5) CŨNG log sự kiện này → hai dòng cho một chuyện.
     * Ở mức học thì chấp nhận; dự án thật nên chọn MỘT chỗ — thường là handler,
     * nơi biết cả mã HTTP lẫn đường dẫn.
     */
    private void kiemTraTrungTen(String name, Long boQuaId) {
        boolean trung = repo.findAll().stream()
                .anyMatch(p -> p.name() != null
                        && p.name().equalsIgnoreCase(name)
                        && !p.id().equals(boQuaId));
        if (trung) {
            log.warn("Từ chối vì trùng tên: {}", name);
            throw new DuplicateResourceException("Đã tồn tại sản phẩm tên: " + name);
        }
    }
}
