# shop-api — trạng thái sau Bài 7: Logging

> Hai giờ sáng, hệ thống hỏng. Không debugger, không breakpoint. Chỉ còn log.

## Chạy

```bash
mvn spring-boot:run                                              # dev: chữ, console + file
PAYMENT_API_KEY=abc mvn spring-boot:run -Dspring-boot.run.profiles=prod   # prod: JSON
```

Log ghi vào `logs/shop-api.log`, xoay vòng theo ngày và kích thước.

## Lần theo một request

```
10:15:30.120 DEBUG [a3f9c2e1] c.e.shop.service.ProductService : Yêu cầu tạo sản phẩm name=...
10:15:30.125  INFO [a3f9c2e1] c.e.shop.service.ProductService : Đã tạo sản phẩm id=3 ...
10:15:30.410  WARN [b7d14f88] c.e.shop.service.ProductService : Không tìm thấy sản phẩm id=9999
```

```bash
grep a3f9c2e1 logs/shop-api.log
```

## Cấu trúc mới

```
src/main/
├── java/com/example/shop/
│   ├── service/ProductService.java   log đủ các mức, placeholder {}
│   └── web/RequestIdFilter.java      MDC + X-Request-Id, MDC.clear() trong finally
└── resources/
    ├── application.yml               pattern có %X{requestId}, file + rolling
    └── logback-spring.xml            dev: chữ · prod: JSON
```

## Năm mức

| Mức | Dùng khi | Prod |
|---|---|---|
| error | Hệ thống hỏng, cần người xử lý | Bật |
| warn | Bất thường đã xử lý — 404, trùng tên | Bật |
| info | Sự kiện nghiệp vụ — tạo, xoá | Bật |
| debug | Lần theo luồng khi điều tra | Tắt |
| trace | Rất chi tiết | Tắt |

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Nối chuỗi `"a" + b` trong log | Dùng chỗ trống `{}` |
| Quên `MDC.clear()` | Luôn đặt trong `finally` — Tomcat tái sử dụng thread |
| Log mật khẩu, token | Không bao giờ |

## Thí nghiệm

Xoá dòng `MDC.clear()`, gửi vài request liên tiếp → mã request dính lại từ request trước.
Đổi lại ngay.
