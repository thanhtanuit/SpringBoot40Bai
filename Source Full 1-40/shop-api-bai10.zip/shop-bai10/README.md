# shop-api — trạng thái sau Bài 10: Truy vấn và phân trang (hết Phần 1)

## Chạy

```bash
mvn spring-boot:run
```

Cổng 8081. H2 console: http://localhost:8081/h2-console (`jdbc:h2:mem:shopdb`, user `sa`).

## Endpoint sản phẩm

| Request | Ghi chú |
|---|---|
| `GET /api/products?page=0&size=10&sort=price,desc` | `PageResponse`, 2 câu SQL |
| `GET /api/products/scroll` | `SliceResponse`, 1 câu SQL — cho cuộn vô hạn |
| `GET /api/products/search?keyword=&minPrice=&maxPrice=&categoryId=` | Bốn bộ lọc tuỳ chọn |
| `GET /api/products/best-sellers?limit=5` | `@Query` GROUP BY |
| `GET/POST/PUT/DELETE /api/products/{id}` · `PATCH /{id}/price` | Như Bài 9 |

`size` bị ép về `shop.max-items-per-page` (20 ở dev, 50 ở prod).

## Phép đo đầu tiên: 7 → 2

`GET /api/products?size=5`, đếm SELECT trong log:

| | Số câu |
|---|---|
| Không `@EntityGraph` | 1 dữ liệu + 1 count + 5 nạp category = **7** |
| Có `@EntityGraph(attributePaths = "category")` | **2** |

Thử: xoá `@EntityGraph` trên `findAll(Pageable)` trong `ProductRepository` — sẽ gặp
`LazyInitializationException` (vì `open-in-view: false`). Bật tạm
`spring.jpa.open-in-view: true` để thấy 7 câu, rồi trả lại.

## Ba bậc viết truy vấn

| Khi | Dùng |
|---|---|
| 1–2 điều kiện, cố định | Derived query |
| Phức tạp nhưng cố định (GROUP BY, JOIN) | `@Query` |
| Số điều kiện đổi theo request | Specification — **Bài 15** |

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Không chặn trần `size` | `chuanHoa()` + `max-page-size` |
| Trả thẳng `Page<T>` ra API | `PageResponse` — hợp đồng do mình kiểm soát |
| Fetch collection + phân trang | Hibernate nạp hết về RAM — Bài 39 |

## Hết Phần 1 — những món nợ

| Nợ | Bài |
|---|---|
| H2 mất dữ liệu khi restart | 11 |
| Schema do Hibernate sinh | 12 |
| `@Transactional` theo cảm tính | 13 |
| Mapper viết tay | 14 |
| Truy vấn động bằng `IS NULL OR` | 15 |
| Chưa có bảo mật | 21 |

Bài 11 cần **Docker Desktop** chạy sẵn.
