# shop-api — trạng thái sau Bài 23: Phân quyền theo vai trò

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy V14 (user1), V15 (cost_price)
```

| Tài khoản | Mật khẩu | Role |
|---|---|---|
| `admin` | `admin12345` | ADMIN |
| `seller` | `seller12345` | SELLER |
| `user1` | `user12345` | USER |

## Ma trận quyền — tài liệu để viết test ở Bài 26

| Endpoint | Ẩn danh | USER | SELLER | ADMIN |
|---|---|---|---|---|
| `POST /api/auth/register · login · refresh` | ✅ | ✅ | ✅ | ✅ |
| `GET /api/auth/me` | 401 | ✅ | ✅ | ✅ |
| `GET /api/products/**` | ✅ | ✅ | ✅ | ✅ |
| — trường `costPrice` | ẩn | ẩn | ẩn | **hiện** |
| `POST · PUT · PATCH /api/products/{id}` | 401 | 403 | ✅ | ✅ |
| `DELETE /api/products/{id}` | 401 | 403 | 403 | ✅ |
| `POST · DELETE /api/products/{id}/image` | 401 | 403 | ✅ | ✅ |
| `POST /api/orders` | 401 | ✅ | ✅ | ✅ |
| `GET /api/orders/{id}` | 401 | chủ đơn | chủ đơn | mọi đơn |
| `/api/admin/**`, `/api/config/**`, `/api/cache/**` | 401 | 403 | 403 | ✅ |

## Thay đổi so với Bài 22

| | |
|---|---|
| `V14`, `V15` | `user1`; `cost_price` |
| `SecurityConfig` | `@EnableMethodSecurity`, URL chỉ còn luật thô, entry point + handler JSON |
| `security/JsonAuthenticationEntryPoint`, `JsonAccessDeniedHandler` | 401/403 ProblemDetail |
| `security/OrderSecurity` | `@orderSecurity.isOwner(#id, authentication)` |
| `web/ProductPresenter` | Ẩn `costPrice` với người không phải ADMIN — trên DTO, nên áp được cả dữ liệu cache |
| Controller | `@PreAuthorize` |
| `GlobalExceptionHandler` | + `AccessDeniedException` → 403 (không thì `handleAll` biến thành 500) |

## 401 và 403

| | Nghĩa | Client làm gì |
|---|---|---|
| **401** | "Tôi không biết bạn là ai" — đúng ra là *Unauthenticated* | Đăng nhập lại / refresh |
| **403** | "Tôi biết bạn là ai, câu trả lời là không" | Hiện "không đủ quyền", đừng thử lại |

## Bẫy

| Bẫy | |
|---|---|
| `@PreAuthorize` thất bại từ controller | Không qua `AccessDeniedHandler` — cần handler trong advice |
| Để frontend ẩn dữ liệu | Không phải bảo mật — DevTools thấy hết |
| `@PostAuthorize` trên method có tác dụng phụ | Đã chạy xong mới kiểm |
| Quyền nằm trong JWT | Đổi quyền không có hiệu lực tới khi token hết hạn |

## Nâng cao — role hay permission

Khi bắt đầu thấy `ADMIN_READONLY`, `SELLER_LIMITED_NO_DELETE`: tách **permission**
(`PRODUCT_DELETE`, `ORDER_READ_ANY`...) khỏi role, `@PreAuthorize("hasAuthority('PRODUCT_DELETE')")`.
Dưới 5 role và luật đơn giản thì role là đủ.

Bài 24: frontend Vue — và CORS.
