package com.example.shop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.shop.security.JsonAccessDeniedHandler;
import com.example.shop.security.JsonAuthenticationEntryPoint;
import com.example.shop.security.JwtAuthenticationFilter;
import com.example.shop.security.JwtService;

/**
 * Bài 22 — JWT. Bài 23 — phân quyền HAI TẦNG, bổ sung nhau:
 *
 *  Tầng URL (authorizeHttpRequests) — hàng rào THÔ, chặn sớm trước controller. Luật rộng theo đường dẫn.
 *  Tầng phương thức (@PreAuthorize) — luật CHI TIẾT nằm cạnh code. Đọc method là biết ai được gọi,
 *  và áp cho MỌI đường gọi tới method đó.
 *
 * anyRequest().authenticated() là LƯỚI AN TOÀN: quên @PreAuthorize ở đâu thì ít nhất vẫn phải đăng nhập.
 *
 * STATELESS — instance nào cũng xử lý được request nào.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity           // prePostEnabled = true là mặc định
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, JwtService jwtService,
                                           UserDetailsService userDetailsService,
                                           JsonAuthenticationEntryPoint entryPoint,
                                           JsonAccessDeniedHandler accessDeniedHandler) throws Exception {
        // Tạo bằng new — KHÔNG để filter là bean (xem comment trong JwtAuthenticationFilter)
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtService, userDetailsService);

        return http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/login", "/api/auth/register",
                                "/api/auth/refresh", "/api/auth/logout").permitAll()
                        .requestMatchers("/api/hello", "/api/hello/**", "/api/tinh").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()
                        .requestMatchers("/error").permitAll()

                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/config/**", "/api/cache/**", "/api/orders/audit").hasRole("ADMIN")
                        // Bài 23: luật theo sản phẩm/đơn hàng chuyển xuống @PreAuthorize

                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .httpBasic(basic -> basic.disable())
                .formLogin(form -> form.disable())
                .exceptionHandling(e -> e
                        .authenticationEntryPoint(entryPoint)        // 401 ProblemDetail
                        .accessDeniedHandler(accessDeniedHandler))   // 403 ProblemDetail
                .build();
    }

    /** AuthService cần để kiểm tra username/password lúc đăng nhập. */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }
}
