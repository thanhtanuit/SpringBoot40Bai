# shop-api — trạng thái sau Bài 5: Xử lý lỗi tập trung

## Chạy

```bash
mvn spring-boot:run
```

Cổng 8081. Mở `requests.http`, chạy phần "Bài 5" cuối file.

## Ba món nợ đã trả

| Nợ từ | Trước | Sau Bài 5 |
|---|---|---|
| Bài 2 | "Không thấy thì 404" lặp khắp controller | Service ném, một handler lo |
| Bài 3 | Trùng tên → 500 | 409 Conflict |
| Bài 4 | 400 không nói trường nào sai | Có `errors` theo từng trường |

## Cấu trúc

```
src/main/java/com/example/shop/
├── exception/
│   ├── ResourceNotFoundException.java   extends RuntimeException, giữ resource + id
│   ├── DuplicateResourceException.java
│   └── GlobalExceptionHandler.java      @RestControllerAdvice, ProblemDetail
├── service/ProductService.java          ném exception thay vì trả Optional
└── web/ProductController.java           không còn notFound(), không try-catch
```

## Sáu handler

| Exception | Mã | Mức log |
|---|---|---|
| `ResourceNotFoundException` | 404 | warn |
| `DuplicateResourceException` | 409 | warn |
| `MethodArgumentNotValidException` | 400 + `errors` | warn |
| `HttpMessageNotReadableException` | 400 | warn |
| `MethodArgumentTypeMismatchException` | 400 | warn |
| `Exception` (lưới an toàn) | 500 | error + stack trace |

## Ví dụ response

```json
{
  "type": "https://shop-api.example.com/errors/validation",
  "title": "Dữ liệu không hợp lệ",
  "status": 400,
  "detail": "Có 3 trường không hợp lệ",
  "instance": "/api/products",
  "timestamp": "2026-09-27T10:15:30Z",
  "errors": {
    "name": "Tên sản phẩm phải từ 2 đến 100 ký tự",
    "price": "Giá phải lớn hơn 0",
    "stock": "Tồn kho không được âm"
  }
}
```

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Exception nghiệp vụ `extends Exception` | `extends RuntimeException` — rollback đúng, code sạch |
| Trả `ex.getMessage()` / stack trace ra client | Chi tiết kỹ thuật chỉ vào log |
| Mọi lỗi đều `log.error` | 4xx `warn`, 500 `error` kèm stack trace |

## Thí nghiệm

Tạm xoá `handleNotFound`, gọi `GET /api/products/9999` → lỗi rơi vào `handleAll`, ra 500.
Đó là lý do cần handler riêng.
