# shop-api — trạng thái sau Bài 13: Transaction

> `@Transactional` đã nằm khắp service từ Bài 8. Nó **làm gì** —
> và khi nào nó **âm thầm không làm gì cả**?

## Chạy

```bash
docker compose up -d
mvn spring-boot:run          # Flyway chạy thêm V4 (audit_log), V5 (version)
```

Kiểm tra bằng SQL, **không tin response**:

```bash
docker compose exec postgres psql -U shop -d shop
SELECT id, name, stock, version FROM product ORDER BY id;
SELECT id, customer_name, total_amount FROM orders;
SELECT id, action, entity, entity_id, detail FROM audit_log ORDER BY id;
```

## Thay đổi so với Bài 12

| | |
|---|---|
| `V4__create_audit_log.sql`, `V5__add_product_version.sql` | Migration mới — không sửa file cũ |
| `model/AuditLog.java`, `AuditLogRepository` | Nhật ký |
| `service/AuditService.java` | `REQUIRES_NEW`, class riêng |
| `service/OrderService.java` | Ba bước + công tắc `"LOI"` + comment ba thí nghiệm |
| `service/ProductService.java` | `readOnly = true` cấp class, đè cho method ghi |
| `model/Product.java` | `@Version` |
| `GlobalExceptionHandler` | + `OptimisticLockingFailureException` → 409 |
| `OrderController` | + `GET /api/orders/audit` |

## Bốn thí nghiệm (chi tiết trong comment `OrderService`)

1. **Tháo `@Transactional`** → đơn "LOI": kho giảm, đơn lưu, audit trống.
2. **Checked exception** → dữ liệu vẫn commit dù có `@Transactional`.
3. **Self-invocation** → gọi qua `this`, transaction mất tác dụng.
4. **Hai `curl` song song** → bắt được một lần 409 xung đột version.

## Ba điều mang theo

1. Một nghiệp vụ là **một** transaction.
2. `@Transactional` chỉ chạy khi lời gọi **đi qua proxy**.
3. Transaction **không** tự bảo vệ khỏi mọi thứ.

## Bốn cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Checked exception không rollback | `extends RuntimeException` hoặc `rollbackFor` |
| Self-invocation | Tách class · tự tiêm `@Lazy` · `TransactionTemplate` |
| `REQUIRES_NEW` chiếm hai connection | Dùng có chọn lọc |
| Lost update | `@Version` hoặc `SELECT ... FOR UPDATE` |
