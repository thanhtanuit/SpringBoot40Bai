package com.example.shop.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.dto.BestSellerResponse;
import com.example.shop.exception.DuplicateResourceException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Product;
import com.example.shop.repository.OrderItemRepository;
import com.example.shop.repository.ProductRepository;

/**
 * Bài 13 — mẫu hay dùng: readOnly = true ở CẤP CLASS, đè bằng @Transactional thường
 * cho method GHI. Method đọc tự thừa hưởng, không phải nhớ gắn từng cái.
 *
 * readOnly làm ba việc: Hibernate bỏ dirty checking (không chụp bản sao entity);
 * driver báo DB giao dịch chỉ đọc; tín hiệu định tuyến sang bản sao chỉ đọc.
 * KHÔNG phải rào chắn bảo mật — SQL thuần vẫn ghi được.
 */
@Service
@Transactional(readOnly = true)
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository repo;
    private final OrderItemRepository orderItemRepo;

    public ProductService(ProductRepository repo, OrderItemRepository orderItemRepo) {
        this.repo = repo;
        this.orderItemRepo = orderItemRepo;
    }

    /** Hai câu SQL: một lấy dữ liệu trang (offset/fetch first), một SELECT count. */
    public Page<Product> findAll(Pageable pageable) {
        Page<Product> trang = repo.findAll(pageable);
        log.debug("Trang {} — {} / {} sản phẩm", pageable.getPageNumber(),
                trang.getNumberOfElements(), trang.getTotalElements());
        return trang;
    }

    /** Một câu SQL — Slice bỏ câu count. */
    public Slice<Product> scroll(Pageable pageable) {
        return repo.findSliceBy(pageable);
    }

    public Page<Product> search(String keyword, Double minPrice, Double maxPrice,
                                Long categoryId, Pageable pageable) {
        String kw = (keyword == null || keyword.isBlank()) ? null : keyword.trim();
        return repo.search(kw, minPrice, maxPrice, categoryId, pageable);
    }

    public List<BestSellerResponse> bestSellers(int limit) {
        return orderItemRepo.findBestSellers(PageRequest.of(0, limit));
    }

    public Product findById(Long id) {
        log.debug("Tìm sản phẩm id={}", id);
        return repo.findById(id).orElseThrow(() -> {
            log.warn("Không tìm thấy sản phẩm id={}", id);
            return new ResourceNotFoundException("Sản phẩm", id);
        });
    }

    @Transactional
    public Product create(String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu tạo sản phẩm name={} sku={} price={} stock={}", name, sku, price, stock);
        if (repo.existsByNameIgnoreCase(name)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySku(sku)) {
            tuChoiTrungSku(sku);
        }
        Product moi = repo.save(new Product(name, sku, price, stock == null ? 0 : stock));
        log.info("Đã tạo sản phẩm id={} name={}", moi.getId(), moi.getName());
        return moi;
    }

    /**
     * DIRTY CHECKING: không có repo.save() ở đâu cả, dữ liệu vẫn được lưu.
     *
     * Entity lấy ra BÊN TRONG giao dịch ở trạng thái managed. Hibernate giữ bản chụp
     * giá trị lúc nạp; tới lúc commit so sánh, thấy khác thì tự sinh UPDATE.
     *
     * BẪY: hệ quả ngược cũng đúng — sửa một entity managed mà KHÔNG định lưu
     * (ví dụ đổi giá tạm để tính toán) thì tới lúc commit nó VẪN bị lưu.
     */
    @Transactional
    public Product update(Long id, String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu sửa sản phẩm id={}", id);
        Product p = findById(id);
        if (repo.existsByNameIgnoreCaseAndIdNot(name, id)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySkuAndIdNot(sku, id)) {
            tuChoiTrungSku(sku);
        }
        p.setName(name);
        p.setSku(sku);
        p.setPrice(price);
        p.setStock(stock == null ? 0 : stock);
        log.info("Đã sửa sản phẩm id={}", id);
        return p;
    }

    @Transactional
    public Product updatePrice(Long id, double price) {
        Product p = findById(id);
        double giaCu = p.getPrice();
        p.setPrice(price);
        log.info("Đã đổi giá sản phẩm id={} từ {} sang {}", id, giaCu, price);
        return p;
    }

    @Transactional
    public void delete(Long id) {
        repo.delete(findById(id));
        log.info("Đã xoá sản phẩm id={}", id);
    }

    private void tuChoiTrungSku(String sku) {
        log.warn("Từ chối vì trùng SKU: {}", sku);
        throw new DuplicateResourceException("Đã tồn tại sản phẩm SKU: " + sku);
    }

    private void tuChoiTrungTen(String name) {
        log.warn("Từ chối vì trùng tên: {}", name);
        throw new DuplicateResourceException("Đã tồn tại sản phẩm tên: " + name);
    }
}
