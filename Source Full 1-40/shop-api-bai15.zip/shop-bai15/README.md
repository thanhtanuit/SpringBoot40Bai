# shop-api — trạng thái sau Bài 15: Tìm kiếm động với Specification

> Dọn cái mớ `:param IS NULL OR ...` của Bài 10.
> Bộ lọc không gửi thì **biến mất hẳn** khỏi câu SQL.

## Chạy

```bash
docker compose up -d
mvn spring-boot:run
```

Mở phần "Bài 15" trong `requests.http`, gọi lần lượt và **đọc mệnh đề WHERE** trong log.

## Thay đổi so với Bài 14

| | |
|---|---|
| `ProductRepository` | + `JpaSpecificationExecutor`, **xoá** `search(...)` JPQL; `findAll(spec, pageable)` có `@EntityGraph` |
| `repository/spec/ProductSpecs.java` | **Mới** — mỗi bộ lọc một hàm, rỗng → `null` |
| `dto/ProductFilter.java` | **Mới** — nhận qua `@ModelAttribute` |
| `ProductService.search` | `Specification.allOf(...)` |
| `ProductController.search` | Một tham số filter thay vì bốn `@RequestParam` |

## Bộ lọc

| Tham số | Spec | SQL |
|---|---|---|
| `keyword` | `hasKeyword` | `lower(name) like ?` |
| `minPrice` / `maxPrice` | `priceGte` / `priceLte` | `price >= ?` / `price <= ?` |
| `categoryId` | `inCategory` | `category_id = ?` — **không** JOIN |
| `categoryName` | `categoryNameLike` | `inner join category` |
| `inStock` | `inStock` | `stock > 0` hoặc `stock = 0` |

## So với Bài 10

```sql
-- Bài 10, chỉ gửi keyword:
where (? is null or lower(p.name) like ...) and (? is null or p.price >= ?)
  and (? is null or p.price <= ?) and (? is null or c.id = ?)

-- Bài 15, chỉ gửi keyword:
where lower(p1_0.name) like ?
```

Với `(? IS NULL OR ...)`, bộ tối ưu không biết trước tham số có null không nên thường
bỏ qua index. Bài 39 đo bằng `EXPLAIN ANALYZE`.

## Lưu ý

| | |
|---|---|
| `root.get("name")` là chuỗi | Gõ sai là lỗi **lúc chạy** — nâng cao: static metamodel |
| Đừng `root.fetch(...)` trong spec | Spring Data dùng cùng spec cho câu count — fetch trong count là lỗi. Dùng `@EntityGraph` |
| AND / OR | `Specification.allOf(...)` / `Specification.anyOf(...)` |
