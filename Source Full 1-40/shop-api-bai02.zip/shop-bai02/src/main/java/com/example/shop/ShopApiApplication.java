package com.example.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Điểm khởi động của cả ứng dụng.
 *
 * @SpringBootApplication gộp ba annotation:
 *  - @Configuration            : nơi khai báo cấu hình
 *  - @EnableAutoConfiguration  : nhìn thư viện có trong classpath rồi tự cấu hình theo
 *                                (có Spring Web → tự dựng Tomcat, tự đăng ký Jackson)
 *  - @ComponentScan            : quét class từ package CỦA CHÍNH class này TRỞ XUỐNG
 *
 * BẪY 1: class này nằm ở com.example.shop, nên mọi controller/service phải nằm
 * trong com.example.shop hoặc package con. Đặt ở com.example.controller
 * (thiếu chữ "shop") thì Spring không thấy → gọi API ra 404, KHÔNG báo lỗi gì.
 */
@SpringBootApplication
public class ShopApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopApiApplication.class, args);
    }
}
