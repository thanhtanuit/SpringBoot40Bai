package com.example.shop.web;

/**
 * Sản phẩm. Bài 2 để tạm ở package web; Bài 3 chuyển sang package model.
 */
public record Product(Long id, String name, double price) {
}
