package com.example.shop.web;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 * CRUD sản phẩm, dữ liệu nằm trong bộ nhớ.
 *
 *   GET    /api/products              200
 *   GET    /api/products/{id}         200 | 404
 *   POST   /api/products              201 + Location
 *   PUT    /api/products/{id}         200 | 404
 *   DELETE /api/products/{id}         204 | 404
 *   PATCH  /api/products/{id}/price   200 | 404   (nâng cao)
 *
 * Những chỗ CÒN TỆ, cố tình để lại cho các bài sau:
 *  - Dữ liệu nằm ngay trong controller           → Bài 3 tách tầng
 *  - Không kiểm tra dữ liệu (tên rỗng, giá âm)   → Bài 4 validation
 *  - "Không thấy thì 404" lặp lại ở nhiều chỗ    → Bài 5 xử lý lỗi tập trung
 *  - Restart là mất dữ liệu                      → Bài 8 database thật
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {

    /*
     * BẪY 1: controller là SINGLETON — cả ứng dụng chỉ có một object,
     * trong khi Tomcat xử lý mỗi request trên một thread riêng.
     * ArrayList thường: hai request cùng thêm có thể làm hỏng danh sách.
     * long thường: hai request cùng tăng id có thể ra id trùng.
     * Tự test một mình thì không bao giờ thấy lỗi này.
     */
    private final List<Product> products = new CopyOnWriteArrayList<>();
    private final AtomicLong idSeq = new AtomicLong(0);

    @GetMapping
    public List<Product> findAll() {
        return products;
    }

    /**
     * Trả Product trần thì Spring LUÔN trả 200, kể cả khi không tìm thấy.
     * ResponseEntity cho phép điều khiển cả mã trạng thái lẫn header.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Product> findById(@PathVariable Long id) {
        return timTheoId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * BẪY 2: bỏ qua id client gửi lên. Server là nơi DUY NHẤT được cấp id.
     * Tạo mới trả 201 Created kèm header Location trỏ tới tài nguyên vừa tạo.
     */
    @PostMapping
    public ResponseEntity<Product> create(@RequestBody Product body) {
        Product moi = new Product(idSeq.incrementAndGet(), body.name(), body.price());
        products.add(moi);

        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(moi.id())
                .toUri();
        return ResponseEntity.created(location).body(moi);
    }

    /**
     * PUT = thay thế TOÀN BỘ. Body thiếu price thì price về 0 — đúng chuẩn PUT.
     * Record bất biến nên "sửa" nghĩa là tạo object mới đặt vào chỗ cũ.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Product> update(@PathVariable Long id, @RequestBody Product body) {
        int i = viTri(id);
        if (i < 0) {
            return ResponseEntity.notFound().build();
        }
        Product moi = new Product(id, body.name(), body.price());
        products.set(i, moi);
        return ResponseEntity.ok(moi);
    }

    /**
     * BẪY 3: xoá thành công trả 204 No Content — thành công, cố tình không có gì
     * để trả về. Đừng trả 200 kèm "Xoá thành công".
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        int i = viTri(id);
        if (i < 0) {
            return ResponseEntity.notFound().build();
        }
        products.remove(i);
        return ResponseEntity.noContent().build();
    }

    /**
     * Nâng cao — PATCH = sửa MỘT PHẦN. Giữ nguyên tên, chỉ đổi giá.
     */
    @PatchMapping("/{id}/price")
    public ResponseEntity<Product> updatePrice(@PathVariable Long id, @RequestBody PriceUpdate body) {
        int i = viTri(id);
        if (i < 0) {
            return ResponseEntity.notFound().build();
        }
        Product cu = products.get(i);
        Product moi = new Product(cu.id(), cu.name(), body.price());
        products.set(i, moi);
        return ResponseEntity.ok(moi);
    }

    private Optional<Product> timTheoId(Long id) {
        return products.stream().filter(p -> p.id().equals(id)).findFirst();
    }

    private int viTri(Long id) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).id().equals(id)) {
                return i;
            }
        }
        return -1;
    }
}
