package com.example.shop.web;

/**
 * Body cho PATCH /api/products/{id}/price — chỉ có đúng trường price.
 * Client không cần (và không nên phải) gửi tên khi chỉ muốn đổi giá.
 */
public record PriceUpdate(double price) {
}
