package com.example.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Test mặc định của start.spring.io: chỉ kiểm tra ứng dụng khởi động được.
 * Test thật sự bắt đầu từ Bài 25.
 */
@SpringBootTest
class ShopApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
