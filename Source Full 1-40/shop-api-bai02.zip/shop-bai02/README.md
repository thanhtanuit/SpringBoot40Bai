# shop-api — trạng thái sau Bài 2: CRUD trong bộ nhớ

## Chạy

```bash
mvn spring-boot:run
```

Cổng 8081. Mở `requests.http` trong IntelliJ, bấm ▶ lần lượt từ trên xuống.

## Endpoint

| Phương thức | Đường dẫn | Thành công | Không thấy |
|---|---|---|---|
| GET | `/api/products` | 200 | — |
| GET | `/api/products/{id}` | 200 | 404 |
| POST | `/api/products` | 201 + `Location` | — |
| PUT | `/api/products/{id}` | 200 | 404 |
| DELETE | `/api/products/{id}` | 204 | 404 |
| PATCH | `/api/products/{id}/price` | 200 | 404 |

Endpoint của Bài 1 (`/api/hello`, `/api/hello/{ten}`, `/api/tinh`) vẫn giữ nguyên.

## Cấu trúc

```
src/main/java/com/example/shop/
├── ShopApiApplication.java
└── web/
    ├── HelloController.java     Bài 1
    ├── KetQua.java              Bài 1
    ├── Product.java             record (id, name, price)
    ├── PriceUpdate.java         body cho PATCH
    └── ProductController.java   CRUD + CopyOnWriteArrayList + AtomicLong
```

## Ba cái bẫy

| Bẫy | Cách tránh |
|---|---|
| Controller là singleton, nhiều thread cùng gọi | `CopyOnWriteArrayList` + `AtomicLong` |
| Tin id do client gửi | Server tự cấp id, bỏ qua id trong body |
| Trả 200 cho mọi thứ | Tạo mới 201 + `Location`, xoá 204 |

## Còn tệ — để dành cho bài sau

| Vấn đề | Bài |
|---|---|
| Dữ liệu nằm ngay trong controller | 3 |
| Tên rỗng, giá âm vẫn lọt | 4 |
| "Không thấy thì 404" lặp lại | 5 |
| Restart là mất dữ liệu | 8 |
