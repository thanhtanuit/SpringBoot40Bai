# shop-api — trạng thái sau Bài 19: Cache

> Cache dễ bật, khó đúng. Cache là **đánh đổi tính đúng đắn lấy tốc độ**.

## Chạy

```bash
docker compose up -d                                         # postgres + redis
mvn spring-boot:run                                          # cache = Redis
mvn spring-boot:run -Dspring-boot.run.profiles=dev,caffeine  # cache = Caffeine
```

```bash
docker compose exec redis redis-cli
KEYS *
GET "products::1"        # JSON đọc được
TTL "products::1"        # đếm ngược
```

## Thay đổi so với Bài 18

| | |
|---|---|
| `pom.xml` | + `starter-cache`, `caffeine`, `starter-data-redis` |
| `docker-compose.yml` | + `redis:7-alpine`, `allkeys-lru`, healthcheck |
| `application.yml` | `spring.cache.type: redis` |
| `application-caffeine.yml` | Profile Caffeine: `maximumSize=500,expireAfterWrite=10m,recordStats` |
| `config/CacheConfig.java` | Serializer JSON cố định kiểu, TTL từng cache, **`transactionAware()`** |
| `ProductService.findResponseById` | `@Cacheable` — cache **DTO**, không cache entity |
| `update`, `patch`, `delete`, `restore` | `@CacheEvict` |
| `OrderService` | Trừ kho → evict `products` |
| `web/CacheController.java` | `/api/cache/stats` |

## Hai cái bẫy

| Bẫy | |
|---|---|
| **Cache không được dọn** | GET → PATCH → GET trả giá cũ. Không lỗi, không log. *Mọi* đường ghi phải dọn — kể cả job, script, service khác (ở đây: `OrderService` trừ kho) |
| **Evict trước commit** | Request khác nạp lại dữ liệu cũ đúng khe giữa evict và commit. Sửa: cache manager transaction-aware |

## Caffeine hay Redis

| | Caffeine | Redis |
|---|---|---|
| Tốc độ đọc | ~100ns | ~1ms (một vòng mạng) |
| Nhiều instance | **Sai** — giá nhảy qua lại theo load balancer | Đúng — một nguồn duy nhất |

## Đừng cache kết quả tìm kiếm động

Khoá bùng nổ, tỷ lệ trúng gần 0, sửa một sản phẩm phải xoá sạch, `hashCode()` có thể
va chạm. Danh sách lọc + phân trang: tối ưu bằng index và truy vấn (Bài 39).

## Ba điều đọng lại

1. Trước khi cache hỏi: **dữ liệu cũ vài phút có chấp nhận được không?** Tồn kho, số dư: không.
2. Việc khó không phải ghi vào mà là **dọn đúng lúc**.
3. Đừng cache để che một truy vấn tệ — sửa truy vấn, thêm index trước.
