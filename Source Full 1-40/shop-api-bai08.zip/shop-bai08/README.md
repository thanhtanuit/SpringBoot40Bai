# shop-api — trạng thái sau Bài 8: Database thật với Spring Data JPA

> Thay toàn bộ tầng lưu trữ — `ConcurrentHashMap` → Hibernate, SQL, giao dịch —
> mà **controller không sửa một dòng nào**. Phần thưởng cho việc tách tầng ở Bài 3.

## Chạy

```bash
mvn spring-boot:run
```

Khởi động là có sẵn 5 sản phẩm từ `data.sql`. Log in đầy đủ câu SQL — **hãy đọc chúng**.

**H2 console:** http://localhost:8081/h2-console
JDBC URL **phải sửa** thành `jdbc:h2:mem:shopdb`, user `sa`, mật khẩu trống.

## Thay đổi so với Bài 7

| File | Thay đổi |
|---|---|
| `model/Product.java` | record → `@Entity` class, constructor `protected` rỗng, `@PrePersist` |
| `repository/` | **Xoá 3 file**, còn một interface kế thừa `JpaRepository` |
| `service/ProductService.java` | `@Transactional`, sửa bằng setter — không gọi `save()` |
| `dto/ProductMapper.java` | `name()` → `getName()` |
| `web/ProductController.java` | **Không đổi** |
| `application.yml` | datasource H2, `ddl-auto: create-drop`, `open-in-view: false` |
| `application-dev.yml` | H2 console — chỉ ở dev |
| `data.sql` | 5 sản phẩm mẫu |

## Ba cái bẫy

| Bẫy | Hậu quả |
|---|---|
| Entity là record / DTO đổi sang class | Entity cần thay đổi được, DTO nên bất biến — đừng lẫn |
| Dirty checking | Sửa entity managed là bị lưu, kể cả khi không định lưu |
| `ddl-auto: update` ở production | Nó đoán, và không bao giờ xoá cột thừa |

## Thí nghiệm ddl-auto

Đổi sang `update`, thêm field `sku` vào `Product`, khởi động → cột mới xuất hiện.
Xoá field đó, khởi động lại → cột `sku` **vẫn còn**. (`create-drop` + H2 bộ nhớ sẽ xoá
sạch mỗi lần, nên thí nghiệm cần đổi URL sang file: `jdbc:h2:file:./data/shopdb`.)

## Còn nợ

| Vấn đề | Bài |
|---|---|
| Chưa có quan hệ bảng | 9 |
| Chưa phân trang, tìm kiếm | 10 |
| H2 mất dữ liệu khi restart | 11 |
| Schema do Hibernate sinh | 12 |
