package com.example.shop.dto;

/**
 * Dữ liệu trả ra client. Chiều ra dùng kiểu nguyên thuỷ được —
 * dữ liệu do chính mình tạo, không nhận từ ngoài vào.
 *
 * Model sẽ lớn lên (giá vốn, cờ đã xoá, người tạo...). DTO quyết định
 * CHÍNH XÁC client được thấy gì — Bài 23 cần giấu giá vốn.
 */
public record ProductResponse(Long id, String name, double price, int stock) {
}
