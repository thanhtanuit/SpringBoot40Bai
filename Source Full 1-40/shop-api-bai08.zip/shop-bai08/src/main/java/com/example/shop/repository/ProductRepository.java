package com.example.shop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shop.model.Product;

/**
 * Bài 8: XOÁ ba file của Bài 3 (interface tự viết, InMemory, Fake), còn lại đúng file này.
 *
 * KHÔNG có class cài đặt. Spring Data đọc interface lúc khởi động và tự sinh bản
 * cài đặt bằng proxy động. findAll, findById, save, deleteById, count... có sẵn hết.
 *
 * Bài 3 cố tình đặt tên method trùng JpaRepository — hôm nay thu hoạch:
 * ProductService không phải sửa lời gọi nào.
 *
 * Derived query: tên method → câu SQL. Gõ sai tên trường (existsByNam...)
 * → app CHẾT LÚC KHỞI ĐỘNG, thông báo rõ ràng. Bài 10 khai thác kỹ.
 */
public interface ProductRepository extends JpaRepository<Product, Long> {

    /** SELECT COUNT(*) > 0 ... WHERE LOWER(name) = LOWER(?) */
    boolean existsByNameIgnoreCase(String name);

    /** Như trên, loại trừ chính sản phẩm đang sửa. */
    boolean existsByNameIgnoreCaseAndIdNot(String name, Long id);
}
