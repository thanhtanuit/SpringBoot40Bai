package com.example.shop.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Dữ liệu client gửi lên khi tạo / sửa sản phẩm.
 *
 * KHÔNG có trường id — client không có cách nào gửi id nữa.
 * Đây là cách chặn mass assignment: trường không tồn tại thì không gán được.
 *
 * BẪY 2: dùng kiểu WRAPPER (Double, Integer), không dùng double, int.
 * Kiểu nguyên thuỷ không chứa được null → client không gửi price thì Jackson
 * điền 0.0 → @NotNull KHÔNG BAO GIỜ bắt được → sản phẩm giá 0 lọt vào,
 * và bạn mất khả năng phân biệt "không gửi" với "gửi số 0".
 *
 * @NotNull  cấm null
 * @NotEmpty cấm null, ""
 * @NotBlank cấm null, "", "   "   ← dùng cho tên
 *
 * {min}, {max} trong message tự thay bằng giá trị trong annotation.
 */
public record CreateProductRequest(

        @NotBlank(message = "Tên sản phẩm không được để trống")
        @Size(min = 2, max = 100, message = "Tên sản phẩm phải từ {min} đến {max} ký tự")
        String name,

        @NotNull(message = "Giá không được để trống")
        @Positive(message = "Giá phải lớn hơn 0")
        Double price,

        // Tuỳ chọn: không gửi thì service coi là 0
        @Min(value = 0, message = "Tồn kho không được âm")
        Integer stock
) {
}
