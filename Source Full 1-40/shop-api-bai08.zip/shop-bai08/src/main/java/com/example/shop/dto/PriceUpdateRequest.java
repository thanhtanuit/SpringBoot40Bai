package com.example.shop.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/** Body cho PATCH /api/products/{id}/price. Thay cho PriceUpdate của Bài 2. */
public record PriceUpdateRequest(

        @NotNull(message = "Giá không được để trống")
        @Positive(message = "Giá phải lớn hơn 0")
        Double price
) {
}
