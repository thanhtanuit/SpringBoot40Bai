-- Bài 8: năm sản phẩm mẫu. Chạy sau khi Hibernate tạo bảng (defer-datasource-initialization).
-- Bài 12 thay file này bằng migration V2__seed_data.sql của Flyway.
INSERT INTO product (name, price, stock, created_at) VALUES ('Bàn phím cơ', 1250000, 10, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, created_at) VALUES ('Chuột không dây', 350000, 25, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, created_at) VALUES ('Tai nghe chụp tai', 890000, 8, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, created_at) VALUES ('Màn hình 27 inch', 4500000, 4, CURRENT_TIMESTAMP);
INSERT INTO product (name, price, stock, created_at) VALUES ('Webcam Full HD', 650000, 15, CURRENT_TIMESTAMP);
