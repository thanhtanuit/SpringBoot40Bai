import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Bài 24 (nâng cao) — PROXY: trình duyệt gọi http://localhost:5173/api/... → CÙNG ORIGIN,
// không CORS, không preflight. Vite chuyển tiếp sang backend (server-to-server không bị
// same-origin policy chi phối).
// Bật: bỏ comment khối server, rồi đặt VITE_API_URL=/api/v1 trong file .env.local
//
// Production cùng một Nginx (/ tĩnh, /api backend — Bài 37) → proxy ở dev phản ánh đúng thực tế.
// Production tách hẳn (app.shop.com / api.shop.com) → dùng CORS ở dev để gặp vấn đề sớm.
export default defineConfig({
  plugins: [vue()],
  // server: {
  //   proxy: {
  //     '/api': { target: 'http://localhost:8081', changeOrigin: true },
  //   },
  // },
})
