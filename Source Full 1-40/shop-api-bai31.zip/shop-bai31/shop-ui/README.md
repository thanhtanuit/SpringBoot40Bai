# shop-ui — frontend Vue cho shop-api (Bài 24)

```bash
npm install
npm run dev          # http://localhost:5173
```

Backend phải chạy ở `http://localhost:8081` với profile `dev` (CORS cho phép `localhost:5173`).

## Kịch bản kiểm thử

1. Chưa đăng nhập → thấy danh sách (GET công khai).
2. Đăng nhập `user1` → bấm Thêm → **403**.
3. Đăng nhập `seller` → Thêm thành công, thấy `Location` (nhờ `exposedHeaders`) → Xoá → **403**.
4. Đăng nhập `admin` → Xoá được, thấy thêm cột **Giá vốn**.
5. Refresh tự động: backend đặt `shop.jwt.access-token-ttl: 30s`, đăng nhập, đợi 35 giây,
   bấm một thao tác → Network: 401 → `/auth/refresh` → request gốc chạy lại, thành công.

Tab Network khi Thêm: `OPTIONS` (preflight, 204) rồi `POST` (201).

## Proxy thay CORS

Bỏ comment khối `server.proxy` trong `vite.config.js`, tạo `.env.local`:
```
VITE_API_URL=/api/v1
```
Giờ request đi tới `localhost:5173/api/...` — cùng origin, không preflight.

## Bài 28 — kiểu TypeScript sinh từ OpenAPI (nâng cao)

```bash
curl http://localhost:8081/v3/api-docs/all -o ../docs/openapi.json
npm run api:types      # → src/api/schema.d.ts
```

Backend đổi `price` thành `sellingPrice`, sinh lại → IDE báo lỗi ngay thay vì `undefined`
hiện trên màn hình production. Sinh cả client có hàm gọi: `@hey-api/openapi-ts`, `orval`.
