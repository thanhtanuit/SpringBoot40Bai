import axios from 'axios'

// Mặc định gọi thẳng backend khác origin → CORS. Dùng proxy Vite: VITE_API_URL=/api
// Bài 30: tiền tố phiên bản /api/v1
const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8081/api/v1'

export const api = axios.create({ baseURL: BASE_URL, timeout: 10000 })

// Gắn token vào mọi request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Tự refresh khi gặp 401
let dangRefresh = null

// Bài 30 — BÓC LỚP ApiResponse một lần ở đây: phần còn lại của app vẫn đọc res.data như cũ.
function bocLop(res) {
  if (res.data && typeof res.data === 'object' && 'success' in res.data) {
    res.data = res.data.data
  }
  return res
}

api.interceptors.response.use(
  bocLop,
  async (error) => {
    const original = error.config

    // _daThu: refresh xong vẫn 401 thì KHÔNG thử lại — chặn vòng lặp vô hạn
    if (error.response?.status !== 401 || original._daThu) {
      return Promise.reject(error)
    }
    // 401 từ chính /auth/login (sai mật khẩu) KHÔNG phải token hết hạn
    if (original.url.includes('/auth/')) {
      return Promise.reject(error)
    }
    original._daThu = true

    try {
      // GỘP mọi lần refresh đồng thời vào MỘT lời gọi.
      // Không có: 5 request cùng 401 → 5 lần refresh → với xoay vòng token (Bài 22), 4 lần
      // sau dùng token đã thu hồi → server THU HỒI TOÀN BỘ PHIÊN → người dùng bị đá ra.
      dangRefresh ??= axios
        .post(`${BASE_URL}/auth/refresh`, { refreshToken: localStorage.getItem('refreshToken') })
        .finally(() => { dangRefresh = null })

      const res = bocLop(await dangRefresh)   // axios thô — tự bóc lớp
      localStorage.setItem('accessToken', res.data.accessToken)
      localStorage.setItem('refreshToken', res.data.refreshToken)

      original.headers.Authorization = `Bearer ${res.data.accessToken}`
      return api(original)
    } catch (e) {
      localStorage.removeItem('accessToken')
      localStorage.removeItem('refreshToken')
      window.location.href = '/login'
      return Promise.reject(e)
    }
  },
)

// Bài 30 — lỗi: { success: false, error: { code, message, fieldErrors } }
// message ĐÃ dịch theo Accept-Language trình duyệt gửi. Rẽ nhánh thì theo CODE, không theo chuỗi.
export function maLoi(e) {
  return e.response?.data?.error?.code
}

export function thongBaoLoi(e, macDinh = 'Đã có lỗi xảy ra') {
  const err = e.response?.data?.error
  if (err?.fieldErrors) {
    return Object.entries(err.fieldErrors).map(([k, v]) => `${k}: ${v}`).join(' · ')
  }
  return err?.message ?? e.message ?? macDinh
}
