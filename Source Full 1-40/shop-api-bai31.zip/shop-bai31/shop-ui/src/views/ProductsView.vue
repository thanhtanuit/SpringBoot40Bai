<script setup>
import { ref, reactive, onMounted } from 'vue'
import { api, thongBaoLoi, maLoi } from '../api/client'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const products = ref([])
const loi = ref(null)
const thongBao = ref(null)
const form = reactive({ name: '', sku: '', price: 500000, stock: 5 })

async function tai() {
  loi.value = null
  try {
    const res = await api.get('/products', { params: { size: 20, sort: 'id,desc' } })
    products.value = res.data.content
  } catch (e) {
    // Trước khi cấu hình CORS: Console báo "blocked by CORS policy", nhưng tab Network
    // cho thấy server VẪN trả 200. CORS là luật của trình duyệt.
    loi.value = thongBaoLoi(e)
  }
}

async function them() {
  loi.value = null
  thongBao.value = null
  try {
    // Tab Network: OPTIONS (preflight, 204) rồi POST (201)
    const res = await api.post('/products', { ...form })
    // Đọc được header Location nhờ setExposedHeaders — thiếu thì undefined
    thongBao.value = `Đã tạo — Location: ${res.headers.location}`
    form.name = ''
    form.sku = ''
    await tai()
  } catch (e) {
    // Bài 30: rẽ nhánh theo MÃ ổn định
    if (maLoi(e) === 'DUPLICATE_SKU') {
      form.sku = ''
    }
    loi.value = thongBaoLoi(e)   // user1 → FORBIDDEN
  }
}

async function xoa(id) {
  loi.value = null
  thongBao.value = null
  try {
    await api.delete(`/products/${id}`)
    thongBao.value = `Đã xoá sản phẩm ${id}`
    await tai()
  } catch (e) {
    loi.value = thongBaoLoi(e)   // seller → 403, chỉ ADMIN xoá được
  }
}

onMounted(tai)
</script>

<template>
  <section>
    <h1>Sản phẩm</h1>
    <p v-if="loi" class="loi">{{ loi }}</p>
    <p v-if="thongBao" class="ok">{{ thongBao }}</p>

    <form v-if="auth.isLoggedIn" class="them" @submit.prevent="them">
      <input v-model="form.name" placeholder="Tên" />
      <input v-model="form.sku" placeholder="SKU (ABC-1234)" />
      <input v-model.number="form.price" type="number" placeholder="Giá" />
      <input v-model.number="form.stock" type="number" placeholder="Tồn kho" />
      <button>Thêm</button>
    </form>

    <table>
      <thead>
        <tr>
          <th>ID</th><th>Tên</th><th>SKU</th><th>Giá</th><th>Tồn</th>
          <th v-if="auth.isAdmin">Giá vốn</th>
          <th v-if="auth.isLoggedIn"></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="p in products" :key="p.id">
          <td>{{ p.id }}</td>
          <td>{{ p.name }}</td>
          <td>{{ p.sku }}</td>
          <td>{{ p.price.toLocaleString('vi-VN') }}đ</td>
          <td>{{ p.stock }}</td>
          <!-- costPrice CHỈ có trong JSON khi là ADMIN — server lọc, không phải frontend ẩn -->
          <td v-if="auth.isAdmin">{{ p.costPrice?.toLocaleString('vi-VN') ?? '—' }}</td>
          <td v-if="auth.isLoggedIn"><button class="phu" @click="xoa(p.id)">Xoá</button></td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
