package com.example.shop.product;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Bài 26 — CHỈ ĐỂ SO THỜI GIAN với ProductControllerTest:
 *   mvn test -Dtest=ProductControllerTest
 *   mvn test -Dtest=ProductControllerIntegrationTest
 *
 * @SpringBootTest nạp TOÀN BỘ: datasource, Hikari, Hibernate, cache, scheduler, async...
 * Một test thì không đáng kể; 200 test là vài phút chờ mỗi lần CI — và người ta bắt đầu bỏ qua test.
 *
 * Spring cache context theo cấu hình: mỗi biến thể @MockitoBean / @TestPropertySource tạo
 * context MỚI. Giữ cấu hình test đồng nhất là cách giữ suite nhanh.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@DisplayName("ProductController — tích hợp (so thời gian)")
class ProductControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;

    @Test
    void demo() throws Exception {
        mockMvc.perform(get("/api/v1/products")).andExpect(status().isOk());
    }
}
