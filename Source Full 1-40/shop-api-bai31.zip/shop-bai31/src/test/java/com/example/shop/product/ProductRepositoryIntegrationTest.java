package com.example.shop.product;

import com.example.shop.integration.AbstractIntegrationTest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.shop.common.audit.JpaAuditingConfig;
import com.example.shop.product.Product;
import com.example.shop.product.ProductRepository;

/**
 * Bài 27 — @DataJpaTest: chỉ nạp JPA (+ Flyway), không web, security, cache. Nhẹ hơn
 * @SpringBootTest nhiều.
 *
 * @AutoConfigureTestDatabase(replace = NONE) BẮT BUỘC: mặc định @DataJpaTest THAY datasource
 * bằng H2 nhúng — đúng thứ ta đang tránh.
 *
 * @Import(JpaAuditingConfig): slice không nạp @Configuration của bạn → @CreatedDate không được
 * điền → vi phạm NOT NULL ở created_at.
 *
 * @DataJpaTest mặc định @Transactional và rollback sau mỗi test — ở đây ổn vì không có HTTP
 * ở thread khác, và ta không kiểm commit.
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(JpaAuditingConfig.class)
@DisplayName("ProductRepository trên PostgreSQL thật")
class ProductRepositoryIntegrationTest extends AbstractIntegrationTest {

    @Autowired private ProductRepository repo;
    @Autowired private TestEntityManager em;
    @Autowired private JdbcTemplate jdbc;

    /** Mỗi lần chạy integration test là một lần DIỄN TẬP deploy schema. */
    @Test
    void should_ChayDuMigration_TrenPostgresThat() {
        Integer soMigration = jdbc.queryForObject(
                "SELECT COUNT(*) FROM flyway_schema_history WHERE success", Integer.class);
        assertThat(soMigration).isEqualTo(15);
    }

    @Test
    void should_TimTheoKeyword_KhongPhanBietHoaThuong() {
        em.persistAndFlush(new Product("Bàn phím cơ TC", "BPH-9001", 1_000_000, 10));
        em.persistAndFlush(new Product("Chuột không dây TC", "CHU-9001", 300_000, 5));

        var ketQua = repo.findByNameContainingIgnoreCase("BÀN PHÍM CƠ TC");

        assertThat(ketQua).hasSize(1)
                .extracting(Product::getName).containsExactly("Bàn phím cơ TC");
    }

    /** Logic nằm trong annotation Hibernate (Bài 16) — không có cách nào test bằng Mockito. */
    @Test
    void should_BoQuaBanGhiDaXoaMem() {
        Product p = em.persistAndFlush(new Product("Sẽ xoá", "XOA-0001", 1000, 1));
        repo.delete(p);      // @SQLDelete → UPDATE deleted = true
        em.flush();
        em.clear();

        assertThat(repo.findById(p.getId())).isEmpty();                              // @SQLRestriction lọc
        assertThat(repo.findDeleted()).extracting(Product::getSku).contains("XOA-0001");   // native thấy
    }

    /** Partial unique index (V8) — H2 không có. Xoá mềm rồi tạo lại cùng tên/sku phải được. */
    @Test
    void should_ChoTaoLaiCungTen_When_BanCuDaXoaMem() {
        Product cu = em.persistAndFlush(new Product("Trùng tên", "TRU-0001", 1000, 1));
        repo.delete(cu);
        em.flush();

        em.persistAndFlush(new Product("Trùng tên", "TRU-0001", 2000, 1));

        assertThat(repo.existsByNameIgnoreCase("Trùng tên")).isTrue();
    }
}
