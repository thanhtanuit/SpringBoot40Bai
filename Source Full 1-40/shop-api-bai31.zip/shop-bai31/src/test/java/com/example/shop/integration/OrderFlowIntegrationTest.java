package com.example.shop.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.cache.CacheManager;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.shop.common.error.ApiResponse;
import com.example.shop.user.dto.AuthResponse;
import com.example.shop.order.dto.CreateOrderRequest;
import com.example.shop.product.dto.CreateProductRequest;
import com.example.shop.user.dto.LoginRequest;
import com.example.shop.order.dto.OrderItemRequest;
import com.example.shop.order.dto.OrderResponse;
import com.example.shop.product.dto.ProductResponse;
import com.example.shop.user.dto.RegisterRequest;
import com.example.shop.user.dto.UserResponse;

/**
 * Bài 27 — kịch bản đầu-cuối qua ĐÚNG đường production:
 * HTTP → filter JWT → controller → service → transaction → Hibernate → PostgreSQL (+ Redis).
 *
 * TestRestTemplate gửi HTTP THẬT tới cổng ngẫu nhiên — đi qua servlet container, header thật,
 * serialize/deserialize hai chiều (thứ MockMvc bỏ qua).
 *
 * Bài 31: repository giờ package-private — test ở package integration KHÔNG chạm được.
 * Kiểm trạng thái DB bằng JdbcTemplate: trung thực hơn, kiểm KẾT QUẢ THẬT, không phụ thuộc cấu trúc code.
 *
 * Bài 30: response bọc trong ApiResponse → đọc qua ParameterizedTypeReference và .data().
 *
 * @TestMethodOrder(Random): test phụ thuộc thứ tự là test dối trá — xanh máy bạn, đỏ trên CI.
 * Chạy hai lần liên tiếp phải cùng kết quả; đỏ lần hai = DatabaseCleaner còn sót bảng.
 */
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(DatabaseCleaner.class)
@TestMethodOrder(MethodOrderer.Random.class)
@DisplayName("Luồng đặt hàng đầu-cuối")
class OrderFlowIntegrationTest extends AbstractIntegrationTest {

    @Autowired private TestRestTemplate rest;
    @Autowired private DatabaseCleaner cleaner;
    @Autowired private CacheManager cacheManager;
    @Autowired private JdbcTemplate jdbc;

    private static final ParameterizedTypeReference<ApiResponse<OrderResponse>> ORDER =
            new ParameterizedTypeReference<>() { };
    private static final ParameterizedTypeReference<ApiResponse<ProductResponse>> PRODUCT =
            new ParameterizedTypeReference<>() { };
    private static final ParameterizedTypeReference<ApiResponse<AuthResponse>> AUTH =
            new ParameterizedTypeReference<>() { };
    private static final ParameterizedTypeReference<ApiResponse<UserResponse>> USER =
            new ParameterizedTypeReference<>() { };

    private String tokenAdmin;
    private String tokenUser;

    @BeforeEach
    void setUp() {
        cleaner.clean();
        // Không dọn cache thì test trước để lại dữ liệu cho test sau
        cacheManager.getCacheNames().forEach(n -> Objects.requireNonNull(cacheManager.getCache(n)).clear());

        tokenAdmin = dangKyVaDangNhap("admin_test", "ADMIN");
        tokenUser = dangKyVaDangNhap("user_test", "USER");
    }

    @Test
    void should_TruTonKhoDung_When_DatHangThanhCong() {
        Long productId = taoSanPham("Bàn phím cơ", "BPH-0001", 1_000_000, 10);
        assertThat(tonKho(productId)).isEqualTo(10);

        var req = new CreateOrderRequest("Nguyễn Văn A", List.of(new OrderItemRequest(productId, 3)));
        ResponseEntity<ApiResponse<OrderResponse>> res = rest.exchange("/api/v1/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenUser)), ORDER);

        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(res.getHeaders().getLocation()).isNotNull();
        assertThat(res.getBody().success()).isTrue();
        assertThat(res.getBody().data().totalAmount()).isEqualTo(3_000_000);
        assertThat(res.getBody().data().items()).hasSize(1);

        // Kiểm TRONG DATABASE — điều @WebMvcTest không làm được
        assertThat(tonKho(productId)).isEqualTo(7);
        assertThat(soDon()).isEqualTo(1);
    }

    /**
     * CHỈ integration test làm được. Bài 25: tồn kho là 8 sau lỗi (Mockito không mô phỏng
     * transaction). Ở đây là 10 — PostgreSQL THẬT SỰ rollback.
     * Thử: tạm bỏ @Transactional khỏi OrderService → test này ĐỎ, đúng cái nó phải bắt.
     */
    @Test
    @DisplayName("Đơn có 1 dòng hết hàng → toàn bộ đơn không được lưu")
    void should_RollbackToanBo_When_MotDongHetHang() {
        Long sp1 = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);
        Long sp2 = taoSanPham("Chuột", "CHU-0001", 300_000, 2);

        var req = new CreateOrderRequest("Nguyễn Văn A", List.of(
                new OrderItemRequest(sp1, 5),      // hợp lệ
                new OrderItemRequest(sp2, 99)));   // hết hàng

        ResponseEntity<ApiResponse<OrderResponse>> res = rest.exchange("/api/v1/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenUser)), ORDER);

        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(res.getBody().error().code()).isEqualTo("INSUFFICIENT_STOCK");
        assertThat(soDon()).isZero();
        assertThat(tonKho(sp1)).isEqualTo(10);
        assertThat(tonKho(sp2)).isEqualTo(2);

        // Bài 13: dòng ATTEMPT ghi bằng REQUIRES_NEW — SỐNG SÓT qua rollback của đơn
        Integer attempt = jdbc.queryForObject(
                "SELECT COUNT(*) FROM audit_log WHERE action = 'ATTEMPT'", Integer.class);
        assertThat(attempt).isEqualTo(1);
    }

    /** Bài 31 — dòng hàng lưu BẢN SAO tên: đổi tên sản phẩm về sau không làm sai đơn cũ. */
    @Test
    void should_GiuTenCu_When_DoiTenSanPhamSauKhiDat() {
        Long id = taoSanPham("Tên cũ", "TEN-0001", 100_000, 10);
        Long orderId = datHang(tokenUser, id, 1);

        rest.exchange("/api/v1/products/" + id, HttpMethod.PATCH,
                new HttpEntity<>(Map.of("name", "Tên mới"), headers(tokenAdmin)), PRODUCT);

        var don = rest.exchange("/api/v1/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenUser)), ORDER);
        assertThat(don.getBody().data().items().get(0).productName()).isEqualTo("Tên cũ");
    }

    @Test
    void should_ChanTruyCap_When_KhongPhaiChuDon() {
        Long productId = taoSanPham("Chuột", "CHU-0001", 300_000, 20);
        Long orderId = datHang(tokenUser, productId, 1);
        String tokenNguoiKhac = dangKyVaDangNhap("user_khac", "USER");

        ResponseEntity<String> res = rest.exchange("/api/v1/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenNguoiKhac)), String.class);

        // Đi qua OrderSecurity THẬT — Bài 26 chỉ mock nó
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }

    @Test
    void should_ChoPhepChuDonVaAdminXem() {
        Long productId = taoSanPham("Chuột", "CHU-0001", 300_000, 20);
        Long orderId = datHang(tokenUser, productId, 1);

        assertThat(rest.exchange("/api/v1/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenUser)), ORDER).getStatusCode())
                .isEqualTo(HttpStatus.OK);
        assertThat(rest.exchange("/api/v1/orders/" + orderId, HttpMethod.GET,
                new HttpEntity<>(headers(tokenAdmin)), ORDER).getStatusCode())
                .isEqualTo(HttpStatus.OK);
    }

    @Test
    void should_GhiCreatedByLaNguoiDangNhap_When_TaoSanPham() {
        Long productId = taoSanPham("Đế tản nhiệt", "DTN-0001", 450_000, 5);

        String createdBy = jdbc.queryForObject(
                "SELECT created_by FROM product WHERE id = ?", String.class, productId);
        assertThat(createdBy).isEqualTo("admin_test");   // Bài 16 + Bài 22
    }

    /**
     * Nâng cao — CÁI BẪY CACHE Bài 19 trên Redis thật.
     * Bỏ @CacheEvict khỏi ProductService.patch → test ĐỎ. Loại lỗi không exception, không log.
     */
    @Test
    void should_TraVeGiaMoi_When_CapNhatSauKhiDaCache() {
        Long id = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);

        var lan1 = rest.exchange("/api/v1/products/" + id, HttpMethod.GET, null, PRODUCT);
        assertThat(lan1.getBody().data().price()).isEqualTo(1_000_000);   // → vào cache

        rest.exchange("/api/v1/products/" + id, HttpMethod.PATCH,
                new HttpEntity<>(Map.of("price", 999_000), headers(tokenAdmin)), PRODUCT);

        var lan2 = rest.exchange("/api/v1/products/" + id, HttpMethod.GET, null, PRODUCT);
        assertThat(lan2.getBody().data().price()).isEqualTo(999_000);
    }

    @Test
    void should_TraVeTonKhoMoi_When_DatHangSauKhiDaCache() {
        Long id = taoSanPham("Bàn phím", "BPH-0001", 1_000_000, 10);
        rest.exchange("/api/v1/products/" + id, HttpMethod.GET, null, PRODUCT);   // → vào cache

        datHang(tokenUser, id, 4);

        var sau = rest.exchange("/api/v1/products/" + id, HttpMethod.GET, null, PRODUCT);
        assertThat(sau.getBody().data().stock()).isEqualTo(6);   // OrderService cũng phải dọn cache
    }

    // ---------- helper ----------

    private int tonKho(Long productId) {
        return jdbc.queryForObject("SELECT stock FROM product WHERE id = ?", Integer.class, productId);
    }

    private long soDon() {
        return jdbc.queryForObject("SELECT COUNT(*) FROM orders", Long.class);
    }

    private HttpHeaders headers(String token) {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        if (token != null) {
            h.setBearerAuth(token);
        }
        return h;
    }

    private String dangKyVaDangNhap(String username, String role) {
        rest.exchange("/api/v1/auth/register", HttpMethod.POST,
                new HttpEntity<>(new RegisterRequest(username, "matkhau12345", username + "@test.local"),
                        headers(null)), USER);

        if (!"USER".equals(role)) {
            capQuyen(username, role);
        }

        ResponseEntity<ApiResponse<AuthResponse>> res = rest.exchange("/api/v1/auth/login", HttpMethod.POST,
                new HttpEntity<>(new LoginRequest(username, "matkhau12345"), headers(null)), AUTH);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.OK);
        return res.getBody().data().accessToken();
    }

    /**
     * Không có endpoint cấp quyền ADMIN → JDBC thô. Hợp lý cho chuẩn bị dữ liệu: KHÔNG đi qua
     * logic nghiệp vụ, không tạo phụ thuộc vòng giữa test và thứ đang được test.
     */
    private void capQuyen(String username, String role) {
        Long id = jdbc.queryForObject("SELECT id FROM app_user WHERE username = ?", Long.class, username);
        jdbc.update("INSERT INTO user_role (user_id, role) VALUES (?, ?)", id, role);
    }

    private Long taoSanPham(String ten, String sku, double gia, int ton) {
        var req = new CreateProductRequest(ten, sku, gia, ton);
        ResponseEntity<ApiResponse<ProductResponse>> res = rest.exchange("/api/v1/products", HttpMethod.POST,
                new HttpEntity<>(req, headers(tokenAdmin)), PRODUCT);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return res.getBody().data().id();
    }

    private Long datHang(String token, Long productId, int soLuong) {
        var req = new CreateOrderRequest("Khách test", List.of(new OrderItemRequest(productId, soLuong)));
        ResponseEntity<ApiResponse<OrderResponse>> res = rest.exchange("/api/v1/orders", HttpMethod.POST,
                new HttpEntity<>(req, headers(token)), ORDER);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return res.getBody().data().id();
    }
}
