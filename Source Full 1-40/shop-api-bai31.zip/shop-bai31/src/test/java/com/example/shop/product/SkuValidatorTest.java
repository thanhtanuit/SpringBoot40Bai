package com.example.shop.product;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

/** Bài 25 — @ValueSource cho một tham số, @NullSource cho đầu vào null. */
@DisplayName("SkuValidator")
class SkuValidatorTest {

    private final SkuValidator validator = new SkuValidator();

    @ParameterizedTest(name = "\"{0}\" hợp lệ")
    @ValueSource(strings = {"ABC-1234", "SKU-0001", "XYZ-9999"})
    void should_HopLe_When_DungDinhDang(String sku) {
        assertThat(validator.isValid(sku, null)).isTrue();
    }

    @ParameterizedTest(name = "\"{0}\" không hợp lệ")
    @ValueSource(strings = {"", "abc-1234", "AB-1234", "ABCD-1234", "ABC-123", "ABC-12345", "ABC_1234", " ABC-1234"})
    void should_KhongHopLe_When_SaiDinhDang(String sku) {
        assertThat(validator.isValid(sku, null)).isFalse();
    }

    /** null → true: bắt buộc có là việc của @NotBlank (Bài 4). */
    @ParameterizedTest
    @NullSource
    void should_HopLe_When_Null(String sku) {
        assertThat(validator.isValid(sku, null)).isTrue();
    }
}
