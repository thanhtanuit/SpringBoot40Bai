package com.example.shop.architecture;

import static com.tngtech.archunit.core.domain.JavaClass.Predicates.resideInAPackage;
import static com.tngtech.archunit.core.domain.JavaClass.Predicates.simpleName;
import static com.tngtech.archunit.core.domain.properties.CanBeAnnotated.Predicates.annotatedWith;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noFields;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noMethods;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

import org.springframework.beans.factory.annotation.Autowired;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import jakarta.persistence.Entity;

/**
 * Bài 31 — sơ đồ phụ thuộc trên giấy thành LUẬT KIỂM TRA MỖI LẦN BUILD.
 *
 *            common  ←──── product ←──── order
 *              ↑
 *             user
 *
 * Kiến trúc xuống cấp TỪNG CHÚT MỘT: một người vội, thêm một import, review không để ý, sáu tháng
 * sau mọi thứ dính vào nhau. Vi phạm → ArchUnit in CHÍNH XÁC class nào, dòng nào.
 *
 *   mvn test -Dtest=ArchitectureTest
 */
@AnalyzeClasses(packages = "com.example.shop", importOptions = ImportOption.DoNotIncludeTests.class)
class ArchitectureTest {

    @ArchTest
    static final ArchRule khongCoPhuThuocVongTron =
            slices().matching("com.example.shop.(*)..").should().beFreeOfCycles();

    @ArchTest
    static final ArchRule commonKhongBietFeature =
            noClasses().that().resideInAPackage("com.example.shop.common..")
                    .should().dependOnClassesThat().resideInAnyPackage(
                            "com.example.shop.product..", "com.example.shop.order..", "com.example.shop.user..");

    @ArchTest
    static final ArchRule productKhongBietOrderVaUser =
            noClasses().that().resideInAPackage("com.example.shop.product..")
                    .should().dependOnClassesThat().resideInAnyPackage(
                            "com.example.shop.order..", "com.example.shop.user..");

    @ArchTest
    static final ArchRule userDocLap =
            noClasses().that().resideInAPackage("com.example.shop.user..")
                    .should().dependOnClassesThat().resideInAnyPackage(
                            "com.example.shop.product..", "com.example.shop.order..");

    /** order → product CHỈ qua ProductService và product.dto — không entity, không repository. */
    @ArchTest
    static final ArchRule orderChiQuaProductService =
            noClasses().that().resideInAPackage("com.example.shop.order..")
                    .should().dependOnClassesThat(
                            resideInAPackage("com.example.shop.product")
                                    .and(DescribedPredicate.not(simpleName("ProductService"))))
                    .because("order chỉ được dùng hợp đồng public của product (Bài 31)");

    @ArchTest
    static final ArchRule controllerKhongGoiRepository =
            noClasses().that().haveSimpleNameEndingWith("Controller")
                    .should().dependOnClassesThat().haveSimpleNameEndingWith("Repository");

    @ArchTest
    static final ArchRule controllerKhongTraEntity =
            noMethods().that().areDeclaredInClassesThat().haveSimpleNameEndingWith("Controller")
                    .should().haveRawReturnType(annotatedWith(Entity.class))
                    .because("trả entity ra API → vòng lặp JSON, lộ dữ liệu (Bài 4, Bài 9)");

    @ArchTest
    static final ArchRule entityTrongFeaturePhaiAn =
            classes().that().areAnnotatedWith(Entity.class)
                    .and().resideInAnyPackage("com.example.shop.product..", "com.example.shop.order..",
                            "com.example.shop.user..")
                    .should().notBePublic();

    @ArchTest
    static final ArchRule serviceImplPhaiPackagePrivate =
            classes().that().haveSimpleNameEndingWith("ServiceImpl").should().notBePublic();

    /** Quy tắc Bài 3 — giờ không còn phụ thuộc trí nhớ của ai. */
    @ArchTest
    static final ArchRule khongDungFieldInjection =
            noFields().should().beAnnotatedWith(Autowired.class)
                    .because("dùng constructor injection (Bài 3)");
}
