package com.example.shop.order;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.shop.common.audit.AuditService;
import com.example.shop.common.error.BusinessException;
import com.example.shop.common.error.ErrorCode;
import com.example.shop.common.error.ResourceNotFoundException;
import com.example.shop.order.dto.CreateOrderRequest;
import com.example.shop.order.dto.OrderItemRequest;
import com.example.shop.product.ProductService;
import com.example.shop.product.dto.ProductSnapshot;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * Bài 25 — unit test. Bài 31: order không còn thấy entity Product → mock ProductService
 * (hợp đồng public của product) và trả ProductSnapshot. Việc trừ kho kiểm bằng verify(truTonKho),
 * không còn soi p.getStock() — test kiểm HÀNH VI ở ranh giới feature.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService")
class OrderServiceTest {

    @Mock private OrderRepository orderRepo;
    @Mock private OrderItemRepository orderItemRepo;
    @Mock private ProductService productService;
    @Mock private AuditService auditService;
    @Mock private NotificationService notificationService;

    /** Bài 29 — bản thật trên SimpleMeterRegistry: mock thì doThoiGian trả null, logic không chạy. */
    private final SimpleMeterRegistry registry = new SimpleMeterRegistry();
    @Spy private OrderMetrics metrics = new OrderMetrics(registry);

    @InjectMocks
    private OrderService service;

    private final ProductSnapshot banPhim = new ProductSnapshot(1L, "Bàn phím", 1_000_000, 10);
    private final ProductSnapshot chuot = new ProductSnapshot(2L, "Chuột", 300_000, 5);

    private static CreateOrderRequest don(String khach, OrderItemRequest... dong) {
        return new CreateOrderRequest(khach, List.of(dong));
    }

    @Nested
    @DisplayName("Đặt hàng")
    class DatHang {

        @Test
        void should_TinhDungTongTien_When_DonCoNhieuDong() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(productService.layThongTinDeDatHang(2L)).thenReturn(chuot);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            Order ketQua = service.datHang(don("Nguyễn Văn A",
                    new OrderItemRequest(1L, 2),     // 2 × 1.000.000
                    new OrderItemRequest(2L, 3)));   // 3 ×   300.000

            assertThat(ketQua.getTotalAmount()).isEqualTo(2_900_000);
            assertThat(ketQua.getItems()).hasSize(2);
        }

        @Test
        void should_TruTonKhoQuaProductService_When_DatHangThanhCong() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("A", new OrderItemRequest(1L, 3)));

            verify(productService).truTonKho(1L, 3);
        }

        /** Bài 31: dòng hàng mang BẢN SAO tên và giá lúc mua. */
        @Test
        void should_ChotTenVaGiaLucMua() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            Order ketQua = service.datHang(don("A", new OrderItemRequest(1L, 1)));

            OrderItem dong = ketQua.getItems().get(0);
            assertThat(dong.getProductId()).isEqualTo(1L);
            assertThat(dong.getProductName()).isEqualTo("Bàn phím");
            assertThat(dong.getUnitPrice()).isEqualTo(1_000_000);
        }

        @Test
        void should_GuiThongBaoVaGhiAudit_When_DatHangThanhCong() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("Nguyễn Văn A", new OrderItemRequest(1L, 1)));

            verify(notificationService).guiThongBaoDatHang(any(), eq("Nguyễn Văn A"));
            verify(auditService).ghi(eq("ATTEMPT"), eq("Order"), any(), anyString());
            verify(auditService).ghiCungGiaoDich(eq("CREATE"), eq("Order"), any(), anyString());
        }

        @Test
        void should_TangMetric_When_DatHangThanhCong() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            service.datHang(don("A", new OrderItemRequest(1L, 2)));

            assertThat(registry.get("shop.orders.created").counter().count()).isEqualTo(1);
            assertThat(registry.get("shop.orders.amount").summary().totalAmount()).isEqualTo(2_000_000);
        }

        @Test
        void should_ThrowInsufficientStock_When_KhongDuHang() {
            when(productService.layThongTinDeDatHang(2L)).thenReturn(chuot);

            assertThatThrownBy(() -> service.datHang(don("A", new OrderItemRequest(2L, 99))))
                    .isInstanceOfSatisfying(BusinessException.class, e -> {
                        assertThat(e.getCode()).isEqualTo(ErrorCode.INSUFFICIENT_STOCK);
                        assertThat(e.getArgs()).containsExactly("Chuột", 5, 99);
                    });

            verify(productService, never()).truTonKho(anyLong(), anyInt());
            verify(orderRepo, never()).save(any());
            assertThat(registry.get("shop.orders.failed").tag("reason", "insufficient_stock")
                    .counter().count()).isEqualTo(1);
        }

        @Test
        void should_ThrowNotFound_When_SanPhamKhongTonTai() {
            when(productService.layThongTinDeDatHang(9999L))
                    .thenThrow(new ResourceNotFoundException(ErrorCode.PRODUCT_NOT_FOUND, 9999L));

            assertThatThrownBy(() -> service.datHang(don("A", new OrderItemRequest(9999L, 1))))
                    .isInstanceOf(ResourceNotFoundException.class);

            assertThat(registry.get("shop.orders.failed").tag("reason", "product_not_found")
                    .counter().count()).isEqualTo(1);
        }

        /**
         * Dòng 1 đã gọi truTonKho, dòng 2 hết hàng → exception. Unit test chỉ kiểm được
         * "save không bị gọi". Việc kho của dòng 1 được HOÀN LẠI là việc của transaction thật
         * — OrderFlowIntegrationTest (Bài 27) kiểm.
         */
        @Test
        void should_KhongLuuDon_When_DongSauHetHang() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(productService.layThongTinDeDatHang(2L)).thenReturn(chuot);

            assertThatThrownBy(() -> service.datHang(don("A",
                    new OrderItemRequest(1L, 2),
                    new OrderItemRequest(2L, 99))))
                    .isInstanceOf(BusinessException.class);

            verify(productService).truTonKho(1L, 2);
            verify(orderRepo, never()).save(any());
        }

        @Test
        void should_KhongGhiAuditCreateVaKhongGuiThongBao_When_CongTacLoiBat() {
            when(productService.layThongTinDeDatHang(1L)).thenReturn(banPhim);
            when(orderRepo.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

            assertThatThrownBy(() -> service.datHang(don("LOI khách", new OrderItemRequest(1L, 1))))
                    .isInstanceOf(RuntimeException.class);

            verify(auditService, never()).ghiCungGiaoDich(any(), any(), any(), any());
            verify(notificationService, never()).guiThongBaoDatHang(any(), any());
        }
    }

    @ParameterizedTest(name = "Tổng {0}đ → giảm {1}đ")
    @CsvSource({
            "  1000000,       0",
            "  1999999,       0",
            "  2000000,  100000",
            "  4999999,  249999.95",
            "  5000000,  500000",
            "  9999999,  999999.9",
            " 10000000, 1500000",
            " 20000000, 3000000"
    })
    void should_TinhDungGiamGia_TheoCacMuc(double tongTien, double giamGiaMongDoi) {
        assertThat(service.tinhGiamGia(tongTien)).isCloseTo(giamGiaMongDoi, within(0.01));
    }
}
