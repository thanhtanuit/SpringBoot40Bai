-- V16 — Bài 31: order không còn trỏ khoá ngoại sang product.
-- Mẫu 3 bước (Bài 12): thêm nullable → điền dòng cũ → siết NOT NULL.

ALTER TABLE order_item ADD COLUMN product_name VARCHAR(100);

UPDATE order_item oi SET product_name = p.name
FROM product p WHERE p.id = oi.product_id;

ALTER TABLE order_item ALTER COLUMN product_name SET NOT NULL;

-- ĐÁNH ĐỔI: database không còn đảm bảo product_id trỏ tới sản phẩm có thật.
ALTER TABLE order_item DROP CONSTRAINT fk_order_item_product;
