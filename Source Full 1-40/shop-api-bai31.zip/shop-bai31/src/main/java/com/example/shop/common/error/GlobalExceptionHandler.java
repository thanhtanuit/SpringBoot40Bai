package com.example.shop.common.error;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.mapping.PropertyReferenceException;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import com.example.shop.common.error.ApiError;
import com.example.shop.common.error.ApiResponse;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Bài 30 — viết lại. Mọi lỗi nghiệp vụ đi CHUNG MỘT ĐƯỜNG qua ErrorCode (handleBusiness).
 * Các handler còn lại chỉ DỊCH exception của framework sang ErrorCode.
 *
 * LocaleContextHolder.getLocale(): locale LocaleResolver đã xác định từ Accept-Language —
 * lại là ThreadLocal, cùng cơ chế MDC (Bài 7), SecurityContext (Bài 22), cùng bẫy với @Async.
 *
 * Phân mức log giữ nguyên Bài 5: 4xx warn một dòng · 5xx error kèm stack trace.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private final MessageSource messages;

    public GlobalExceptionHandler(MessageSource messages) {
        this.messages = messages;
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<Void>> handleBusiness(BusinessException ex, HttpServletRequest req) {
        return tra(ex.getCode(), req, null, ex, ex.getArgs());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleValidation(MethodArgumentNotValidException ex,
                                                              HttpServletRequest req) {
        // getDefaultMessage() ĐÃ được dịch: validator dùng chung MessageSource (I18nConfig)
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors()
                .forEach(fe -> fieldErrors.putIfAbsent(fe.getField(), fe.getDefaultMessage()));
        return tra(ErrorCode.VALIDATION_FAILED, req, fieldErrors, null);
    }

    /** Không lộ message gốc của Jackson (tên class, package — Bài 5). */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<Void>> handleUnreadable(HttpMessageNotReadableException ex,
                                                              HttpServletRequest req) {
        return tra(ErrorCode.MALFORMED_REQUEST, req, null, null);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<Void>> handleTypeMismatch(MethodArgumentTypeMismatchException ex,
                                                                HttpServletRequest req) {
        return tra(ErrorCode.INVALID_PARAMETER, req, null, null, ex.getName());
    }

    @ExceptionHandler(PropertyReferenceException.class)
    public ResponseEntity<ApiResponse<Void>> handleBadSort(PropertyReferenceException ex, HttpServletRequest req) {
        return tra(ErrorCode.INVALID_SORT, req, null, null, ex.getPropertyName());
    }

    /** @PreAuthorize thất bại trong controller (Bài 23). */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleAccessDenied(AccessDeniedException ex, HttpServletRequest req) {
        return tra(ErrorCode.FORBIDDEN, req, null, null);
    }

    @ExceptionHandler(OptimisticLockingFailureException.class)
    public ResponseEntity<ApiResponse<Void>> handleOptimisticLock(OptimisticLockingFailureException ex,
                                                                  HttpServletRequest req) {
        return tra(ErrorCode.CONCURRENT_MODIFICATION, req, null, null);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiResponse<Void>> handleIntegrity(DataIntegrityViolationException ex,
                                                             HttpServletRequest req) {
        log.warn("Vi phạm ràng buộc: {}", ex.getMostSpecificCause().getMessage());
        return tra(ErrorCode.DATA_CONFLICT, req, null, null);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse<Void>> handleMaxSize(MaxUploadSizeExceededException ex, HttpServletRequest req) {
        return tra(ErrorCode.FILE_TOO_LARGE, req, null, null);
    }

    /** Bài 30: đường dẫn không tồn tại — trước đây rơi xuống handleAll thành 500. */
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNoResource(NoResourceFoundException ex, HttpServletRequest req) {
        return tra(ErrorCode.ENDPOINT_NOT_FOUND, req, null, null);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethod(HttpRequestMethodNotSupportedException ex,
                                                          HttpServletRequest req) {
        return tra(ErrorCode.METHOD_NOT_ALLOWED, req, null, null, ex.getMethod());
    }

    /** Lưới an toàn — client KHÔNG BAO GIỜ thấy stack trace. */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleAll(Exception ex, HttpServletRequest req) {
        return tra(ErrorCode.INTERNAL_ERROR, req, null, ex);
    }

    private ResponseEntity<ApiResponse<Void>> tra(ErrorCode code, HttpServletRequest req,
                                                  Map<String, String> fieldErrors, Exception ex,
                                                  Object... args) {
        String message = messages.getMessage(code.messageKey(), args, LocaleContextHolder.getLocale());

        if (code.status().is5xxServerError()) {
            log.error("{} {} {} — {}", code.status().value(), req.getMethod(), req.getRequestURI(), code, ex);
        } else {
            log.warn("{} {} {} — {}", code.status().value(), req.getMethod(), req.getRequestURI(), code);
        }

        return ResponseEntity.status(code.status())
                .body(ApiResponse.fail(new ApiError(code.name(), message, req.getRequestURI(), fieldErrors)));
    }
}
