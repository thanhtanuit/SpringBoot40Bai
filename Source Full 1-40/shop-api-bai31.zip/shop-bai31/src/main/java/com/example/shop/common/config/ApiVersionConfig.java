package com.example.shop.common.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.shop.common.web.HelloController;

/**
 * Bài 30 — đánh phiên bản API: mọi @RestController của shop nhận tiền tố /api/v1.
 * Controller chỉ khai phần sau: @RequestMapping("/products") → /api/v1/products.
 *
 * Làm SỚM: thêm tiền tố khi mới có vài người dùng API là việc 5 phút. Làm khi app di động đã
 * ngoài thị trường là chiến dịch di dời hàng tháng — app cũ KHÔNG tự cập nhật, phải giữ cả hai
 * đường chạy song song.
 *
 * HelloController (Bài 1, endpoint học) giữ nguyên /api/hello.
 */
@Configuration
public class ApiVersionConfig implements WebMvcConfigurer {

    public static final String PREFIX = "/api/v1";

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.addPathPrefix(PREFIX, c -> c.isAnnotationPresent(RestController.class)
                && c.getPackageName().startsWith("com.example.shop")   // Bài 31: controller nằm theo feature
                && c != HelloController.class);
    }
}
