package com.example.shop.order;

import org.mapstruct.Mapper;

import com.example.shop.order.dto.OrderItemResponse;
import com.example.shop.order.dto.OrderResponse;

/**
 * Bài 31 — OrderItem giữ sẵn productId, productName → mọi trường TỰ KHỚP theo tên,
 * không còn @Mapping source = "product.name", không còn chạm quan hệ lazy sang product.
 * Package-private: MapStruct sinh "public class OrderMapperImpl implements OrderMapper" cùng package.
 */
@Mapper(componentModel = "spring")
interface OrderMapper {

    OrderResponse toResponse(Order order);

    OrderItemResponse toItemResponse(OrderItem item);
}
