package com.example.shop.product;

import java.time.Duration;

import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;

import com.example.shop.product.dto.ProductResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Bài 31 — cache "products" do CHÍNH feature product khai báo (trước ở common.CacheConfig,
 * khiến common phụ thuộc ngược lên ProductResponse).
 */
@Configuration
class ProductCacheConfig {

    @Bean
    RedisCacheManagerBuilderCustomizer productCacheCustomizer(ObjectMapper objectMapper) {
        return builder -> builder.withCacheConfiguration("products",
                RedisCacheConfiguration.defaultCacheConfig()
                        .entryTtl(Duration.ofMinutes(10))
                        .disableCachingNullValues()
                        .serializeValuesWith(SerializationPair.fromSerializer(
                                new Jackson2JsonRedisSerializer<>(objectMapper, ProductResponse.class))));
    }
}
