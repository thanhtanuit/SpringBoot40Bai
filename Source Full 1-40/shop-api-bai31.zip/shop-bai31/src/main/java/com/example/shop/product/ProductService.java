package com.example.shop.product;

import com.example.shop.product.dto.ProductSnapshot;

/**
 * Bài 31 — HỢP ĐỒNG PUBLIC của feature product cho feature KHÁC.
 *
 * Chỉ gồm thao tác NGHIỆP VỤ mà order cần — không phải cửa hậu vào dữ liệu:
 * order KHÔNG thấy entity Product, KHÔNG thấy ProductRepository (cả hai package-private).
 *
 * Controller trong CÙNG feature dùng thẳng ProductServiceImpl — interface này chỉ vẽ ranh giới
 * với bên ngoài.
 */
public interface ProductService {

    /** @throws com.example.shop.common.error.ResourceNotFoundException PRODUCT_NOT_FOUND */
    ProductSnapshot layThongTinDeDatHang(Long productId);

    /** @throws com.example.shop.common.error.BusinessException INSUFFICIENT_STOCK */
    void truTonKho(Long productId, int soLuong);
}
