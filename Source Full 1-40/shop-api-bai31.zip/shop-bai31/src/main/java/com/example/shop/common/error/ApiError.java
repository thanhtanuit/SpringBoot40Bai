package com.example.shop.common.error;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/** code: ổn định, cho máy · message: đã dịch theo Accept-Language, cho người. */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiError(
        String code,
        String message,
        String path,
        Map<String, String> fieldErrors
) {
}
