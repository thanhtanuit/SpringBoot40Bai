package com.example.shop.product;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.product.dto.DashboardResponse;
import com.example.shop.product.AsyncQueryService;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Bài 20 — hai việc chạy SONG SONG: mỗi cái 1 giây thì tổng vẫn ~1 giây.
 *
 * Điều kiện: KHỞI ĐỘNG CẢ HAI trước khi chờ. Viết f1.get() rồi mới gọi demTonKhoAsync()
 * là quay về tuần tự.
 * Luôn đặt TIMEOUT cho việc chờ — chờ vô hạn là cách khác để treo thread.
 */
@RestController
@Tag(name = "Orders")
@RequestMapping("/dashboard")
public class DashboardController {

    private static final Logger log = LoggerFactory.getLogger(DashboardController.class);

    private final AsyncQueryService asyncService;

    public DashboardController(AsyncQueryService asyncService) {
        this.asyncService = asyncService;
    }

    @GetMapping
    public DashboardResponse tongQuan() throws Exception {
        long batDau = System.currentTimeMillis();

        CompletableFuture<Double> f1 = asyncService.layTyGiaAsync("USD");
        CompletableFuture<Long> f2 = asyncService.demTonKhoAsync();

        CompletableFuture.allOf(f1, f2).get(5, TimeUnit.SECONDS);

        long thoiGian = System.currentTimeMillis() - batDau;
        log.info("Dashboard tổng thời gian: {}ms", thoiGian);
        return new DashboardResponse(f1.join(), f2.join(), thoiGian);
    }
}
