package com.example.shop.order;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.common.audit.AuditService;
import com.example.shop.common.error.BusinessException;
import com.example.shop.common.error.ErrorCode;
import com.example.shop.common.error.ResourceNotFoundException;
import com.example.shop.order.dto.BestSellerResponse;
import com.example.shop.order.dto.CreateOrderRequest;
import com.example.shop.order.dto.OrderItemRequest;
import com.example.shop.product.ProductService;
import com.example.shop.product.dto.ProductSnapshot;

/**
 * Bài 13 — một nghiệp vụ là MỘT transaction: trừ kho, lưu đơn, ghi audit
 * cùng sống hoặc cùng chết.
 *
 * Import từ org.springframework.transaction.annotation — KHÔNG phải jakarta.transaction
 * (thiếu readOnly, propagation, rollbackFor).
 *
 * Spring tiêm vào controller một PROXY bọc ngoài class này. Proxy mở transaction,
 * gọi method thật, xong êm thì commit, có exception thì rollback.
 * → Transaction nằm ở PROXY, không nằm trong code của bạn.
 *
 * ===== THÍ NGHIỆM 1 — tháo @Transactional =====
 * Gỡ @Transactional khỏi class, thêm productRepo.save(p) ở bước 1 (dirty checking chỉ
 * chạy TRONG transaction). Đặt hàng với customerName "LOI ..." → 500.
 * SELECT lại: kho ĐÃ GIẢM, đơn ĐÃ LƯU, audit TRỐNG. Người dùng bấm lại → trừ kho lần nữa.
 * Không có transaction thì mỗi lời gọi repository tự commit ngay.
 *
 * ===== THÍ NGHIỆM 2 — checked exception =====
 * Đổi dòng throw ở công tắc LOI thành  throw new Exception(...)  (+ throws Exception).
 * Dữ liệu BỊ LƯU dù có @Transactional.
 * BẪY 1: Spring chỉ tự rollback với RuntimeException và Error. Checked → COMMIT.
 * Sửa: @Transactional(rollbackFor = Exception.class) — hoặc như Bài 5: exception nghiệp vụ
 * luôn extends RuntimeException.
 *
 * ===== THÍ NGHIỆM 3 — self-invocation (xem datHangSai bên dưới) =====
 */
/*
 * Bài 31 — order CHỈ đi qua ProductService (public API của product), không bao giờ qua
 * ProductRepository hay entity Product — cả hai giờ package-private, import vào là KHÔNG BUILD.
 * Một dòng import bị cấm dẫn tới một quyết định thiết kế tốt hơn.
 *
 * Còn một việc tồn đọng: service này vẫn ôm ba trách nhiệm (đặt hàng, audit, thông báo) và
 * thông báo gửi TRƯỚC khi commit → Bài 32: event nội bộ + @TransactionalEventListener.
 */
@Service
@Transactional
class OrderService {   // Bài 31: package-private — không feature nào khác cần

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepo;
    private final OrderItemRepository orderItemRepo;
    private final ProductService productService;       // KHÔNG phải ProductRepository
    private final AuditService auditService;
    private final NotificationService notificationService;
    private final OrderMetrics metrics;

    OrderService(OrderRepository orderRepo, OrderItemRepository orderItemRepo, ProductService productService,
                 AuditService auditService, NotificationService notificationService, OrderMetrics metrics) {
        this.orderRepo = orderRepo;
        this.orderItemRepo = orderItemRepo;
        this.productService = productService;
        this.auditService = auditService;
        this.notificationService = notificationService;
        this.metrics = metrics;
    }

    /** Bài 29 — bọc bằng Timer + đếm thành công/thất bại. */
    public Order datHang(CreateOrderRequest req) {
        return metrics.doThoiGian(() -> {
            try {
                Order don = xuLyDatHang(req);
                metrics.ghiNhanThanhCong(don.getTotalAmount());
                return don;
            } catch (BusinessException e) {
                metrics.ghiNhanThatBai(e.getCode().name().toLowerCase());
                throw e;
            } catch (RuntimeException e) {
                metrics.ghiNhanThatBai("other");
                throw e;
            }
        });
    }

    private Order xuLyDatHang(CreateOrderRequest req) {
        log.debug("Yêu cầu đặt hàng khách={} số dòng={}", req.customerName(), req.items().size());

        // REQUIRES_NEW — ghi TRƯỚC chỗ có thể lỗi. Đơn rollback thì dòng này vẫn còn (Bài 13).
        auditService.ghi("ATTEMPT", "Order", null,
                "Khách " + req.customerName() + " thử đặt " + req.items().size() + " dòng");

        Order order = new Order(req.customerName());

        // ===== Bước 1: trừ kho — qua API của product =====
        for (OrderItemRequest dong : req.items()) {
            // SNAPSHOT, không phải entity
            ProductSnapshot sp = productService.layThongTinDeDatHang(dong.productId());
            if (sp.stock() < dong.quantity()) {
                throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK, sp.name(), sp.stock(), dong.quantity());
            }
            productService.truTonKho(sp.id(), dong.quantity());   // cùng transaction (REQUIRED)
            order.addItem(new OrderItem(sp.id(), sp.name(), sp.price(), dong.quantity()));
        }

        // ===== Bước 2: lưu đơn =====
        order.tinhTongTien();
        Order daLuu = orderRepo.save(order);

        // ===== Công tắc bật lỗi: tên bắt đầu "LOI" → hỏng ngay trước bước 3 =====
        if (req.customerName().startsWith("LOI")) {
            throw new RuntimeException("Lỗi giả lập sau khi đã trừ kho và lưu đơn");
        }

        // ===== Bước 3: ghi audit — CÙNG transaction =====
        auditService.ghiCungGiaoDich("CREATE", "Order", daLuu.getId(), "Tổng " + daLuu.getTotalAmount());

        log.info("Đã tạo đơn hàng id={} tổng={}", daLuu.getId(), daLuu.getTotalAmount());

        // Bài 20 — @Async: truyền ID và String. Chạy TRƯỚC commit — Bài 32 sửa.
        notificationService.guiThongBaoDatHang(daLuu.getId(), daLuu.getCustomerName());
        return daLuu;
    }

    /**
     * THÍ NGHIỆM 3 — BẪY 2: SELF-INVOCATION.
     *
     * SUPPORTS: không có transaction sẵn thì proxy KHÔNG mở cái mới.
     * Bên trong, this.datHang(req) — "this" là OBJECT THẬT, không phải proxy
     * → lời gọi đi thẳng, @Transactional của datHang KHÔNG có tác dụng.
     * Mỗi lời gọi repository tự commit riêng → đơn "LOI..." vẫn được lưu, dữ liệu lệch.
     *
     * Cùng số phận: @Cacheable (Bài 19), @Async (Bài 20), @PreAuthorize (Bài 23).
     * Cách sửa: tách sang class khác (sạch nhất) · tự tiêm chính mình với @Lazy ·
     * TransactionTemplate.
     *
     * Để thử: bỏ comment endpoint /api/orders/sai trong OrderController, gọi với tên
     * "LOI ...", kiểm tra bằng SQL. Quan sát xong XOÁ method này và endpoint đó.
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public Order datHangSai(CreateOrderRequest req) {
        return this.datHang(req);
    }

    /**
     * Bài 25 — quy tắc giảm giá theo tổng đơn (CHƯA áp vào datHang — dùng để luyện
     * @ParameterizedTest với giá trị SÁT RANH GIỚI).
     * double có sai số — tiền thật nên dùng BigDecimal (lần thứ hai gặp, sau Bài 12).
     */
    double tinhGiamGia(double tongTien) {
        if (tongTien >= 10_000_000) {
            return tongTien * 0.15;
        }
        if (tongTien >= 5_000_000) {
            return tongTien * 0.10;
        }
        if (tongTien >= 2_000_000) {
            return tongTien * 0.05;
        }
        return 0;
    }

    /** Bài 10 → Bài 31: thống kê bán chạy thuộc về order. */
    @Transactional(readOnly = true)
    public java.util.List<BestSellerResponse> banChay(int limit) {
        return orderItemRepo.findBestSellers(PageRequest.of(0, limit));
    }

    @Transactional(readOnly = true)
    public Order findById(Long id) {
        return orderRepo.findByIdWithItems(id)
                .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.ORDER_NOT_FOUND, id));
    }
}
