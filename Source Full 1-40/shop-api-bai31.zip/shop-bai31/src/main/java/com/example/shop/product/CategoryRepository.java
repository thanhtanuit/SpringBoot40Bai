package com.example.shop.product;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shop.product.Category;

interface CategoryRepository extends JpaRepository<Category, Long> {
}
