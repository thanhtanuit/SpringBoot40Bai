/**
 * Feature quản lý sản phẩm và danh mục.
 *
 * <p><b>Cung cấp ra ngoài:</b> {@link com.example.shop.product.ProductService}
 * và các DTO trong {@code product.dto}.
 *
 * <p><b>Không phơi bày:</b> entity {@code Product}, {@code Category}, repository, mapper,
 * specification, {@code ProductServiceImpl} — tất cả package-private.
 *
 * <p><b>Phụ thuộc:</b> chỉ {@code common}. KHÔNG được phụ thuộc {@code order} hay {@code user}.
 *
 * <p><b>Coupling ẩn còn lại:</b> {@code CleanupJob} có câu SQL thuần nhắc tới bảng
 * {@code order_item} — ArchUnit không thấy được chuỗi SQL.
 */
package com.example.shop.product;
