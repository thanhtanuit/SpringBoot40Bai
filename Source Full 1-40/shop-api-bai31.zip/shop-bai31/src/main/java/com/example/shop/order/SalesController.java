package com.example.shop.order;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.common.config.ShopProperties;
import com.example.shop.order.dto.BestSellerResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Bài 31 — GET /api/v1/products/best-sellers (Bài 10) chuyển về feature order.
 * URL giữ nguyên — URL là hợp đồng với client. "/products/best-sellers" cụ thể hơn
 * "/products/{id}" nên Spring chọn đúng dù nằm ở hai controller.
 */
@RestController
@RequestMapping("/products")
@Tag(name = "Products")
public class SalesController {

    private final OrderService service;
    private final ShopProperties props;

    SalesController(OrderService service, ShopProperties props) {
        this.service = service;
        this.props = props;
    }

    @GetMapping("/best-sellers")
    @SecurityRequirements
    @Operation(summary = "Sản phẩm bán chạy")
    public List<BestSellerResponse> bestSellers(@RequestParam(defaultValue = "5") int limit) {
        return service.banChay(Math.min(Math.max(limit, 1), props.maxItemsPerPage()));
    }
}
