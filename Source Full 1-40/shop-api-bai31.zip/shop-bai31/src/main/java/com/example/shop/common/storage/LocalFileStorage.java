package com.example.shop.common.storage;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.shop.common.config.StorageProperties;

/**
 * Bài 17 — lưu file trên đĩa cục bộ.
 *
 * ===== LỖ HỔNG 1: PATH TRAVERSAL =====
 * Viết ngây thơ:  root.resolve(file.getOriginalFilename())   ← NGUY HIỂM
 * originalFilename do CLIENT kiểm soát hoàn toàn — chỉ là một chuỗi trong HTTP request.
 * Gửi "../../../../etc/cron.d/backdoor" → resolve trỏ ra ngoài uploads → ghi đè file hệ thống.
 *
 * Hai lớp phòng thủ:
 *  1. KHÔNG dùng tên client gửi. Server sinh UUID. Tên gốc chỉ để lấy đuôi — cũng qua whitelist.
 *  2. Kiểm tra đường dẫn CUỐI CÙNG: normalize() rút gọn "..", rồi so getParent() với root.
 * Lớp 2 cần cả ở load và delete: filename đến từ DB, nhưng DB cũng có thể đã bị đầu độc.
 * Phòng thủ theo tầng.
 *
 * ===== LỖ HỔNG 2: TIN CONTENT-TYPE =====
 * Content-Type và đuôi file đều do client gửi → giả mạo được hoàn toàn. Hai lớp dưới chỉ
 * chặn người BẤT CẨN, không chặn kẻ tấn công. Làm đúng: đọc magic bytes (Apache Tika):
 *   String thatSu = new Tika().detect(file.getInputStream());
 */
@Service
public class LocalFileStorage implements FileStorageService {

    private static final Logger log = LoggerFactory.getLogger(LocalFileStorage.class);

    private final Path root;
    private final StorageProperties props;

    public LocalFileStorage(StorageProperties props) {
        this.props = props;
        this.root = Paths.get(props.location()).toAbsolutePath().normalize();
        try {
            Files.createDirectories(root);
        } catch (IOException e) {
            throw new IllegalStateException("Không tạo được thư mục lưu file: " + root, e);
        }
    }

    @Override
    public String store(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidFileException("File rỗng");
        }

        String duoi = layDuoiFile(file.getOriginalFilename());
        kiemTraHopLe(file, duoi);

        // Tên do SERVER sinh. Tên client gửi KHÔNG BAO GIỜ dùng để ghép đường dẫn.
        String tenMoi = UUID.randomUUID() + "." + duoi;
        Path dich = root.resolve(tenMoi).normalize();

        if (!root.equals(dich.getParent())) {
            throw new InvalidFileException("Đường dẫn file không hợp lệ");
        }

        try (InputStream in = file.getInputStream()) {
            Files.copy(in, dich, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new StorageException("Lỗi khi lưu file", e);
        }

        log.info("Đã lưu file {} ({} bytes) -> {}", file.getOriginalFilename(), file.getSize(), tenMoi);
        return tenMoi;
    }

    @Override
    public Resource load(String filename) {
        Path file = root.resolve(filename).normalize();
        if (!root.equals(file.getParent())) {
            throw new InvalidFileException("Đường dẫn file không hợp lệ");
        }
        try {
            Resource resource = new UrlResource(file.toUri());
            if (!resource.exists() || !resource.isReadable()) {
                throw new StorageException("Không đọc được file: " + filename, null);
            }
            return resource;
        } catch (IOException e) {
            throw new StorageException("Lỗi khi đọc file: " + filename, e);
        }
    }

    @Override
    public void delete(String filename) {
        Path file = root.resolve(filename).normalize();
        if (!root.equals(file.getParent())) {
            return;
        }
        try {
            Files.deleteIfExists(file);
        } catch (IOException e) {
            log.warn("Không xoá được file {}: {}", filename, e.getMessage());
        }
    }

    private void kiemTraHopLe(MultipartFile file, String duoi) {
        String contentType = file.getContentType();
        if (contentType == null || !props.allowedTypes().contains(contentType.toLowerCase(Locale.ROOT))) {
            throw new InvalidFileException("Chỉ chấp nhận ảnh PNG hoặc JPEG. Nhận được: " + contentType);
        }
        if (!props.allowedExtensions().contains(duoi)) {
            throw new InvalidFileException("Phần mở rộng không hợp lệ: ." + duoi);
        }
    }

    private String layDuoiFile(String originalFilename) {
        String clean = StringUtils.cleanPath(originalFilename == null ? "" : originalFilename);
        String duoi = StringUtils.getFilenameExtension(clean);
        if (duoi == null || duoi.isBlank()) {
            throw new InvalidFileException("File phải có phần mở rộng");
        }
        return duoi.toLowerCase(Locale.ROOT);
    }
}
