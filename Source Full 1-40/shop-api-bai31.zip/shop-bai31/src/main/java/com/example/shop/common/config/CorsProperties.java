package com.example.shop.common.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotEmpty;

/**
 * Bài 24 — danh sách origin được phép. LIỆT KÊ TƯỜNG MINH, đọc từ cấu hình,
 * khác nhau giữa dev và prod. KHÔNG BAO GIỜ để localhost ở production.
 */
@Validated
@ConfigurationProperties(prefix = "shop.cors")
public record CorsProperties(

        @NotEmpty
        List<String> allowedOrigins
) {
}
