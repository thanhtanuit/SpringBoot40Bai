package com.example.shop.user;

enum Role {
    USER, SELLER, ADMIN
}
