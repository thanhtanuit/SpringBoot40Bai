package com.example.shop.user;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shop.user.User;

interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);
}
