package com.example.shop.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * max = 72 KHÔNG tuỳ tiện: BCrypt CẮT BỎ mọi thứ sau byte thứ 72. Không chặn thì hai mật
 * khẩu 100 ký tự có 72 byte đầu giống nhau được coi là trùng khớp.
 * (Ký tự tiếng Việt có dấu chiếm 2–3 byte UTF-8 — 72 ký tự có thể vượt 72 byte.)
 */
public record RegisterRequest(

        @Schema(example = "nguyenvana")
        @NotBlank(message = "{user.username.notblank}")
        @Size(min = 3, max = 50, message = "{user.username.size}")
        @Pattern(regexp = "^[a-zA-Z0-9._-]+$", message = "{user.username.pattern}")
        String username,

        @Schema(example = "matkhau12345")
        @NotBlank(message = "{user.password.notblank}")
        @Size(min = 8, max = 72, message = "{user.password.size}")
        String password,

        @Schema(example = "a@example.com")
        @NotBlank(message = "{user.email.notblank}")
        @Email(message = "{user.email.invalid}")
        String email
) {
}
