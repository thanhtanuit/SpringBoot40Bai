package com.example.shop.product;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.domain.Specification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.shop.common.client.ExchangeRateClient;
import com.example.shop.common.config.ExchangeRateProperties;
import com.example.shop.product.dto.ProductPriceResponse;
import com.example.shop.product.dto.ProductSnapshot;
import com.example.shop.product.dto.ProductResponse;
import com.example.shop.product.dto.ProductFilter;
import com.example.shop.product.dto.UpdateProductRequest;
import com.example.shop.common.error.DuplicateResourceException;
import com.example.shop.common.error.BusinessException;
import com.example.shop.common.error.ErrorCode;
import com.example.shop.common.error.ResourceNotFoundException;
import com.example.shop.product.ProductMapper;
import com.example.shop.product.Product;
import com.example.shop.product.ProductRepository;
import com.example.shop.product.ProductSpecs;
import com.example.shop.common.storage.FileStorageService;

/**
 * Bài 13 — mẫu hay dùng: readOnly = true ở CẤP CLASS, đè bằng @Transactional thường
 * cho method GHI. Method đọc tự thừa hưởng, không phải nhớ gắn từng cái.
 *
 * readOnly làm ba việc: Hibernate bỏ dirty checking (không chụp bản sao entity);
 * driver báo DB giao dịch chỉ đọc; tín hiệu định tuyến sang bản sao chỉ đọc.
 * KHÔNG phải rào chắn bảo mật — SQL thuần vẫn ghi được.
 */
@Service
@Transactional(readOnly = true)
class ProductServiceImpl implements ProductService {   // Bài 31: PACKAGE-PRIVATE

    private static final Logger log = LoggerFactory.getLogger(ProductServiceImpl.class);

    private final ProductRepository repo;
    private final ProductMapper mapper;
    private final FileStorageService storage;
    private final ExchangeRateClient exchangeRateClient;
    private final ExchangeRateProperties exchangeRateProps;

    ProductServiceImpl(ProductRepository repo, ProductMapper mapper, FileStorageService storage,
                       ExchangeRateClient exchangeRateClient, ExchangeRateProperties exchangeRateProps) {
        this.repo = repo;
        this.mapper = mapper;
        this.storage = storage;
        this.exchangeRateClient = exchangeRateClient;
        this.exchangeRateProps = exchangeRateProps;
    }

    /** Hai câu SQL: một lấy dữ liệu trang (offset/fetch first), một SELECT count. */
    public Page<Product> findAll(Pageable pageable) {
        Page<Product> trang = repo.findAll(pageable);
        log.debug("Trang {} — {} / {} sản phẩm", pageable.getPageNumber(),
                trang.getNumberOfElements(), trang.getTotalElements());
        return trang;
    }

    /** Một câu SQL — Slice bỏ câu count. */
    public Slice<Product> scroll(Pageable pageable) {
        return repo.findSliceBy(pageable);
    }

    /**
     * Bài 15 — so với Bài 10: không if/else, không sáu tham số, không hai khối JPQL
     * phải giữ đồng bộ tay. Bộ lọc không gửi → spec null → biến mất khỏi SQL.
     *
     * AND: Specification.allOf(...) · OR: Specification.anyOf(...), ví dụ
     *   Specification.anyOf(ProductSpecs.hasKeyword(kw), ProductSpecs.skuLike(kw))
     */
    public Page<Product> search(ProductFilter filter, Pageable pageable) {
        Specification<Product> spec = Specification.allOf(
                ProductSpecs.hasKeyword(filter.keyword()),
                ProductSpecs.priceGte(filter.minPrice()),
                ProductSpecs.priceLte(filter.maxPrice()),
                ProductSpecs.inCategory(filter.categoryId()),
                ProductSpecs.categoryNameLike(filter.categoryName()),
                ProductSpecs.inStock(filter.inStock()));
        return repo.findAll(spec, pageable);
    }

    // ===== Bài 31: API cho feature KHÁC (order) — qua interface ProductService =====

    @Override
    public ProductSnapshot layThongTinDeDatHang(Long productId) {
        Product p = findById(productId);
        return new ProductSnapshot(p.getId(), p.getName(), p.getPrice(), p.getStock());
    }

    /**
     * Thao tác NGHIỆP VỤ, không phải truy cập dữ liệu thô: order không bao giờ tự setStock.
     * Tham gia transaction của người gọi (REQUIRED) → đơn rollback thì kho cũng rollback.
     * Kiểm tra lại tồn kho ở đây — bất biến của product do product giữ.
     * Tự dọn cache (Bài 19) — trước đây OrderService phải biết tên cache "products".
     */
    @Override
    @Transactional
    @CacheEvict(value = "products", key = "#productId")
    public void truTonKho(Long productId, int soLuong) {
        Product p = findById(productId);
        if (p.getStock() < soLuong) {
            throw new BusinessException(ErrorCode.INSUFFICIENT_STOCK, p.getName(), p.getStock(), soLuong);
        }
        p.setStock(p.getStock() - soLuong);   // dirty checking
    }

    public Product findById(Long id) {
        log.debug("Tìm sản phẩm id={}", id);
        return repo.findById(id).orElseThrow(() -> {
            log.warn("Không tìm thấy sản phẩm id={}", id);
            return new ResourceNotFoundException(ErrorCode.PRODUCT_NOT_FOUND, id);
        });
    }

    /**
     * Bài 19 — ĐỌC CÓ CACHE, trả DTO.
     * Gọi GET /api/products/1 ba lần: dòng "CHẠM DATABASE" chỉ xuất hiện MỘT lần.
     *
     * Không cache exception: findResponseById(9999) mỗi lần đều chạm DB. Thường là tốt —
     * nhưng cũng là lỗ hổng nếu bị spam id không tồn tại.
     *
     * Method GHI không lấy dữ liệu từ cache: chúng gọi findById (không cache) — và gọi
     * qua "this" thì @Cacheable cũng không chạy (self-invocation, Bài 13).
     */
    @Cacheable(value = "products", key = "#id")
    public ProductResponse findResponseById(Long id) {
        log.info("== CHẠM DATABASE cho sản phẩm id={} ==", id);
        return mapper.toResponse(findById(id));
    }

    @Transactional
    public Product create(String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu tạo sản phẩm name={} sku={} price={} stock={}", name, sku, price, stock);
        if (repo.existsByNameIgnoreCase(name)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySku(sku)) {
            tuChoiTrungSku(sku);
        }
        Product moi = repo.save(new Product(name, sku, price, stock == null ? 0 : stock));
        log.info("Đã tạo sản phẩm id={} name={}", moi.getId(), moi.getName());
        return moi;
    }

    /**
     * DIRTY CHECKING: không có repo.save() ở đâu cả, dữ liệu vẫn được lưu.
     *
     * Entity lấy ra BÊN TRONG giao dịch ở trạng thái managed. Hibernate giữ bản chụp
     * giá trị lúc nạp; tới lúc commit so sánh, thấy khác thì tự sinh UPDATE.
     *
     * BẪY: hệ quả ngược cũng đúng — sửa một entity managed mà KHÔNG định lưu
     * (ví dụ đổi giá tạm để tính toán) thì tới lúc commit nó VẪN bị lưu.
     */
    /**
     * BẪY 1 — CACHE KHÔNG ĐƯỢC DỌN: bỏ @CacheEvict, GET → PATCH giá → GET lại → GIÁ CŨ.
     * DB đúng, cache sai. Không lỗi, không log — lộ ra sau vài ngày trên production.
     * MỌI đường ghi phải dọn cache tương ứng — kể cả OrderService trừ kho.
     */
    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public Product update(Long id, String name, String sku, double price, Integer stock) {
        log.debug("Yêu cầu sửa sản phẩm id={}", id);
        Product p = findById(id);
        if (repo.existsByNameIgnoreCaseAndIdNot(name, id)) {
            tuChoiTrungTen(name);
        }
        if (repo.existsBySkuAndIdNot(sku, id)) {
            tuChoiTrungSku(sku);
        }
        p.setName(name);
        p.setSku(sku);
        p.setPrice(price);
        p.setStock(stock == null ? 0 : stock);
        log.info("Đã sửa sản phẩm id={}", id);
        return p;
    }

    /**
     * Bài 14 — PATCH tổng quát. Chỉ trường nào gửi mới đổi.
     * Không save — dirty checking. Thay cho updatePrice của Bài 2.
     */
    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public Product patch(Long id, UpdateProductRequest req) {
        Product p = findById(id);
        if (req.name() != null && repo.existsByNameIgnoreCaseAndIdNot(req.name(), id)) {
            tuChoiTrungTen(req.name());
        }
        if (req.sku() != null && repo.existsBySkuAndIdNot(req.sku(), id)) {
            tuChoiTrungSku(req.sku());
        }
        mapper.updateFromRequest(req, p);
        log.info("Đã cập nhật một phần sản phẩm id={}", id);
        return p;
    }

    /** Bài 16: repo.delete → @SQLDelete → UPDATE deleted = true. Dòng vẫn còn trong DB. */
    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public void delete(Long id) {
        repo.delete(findById(id));
        log.info("Đã xoá sản phẩm id={}", id);
    }

    /**
     * Bài 18 — SUY GIẢM CÓ KIỂM SOÁT: API tỷ giá chết thì chức năng chính vẫn chạy,
     * người dùng thấy con số hơi cũ thay vì màn hình lỗi.
     *
     * Lời gọi mạng nằm trong transaction readOnly → giữ connection DB trong lúc chờ mạng.
     * Ở đây chấp nhận vì có timeout và cache; hệ thống lớn nên gọi mạng NGOÀI transaction.
     */
    public ProductPriceResponse giaQuyDoi(Long id) {
        Product p = findById(id);

        double tyGia;
        String nguon;
        try {
            tyGia = exchangeRateClient.layTyGia("USD");
            nguon = "API";
        } catch (RuntimeException ex) {
            log.warn("Hết lượt thử gọi API tỷ giá ({}), dùng giá trị mặc định", ex.getMessage());
            tyGia = 1.0 / exchangeRateProps.defaultUsdRate();
            nguon = "MAC_DINH";
        }

        double usd = Math.round(p.getPrice() * tyGia * 100) / 100.0;
        return new ProductPriceResponse(p.getId(), p.getName(), p.getPrice(), "VND", usd, "USD", nguon);
    }

    /**
     * Bài 17 — thao tác file KHÔNG nằm trong transaction database.
     * Rollback sau khi file đã ghi → file MỒ CÔI trên đĩa. Xoá file trước khi commit mà
     * transaction hỏng → mất file trong khi DB vẫn trỏ tới.
     * Cách thực tế: ghi file mới trước, xoá file cũ SAU KHI COMMIT
     * (@TransactionalEventListener(AFTER_COMMIT) — Bài 32), cộng job dọn mồ côi định kỳ.
     */
    @Transactional
    public String capNhatAnh(Long id, MultipartFile file) {
        Product p = findById(id);
        String cu = p.getImagePath();
        String moi = storage.store(file);
        p.setImagePath(moi);
        if (cu != null) {
            storage.delete(cu);
        }
        return moi;
    }

    @Transactional
    public void xoaAnh(Long id) {
        Product p = findById(id);
        if (p.getImagePath() != null) {
            storage.delete(p.getImagePath());
            p.setImagePath(null);
        }
    }

    /** Bài 16 — danh sách đã xoá mềm (native query, không qua @SQLRestriction). */
    public List<Product> findDeleted() {
        return repo.findDeleted();
    }

    /**
     * Bài 16 — khôi phục. Nếu trong lúc đó đã có sản phẩm cùng tên/sku đang hoạt động
     * → vi phạm partial unique index → DataIntegrityViolationException → 409.
     */
    @Transactional
    @CacheEvict(value = "products", key = "#id")
    public void restore(Long id) {
        if (repo.restore(id) == 0) {
            throw new ResourceNotFoundException(ErrorCode.DELETED_PRODUCT_NOT_FOUND, id);
        }
        log.info("Đã khôi phục sản phẩm id={}", id);
    }

    private void tuChoiTrungSku(String sku) {
        log.warn("Từ chối vì trùng SKU: {}", sku);
        throw new DuplicateResourceException(ErrorCode.DUPLICATE_SKU, sku);
    }

    private void tuChoiTrungTen(String name) {
        log.warn("Từ chối vì trùng tên: {}", name);
        throw new DuplicateResourceException(ErrorCode.DUPLICATE_NAME, name);
    }
}
