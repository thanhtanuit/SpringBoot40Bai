package com.example.shop.order;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Bài 20 — @Async: API trả về ~100ms trong khi thông báo mất 3 giây.
 *
 * BẪY — @Async + @Transactional KHÔNG nên đặt chung:
 *  1. Transaction KHÔNG LAN sang thread khác (nằm trong ThreadLocal). @Transactional ở đây
 *     tạo transaction ĐỘC LẬP — gốc rollback thì việc async VẪN commit.
 *  2. Entity truyền qua thread là MÌN: session gốc đã đóng → LazyInitializationException.
 *     → Chỉ truyền ID và giá trị thuần (Long orderId, String customerName).
 *       Cần entity thì nạp lại trong thread mới.
 *  3. Self-invocation (Bài 13): gọi this.guiThongBao(...) → chạy ĐỒNG BỘ, im lặng.
 *
 * Còn một vấn đề: thông báo gửi TRƯỚC khi transaction commit. Rollback sau đó thì khách
 * đã nhận email về một đơn không tồn tại → Bài 32: @TransactionalEventListener(AFTER_COMMIT).
 */
@Service
class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    @Async("taskExecutor")
    public void guiThongBaoDatHang(Long orderId, String customerName) {
        log.info("Bắt đầu gửi thông báo cho đơn {}", orderId);
        try {
            Thread.sleep(3000);   // giả lập SMTP chậm
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        log.info("Đã gửi thông báo cho {} (đơn {})", customerName, orderId);
    }
}
