/**
 * Feature đặt hàng.
 *
 * <p><b>Phụ thuộc:</b> {@code common} và {@code product} — CHỈ qua
 * {@link com.example.shop.product.ProductService} và {@code product.dto}, không bao giờ qua repository
 * hay entity (được ArchitectureTest kiểm).
 *
 * <p>{@code OrderItem} lưu bản sao {@code productName} và {@code unitPrice} tại thời điểm mua,
 * không còn khoá ngoại sang {@code product} (V16). Giá hay tên sản phẩm đổi về sau không làm sai đơn cũ.
 *
 * <p>{@code OrderSecurity} là public: SpEL trong {@code @PreAuthorize} gọi nó từ ngoài package.
 */
package com.example.shop.order;
