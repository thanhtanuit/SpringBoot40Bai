package com.example.shop.common.web;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.example.shop.common.error.ApiResponse;

/**
 * Bài 30 — bọc MỌI response thành công trong ApiResponse, không phải sửa từng controller.
 *
 * Chỉ bọc khi converter là JSON (Jackson):
 *  - String đi qua StringHttpMessageConverter — bọc vào là ClassCastException (HelloController Bài 1)
 *  - Resource (ảnh, Bài 17) đi qua ResourceHttpMessageConverter — không phải JSON
 *
 * body đã là ApiResponse (từ GlobalExceptionHandler) → trả nguyên. Không kiểm bằng kiểu khai báo
 * của method: handler khai ResponseEntity<ApiResponse<Void>> nên kiểu đó là ResponseEntity.
 *
 * basePackages: chỉ controller của mình — actuator, springdoc giữ nguyên định dạng của chúng.
 * (Hệ quả: tài liệu OpenAPI vẫn hiện kiểu CHƯA bọc — một cái giá của cách làm này.)
 */
@RestControllerAdvice(basePackages = "com.example.shop")   // Bài 31: controller theo feature
public class ApiResponseWrapper implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter returnType,
                            Class<? extends HttpMessageConverter<?>> converterType) {
        return MappingJackson2HttpMessageConverter.class.isAssignableFrom(converterType);
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType contentType,
                                  Class<? extends HttpMessageConverter<?>> converterType,
                                  ServerHttpRequest request, ServerHttpResponse response) {
        if (body instanceof ApiResponse<?>) {
            return body;
        }
        return ApiResponse.ok(body);
    }
}
