package com.example.shop.common.web;

/**
 * Record: class chỉ chứa dữ liệu, viết một dòng là xong.
 * Trả object này về từ controller → Jackson biến thành JSON:
 *   {"a":3,"b":5,"tong":8}
 */
public record KetQua(int a, int b, int tong) {
}
