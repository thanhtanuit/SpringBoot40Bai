package com.example.shop.order;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.shop.order.dto.BestSellerResponse;

/**
 * Bài 31 — thống kê bán chạy chuyển từ product sang order: dữ liệu bán hàng thuộc về order.
 * Không JOIN sang product nữa: productId, productName có sẵn trên dòng hàng (V16).
 * Constructor expression: tên class ĐẦY ĐỦ — đổi package là phải sửa chuỗi này (JPQL chỉ là chuỗi).
 */
interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    @Query("""
            SELECT new com.example.shop.order.dto.BestSellerResponse(oi.productId, oi.productName, SUM(oi.quantity))
            FROM OrderItem oi
            GROUP BY oi.productId, oi.productName
            ORDER BY SUM(oi.quantity) DESC
            """)
    List<BestSellerResponse> findBestSellers(Pageable pageable);
}
