package com.example.shop.common.payment;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Bản giả — không trừ tiền ai.
 *
 * BẪY 2: nếu viết @Profile("dev"), chạy profile "test" hay "staging" sẽ KHÔNG có
 * bean PaymentGateway nào → app chết lúc khởi động.
 * "!prod" = mọi profile TRỪ prod. Thêm môi trường mới không phải nhớ sửa gì.
 */
@Component
@Profile("!prod")
public class FakePaymentGateway implements PaymentGateway {

    private static final Logger log = LoggerFactory.getLogger(FakePaymentGateway.class);

    @Override
    public String thanhToan(Long orderId, double soTien) {
        log.info("[GIẢ LẬP] Thanh toán đơn {} số tiền {}", orderId, soTien);
        return "FAKE-" + UUID.randomUUID().toString().substring(0, 8);
    }
}
