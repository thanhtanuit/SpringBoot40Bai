package com.example.shop.order.dto;

/** totalSold là Long vì SUM trả Long. */
public record BestSellerResponse(Long productId, String productName, Long totalSold) {
}
