package com.example.shop.product;

import com.example.shop.common.audit.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Danh mục. Tồn tại ĐỘC LẬP, nhiều sản phẩm dùng chung
 * → Product → Category tuyệt đối KHÔNG cascade.
 */
@Entity
@Table(name = "category",
       uniqueConstraints = @UniqueConstraint(name = "uk_category_name", columnNames = "name"))
class Category extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    protected Category() {
    }

    public Category(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
