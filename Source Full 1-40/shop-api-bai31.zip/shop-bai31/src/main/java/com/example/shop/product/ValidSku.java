package com.example.shop.product;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.RECORD_COMPONENT;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

/**
 * Nâng cao — annotation tự viết: mã SKU dạng ABC-1234
 * (ba chữ in hoa, gạch ngang, bốn chữ số).
 *
 * RECORD_COMPONENT: thiếu nó thì không gắn được lên trường của record.
 * message, groups, payload: ba thành phần Bean Validation bắt buộc.
 *
 * Luật định dạng nằm ở MỘT chỗ. Đổi luật: sửa SkuValidator, mọi nơi tự đúng theo.
 * Bài 12: đã gắn vào CreateProductRequest.sku.
 */
@Documented
@Constraint(validatedBy = SkuValidator.class)
@Target({FIELD, PARAMETER, RECORD_COMPONENT})
@Retention(RUNTIME)
public @interface ValidSku {

    String message() default "{product.sku.invalid}";   // Bài 30: khoá i18n

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
