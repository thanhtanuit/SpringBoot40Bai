package com.example.shop.user;

import com.example.shop.common.audit.BaseEntity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;

/** Bài 21 — tài khoản. KHÔNG BAO GIỜ trả entity này ra API — mang hash mật khẩu. */
@Entity
@Table(name = "app_user")
class User extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String username;

    /** Hash BCrypt, không bao giờ là mật khẩu gốc. */
    @Column(nullable = false, length = 100)
    private String password;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(nullable = false)
    private boolean enabled = true;

    /**
     * EAGER — một trong số ít ngoại lệ của quy tắc "luôn LAZY" (Bài 9): UserDetailsService
     * nạp user rồi trả về, session đóng ngay; roles LAZY sẽ nổ LazyInitializationException
     * lúc Spring Security kiểm tra quyền. Tập roles luôn nhỏ.
     *
     * @ElementCollection: Role là enum, không phải entity — không cần bảng role có id.
     */
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role", length = 20)
    @Enumerated(EnumType.STRING)
    private Set<Role> roles = new HashSet<>();

    protected User() {
    }

    public User(String username, String password, String email, Set<Role> roles) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.roles = new HashSet<>(roles);
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public Set<Role> getRoles() {
        return roles;
    }
}
