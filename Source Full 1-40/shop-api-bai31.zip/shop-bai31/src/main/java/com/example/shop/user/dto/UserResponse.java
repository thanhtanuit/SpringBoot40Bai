package com.example.shop.user.dto;

import java.util.List;

/**
 * KHÔNG có field password. Giá trị của DTO (Bài 4) lộ rõ nhất ở đây: trả entity User là
 * đưa hash mật khẩu ra API — không đảo ngược được, nhưng cho phép tấn công offline.
 */
public record UserResponse(Long id, String username, String email, List<String> roles) {
}
