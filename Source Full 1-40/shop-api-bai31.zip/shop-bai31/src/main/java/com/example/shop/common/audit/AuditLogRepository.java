package com.example.shop.common.audit;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.shop.common.audit.AuditLog;

interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findTop20ByOrderByIdDesc();
}
