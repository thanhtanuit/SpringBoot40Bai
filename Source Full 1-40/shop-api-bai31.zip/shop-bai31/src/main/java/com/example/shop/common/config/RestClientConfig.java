package com.example.shop.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * Bài 18 — RestClient (Spring 6.1): API đồng bộ mới thay RestTemplate. Fluent như WebClient
 * nhưng không kéo Reactor/WebFlux. RestTemplate chưa deprecated nhưng ngừng nhận tính năng mới.
 *
 * BẪY 1: BỎ TRỐNG TIMEOUT = VÔ HẠN. Dịch vụ ngoài treo giữ thread của bạn mãi mãi.
 * Tomcat có 200 thread → 200 request là TOÀN BỘ API chết, kể cả endpoint chẳng liên quan.
 * Thử 3: comment dòng requestFactory, trỏ vào endpoint treo, bắn nhiều request — tự chứng kiến.
 */
@Configuration
public class RestClientConfig {

    @Bean
    public RestClient exchangeRateRestClient(RestClient.Builder builder, ExchangeRateProperties props) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(props.connectTimeout());
        factory.setReadTimeout(props.readTimeout());

        return builder
                .baseUrl(props.baseUrl())
                .requestFactory(factory)
                .defaultHeader("Accept", "application/json")
                .build();
    }
}
