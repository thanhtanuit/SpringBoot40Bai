/**
 * Hạ tầng dùng chung: error, audit, security, storage, client, config, web, payment, job.
 *
 * <p><b>Luật:</b> common KHÔNG BAO GIỜ trỏ ngược lên feature ({@code product}, {@code order},
 * {@code user}). Cần thứ gì của feature → feature tự khai báo (ví dụ {@code product.ProductCacheConfig}).
 */
package com.example.shop.common;
