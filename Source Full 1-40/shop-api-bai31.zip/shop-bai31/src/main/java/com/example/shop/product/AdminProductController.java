package com.example.shop.product;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.product.ProductServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Bài 16 — quản trị xoá mềm.
 *
 * CHƯA CÓ BẢO MẬT: ai cũng gọi được. Bài 21 dành /api/admin/** riêng cho ADMIN —
 * nhớ quay lại siết.
 */
@RestController
@RequestMapping("/admin/products")
@Tag(name = "Admin")
public class AdminProductController {

    private final ProductServiceImpl service;

    public AdminProductController(ProductServiceImpl service) {
        this.service = service;
    }

    @GetMapping("/deleted")
    @Operation(summary = "Sản phẩm đã xoá mềm")
    public List<Map<String, Object>> daXoa() {
        return service.findDeleted().stream()
                .map(p -> Map.<String, Object>of(
                        "id", p.getId(),
                        "name", p.getName(),
                        "sku", p.getSku(),
                        "deletedAt", p.getUpdatedAt()))
                .toList();
    }

    @PostMapping("/{id}/restore")
    @Operation(summary = "Khôi phục sản phẩm", description = "409 nếu đã có sản phẩm đang hoạt động cùng tên/SKU.")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void khoiPhuc(@PathVariable Long id) {
        service.restore(id);
    }
}
