package com.example.shop.order;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.order.OrderRepository;

/**
 * Bài 23 — QUYỀN SỞ HỮU: luật không diễn đạt được bằng vai trò.
 * Gọi từ SpEL: @PreAuthorize("@orderSecurity.isOwner(#id, authentication)") — tên bean phải
 * khớp chính xác, nên @Component("orderSecurity") viết rõ.
 *
 * createdBy (Bài 16 + Bài 22) giờ quyết định ai đọc được đơn.
 *
 * ĐÁNH ĐỔI: truy vấn DB TRƯỚC khi controller chạy, rồi controller truy vấn lần nữa — hai SELECT.
 * Endpoint gọi nhiều thì cân nhắc kiểm tra bên trong service, nơi entity đã nạp sẵn.
 */
@Component("orderSecurity")
public class OrderSecurity {

    private final OrderRepository orderRepo;

    public OrderSecurity(OrderRepository orderRepo) {
        this.orderRepo = orderRepo;
    }

    @Transactional(readOnly = true)
    public boolean isOwner(Long orderId, Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) {
            return false;
        }
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (isAdmin) {
            return true;
        }
        // Đơn không tồn tại → false → 403 (không để lộ đơn nào có thật qua 404)
        return orderRepo.findById(orderId)
                .map(o -> auth.getName().equals(o.getCreatedBy()))
                .orElse(false);
    }
}
