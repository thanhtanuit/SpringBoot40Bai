package com.example.shop.product.dto;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Bài 23 thêm costPrice. @JsonInclude(NON_NULL): null thì BIẾN MẤT khỏi JSON, thay vì
 * hiện "costPrice": null (lộ ra rằng có trường này).
 */
public record ProductResponse(
        Long id,
        String name,
        String sku,
        double price,
        int stock,
        String categoryName,
        Instant createdAt,
        Instant updatedAt,
        @Schema(description = "Giá vốn — CHỈ hiện với ADMIN", nullable = true)
        @JsonInclude(JsonInclude.Include.NON_NULL) Double costPrice
) {

    public ProductResponse anGiaVon() {
        return new ProductResponse(id, name, sku, price, stock, categoryName, createdAt, updatedAt, null);
    }
}
