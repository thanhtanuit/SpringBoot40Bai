/**
 * Feature tài khoản: đăng ký, đăng nhập, refresh token.
 *
 * <p><b>Phụ thuộc:</b> chỉ {@code common}. Hạ tầng bảo mật dùng chung (JWT, filter, SecurityConfig)
 * nằm ở {@code common.security}; feature này cung cấp {@code UserDetailsService} qua interface của Spring
 * — common không biết tới class cụ thể.
 */
package com.example.shop.user;
