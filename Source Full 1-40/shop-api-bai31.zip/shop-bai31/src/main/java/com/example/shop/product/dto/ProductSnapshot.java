package com.example.shop.product.dto;

/**
 * Bài 31 — dữ liệu TỐI THIỂU order cần — KHÔNG phải entity Product.
 * Bất biến, không lazy loading, không dính session Hibernate.
 */
public record ProductSnapshot(Long id, String name, double price, int stock) {
}
