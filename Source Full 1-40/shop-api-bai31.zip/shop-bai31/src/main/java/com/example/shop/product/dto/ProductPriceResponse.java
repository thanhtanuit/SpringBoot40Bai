package com.example.shop.product.dto;

/**
 * Bài 18. nguonTyGia = "API" hoặc "MAC_DINH" — client biết con số là thật hay dự phòng.
 */
public record ProductPriceResponse(
        Long id,
        String name,
        double price,
        String currency,
        double convertedPrice,
        String convertedCurrency,
        String nguonTyGia
) {
}
