package com.example.shop.common.config;

import java.util.List;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.tags.Tag;

/**
 * Bài 28 — thông tin chung + nút AUTHORIZE.
 *
 * addSecurityItem + addSecuritySchemes làm nút Authorize hoạt động: dán accessToken (KHÔNG kèm
 * chữ "Bearer"), Swagger tự gắn header Authorization cho mọi lời gọi.
 * Endpoint công khai đánh dấu @SecurityRequirements (rỗng) để Swagger không đòi token.
 *
 * Springdoc đọc @PreAuthorize để vẽ ổ khoá, nhưng TÀI LIỆU LÀ MÔ TẢ, KHÔNG PHẢI THỰC THI.
 * Nguồn sự thật về phân quyền là test ở Bài 26.
 */
@Configuration
public class OpenApiConfig {

    private static final String BEARER = "bearerAuth";

    @Bean
    public OpenAPI shopOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Shop API")
                        .version("v1")
                        .description("""
                                API quản lý sản phẩm, danh mục và đơn hàng.

                                **Xác thực:** gọi `POST /api/v1/auth/login` để lấy `accessToken`,
                                rồi bấm **Authorize** ở góc trên bên phải và dán token vào.

                                **Tài khoản mẫu (dev):** `admin / admin12345`, `seller / seller12345`, `user1 / user12345`

                                Mọi response bọc trong `{ success, data | error, timestamp }`. Lỗi có `error.code` ổn định; `error.message` dịch theo `Accept-Language` (vi, en).
                                """)
                        .contact(new Contact().name("Đội Backend").email("dev@shop.local"))
                        .license(new License().name("Nội bộ")))
                .servers(List.of(
                        new Server().url("http://localhost:8081").description("Local"),
                        new Server().url("https://api.shop.example").description("Production")))
                .tags(List.of(   // thứ tự hiển thị
                        new Tag().name("Auth").description("Đăng ký, đăng nhập, làm mới token"),
                        new Tag().name("Products").description("Quản lý sản phẩm"),
                        new Tag().name("Product images").description("Ảnh sản phẩm"),
                        new Tag().name("Orders").description("Đặt hàng và tra cứu đơn"),
                        new Tag().name("Admin").description("Quản trị — yêu cầu vai trò ADMIN"),
                        new Tag().name("Dev").description("Chỉ để học — không có ở API thật")))
                .addSecurityItem(new SecurityRequirement().addList(BEARER))
                .components(new Components().addSecuritySchemes(BEARER,
                        new SecurityScheme()
                                .name(BEARER)
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("Dán accessToken lấy từ /api/auth/login")));
    }

    /**
     * Nâng cao — chia nhiều nhóm tài liệu, Swagger UI hiện dropdown chọn nhóm.
     * Khai GroupedOpenApi thì nhóm mặc định biến mất → "all" khai tường minh.
     */
    @Bean
    public GroupedOpenApi allApi() {
        return GroupedOpenApi.builder().group("all").pathsToMatch("/api/**").build();
    }

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("public")
                .pathsToMatch("/api/v1/auth/**", "/api/v1/products/**", "/api/v1/orders/**")
                .build();
    }

    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder().group("admin").pathsToMatch("/api/v1/admin/**").build();
    }
}
