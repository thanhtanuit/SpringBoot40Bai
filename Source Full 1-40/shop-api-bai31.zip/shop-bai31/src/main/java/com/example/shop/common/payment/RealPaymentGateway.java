package com.example.shop.common.payment;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.example.shop.common.config.PaymentProperties;

/**
 * Bản thật — chỉ tạo khi profile prod bật.
 * Bài 18 mới nối cổng thanh toán thật; tạm thời ném lỗi.
 */
@Component
@Profile("prod")
public class RealPaymentGateway implements PaymentGateway {

    private final PaymentProperties props;

    public RealPaymentGateway(PaymentProperties props) {
        this.props = props;
    }

    @Override
    public String thanhToan(Long orderId, double soTien) {
        // props.apiKey() sẽ dùng để gọi API thật ở Bài 18
        throw new UnsupportedOperationException("Chưa nối cổng thanh toán thật — Bài 18");
    }
}
