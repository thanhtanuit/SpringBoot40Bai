package com.example.shop.common.error;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Bài 30 — định dạng response thống nhất (ApiResponseWrapper bọc tự động).
 *
 * NON_NULL: response thành công không có "error": null thừa, và ngược lại.
 *
 * BẮT BUỘC giữ đúng HTTP status. Biến thể "luôn 200, success: false" làm MỌI công cụ giám sát,
 * CDN, gateway báo "không lỗi" trong khi hệ thống đang hỏng. Bọc body là một chuyện;
 * NÓI DỐI về status là chuyện khác hẳn.
 *
 * Tên trùng annotation io.swagger...ApiResponse — ở controller dùng tên đầy đủ khi cần.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiResponse<T>(
        boolean success,
        T data,
        ApiError error,
        Instant timestamp
) {

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(true, data, null, Instant.now());
    }

    public static <T> ApiResponse<T> fail(ApiError error) {
        return new ApiResponse<>(false, null, error, Instant.now());
    }
}
