package com.example.shop.common.storage;

import com.example.shop.common.error.BusinessException;
import com.example.shop.common.error.ErrorCode;

/** 400 INVALID_FILE. lyDo chèn vào thông điệp — đã là câu tiếng Việt nội bộ, dịch được nếu cần mã riêng. */
public class InvalidFileException extends BusinessException {

    public InvalidFileException(String lyDo) {
        super(ErrorCode.INVALID_FILE, lyDo);
    }
}
