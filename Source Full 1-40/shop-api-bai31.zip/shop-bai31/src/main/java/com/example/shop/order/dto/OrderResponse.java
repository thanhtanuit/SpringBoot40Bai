package com.example.shop.order.dto;

import java.time.Instant;
import java.util.List;

/**
 * PHẲNG — không có tham chiếu vòng nào (item không trỏ ngược về đơn).
 * Trả thẳng entity Order ra ngoài → Order.items → OrderItem.order → Order.items...
 * Jackson lặp vô tận tới StackOverflowError. JSON là CÂY, không có tham chiếu vòng.
 */
public record OrderResponse(
        Long id,
        String customerName,
        double totalAmount,
        Instant createdAt,
        List<OrderItemResponse> items
) {
}
