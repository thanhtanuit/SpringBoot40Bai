package com.example.shop.common.web;

import java.io.IOException;
import java.util.UUID;
import java.util.regex.Pattern;

import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Gắn một mã cho mỗi request vào MDC → mọi dòng log trong request đó mang mã này.
 *   grep a3f9c2e1 logs/shop-api.log   → toàn bộ hành trình của đúng một request.
 *
 * - Request đã có X-Request-Id (từ gateway/client) thì DÙNG LẠI, để truy vết
 *   xuyên nhiều dịch vụ. Chỉ nhận chuỗi ngắn, an toàn — tránh chèn rác vào log.
 * - Trả mã về header response, để khách báo lỗi kèm luôn mã.
 *
 * BẪY 2: MDC.clear() trong FINALLY là BẮT BUỘC.
 * MDC nằm trong ThreadLocal, mà Tomcat TÁI SỬ DỤNG thread giữa các request.
 * Quên dọn → request sau thừa hưởng mã của request trước. Không lỗi, không cảnh báo,
 * chỉ là mã sai — và bạn truy vết nhầm người dùng cả buổi chiều.
 * (@Async ở Bài 20 gặp lại chuyện này → TaskDecorator.)
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestIdFilter extends OncePerRequestFilter {

    public static final String HEADER = "X-Request-Id";
    public static final String MDC_KEY = "requestId";
    private static final Pattern HOP_LE = Pattern.compile("^[A-Za-z0-9-]{1,64}$");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String id = request.getHeader(HEADER);
        if (id == null || !HOP_LE.matcher(id).matches()) {
            id = UUID.randomUUID().toString().substring(0, 8);
        }

        MDC.put(MDC_KEY, id);
        response.setHeader(HEADER, id);
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }
}
