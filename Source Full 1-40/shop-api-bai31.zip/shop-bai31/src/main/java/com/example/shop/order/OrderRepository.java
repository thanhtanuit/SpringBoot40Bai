package com.example.shop.order;

import java.time.Instant;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface OrderRepository extends JpaRepository<Order, Long> {

    /** Bài 31: không còn JOIN FETCH i.product — dòng hàng đã mang sẵn tên sản phẩm. */
    @Query("""
            SELECT DISTINCT o FROM Order o
            LEFT JOIN FETCH o.items
            WHERE o.id = :id
            """)
    Optional<Order> findByIdWithItems(@Param("id") Long id);

    /** Bài 20 — OrderStatsJob. createdAt nằm ở BaseEntity (Bài 16). */
    long countByCreatedAtAfter(Instant moc);
}
