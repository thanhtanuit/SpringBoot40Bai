package com.example.shop.user;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.shop.common.config.JwtProperties;
import com.example.shop.common.error.ErrorCode;
import com.example.shop.common.error.InvalidTokenException;
import com.example.shop.user.RefreshToken;
import com.example.shop.user.User;
import com.example.shop.user.RefreshTokenRepository;
import com.example.shop.user.UserRepository;

/**
 * Bài 22 — refresh token trong DB.
 *
 * noRollbackFor = InvalidTokenException: khi phát hiện TÁI SỬ DỤNG, ta thu hồi toàn bộ phiên
 * RỒI ném exception. Không có noRollbackFor, exception (RuntimeException) làm transaction
 * ROLLBACK — việc thu hồi biến mất (Bài 13).
 */
@Service
@Transactional(noRollbackFor = InvalidTokenException.class)
class RefreshTokenService {

    private static final Logger log = LoggerFactory.getLogger(RefreshTokenService.class);
    private static final SecureRandom RANDOM = new SecureRandom();

    private final RefreshTokenRepository repo;
    private final UserRepository userRepo;
    private final JwtProperties props;

    public RefreshTokenService(RefreshTokenRepository repo, UserRepository userRepo, JwtProperties props) {
        this.repo = repo;
        this.userRepo = userRepo;
        this.props = props;
    }

    public String taoMoi(String username) {
        User user = userRepo.findByUsername(username).orElseThrow();

        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);

        repo.save(new RefreshToken(token, user, Instant.now().plus(props.refreshTokenTtl())));
        return token;
    }

    /**
     * XOAY VÒNG + PHÁT HIỆN TÁI SỬ DỤNG: token đã thu hồi mà lại xuất hiện → bị đánh cắp hoặc
     * client lỗi → thu hồi TOÀN BỘ phiên của user, bắt đăng nhập lại.
     *
     * BẪY: frontend gọi refresh SONG SONG (hai tab, hai request cùng lúc nhận 401) → request thứ
     * hai dùng token vừa bị xoay → thu hồi cả phiên, người dùng bị đá ra. Frontend phải gom
     * refresh về MỘT lời gọi (Bài 24).
     */
    public RefreshToken kiemTra(String token) {
        RefreshToken rt = repo.findByToken(token)
                .orElseThrow(() -> new InvalidTokenException(ErrorCode.REFRESH_TOKEN_INVALID));

        if (rt.isRevoked()) {
            int soPhien = repo.revokeAllByUserId(rt.getUser().getId());
            log.warn("Refresh token đã thu hồi bị dùng lại — thu hồi {} phiên của user id={}",
                    soPhien, rt.getUser().getId());
            throw new InvalidTokenException(ErrorCode.SESSION_REVOKED);
        }
        if (rt.getExpiresAt().isBefore(Instant.now())) {
            throw new InvalidTokenException(ErrorCode.TOKEN_EXPIRED);
        }
        return rt;
    }

    public void thuHoi(String token) {
        repo.findByToken(token).ifPresent(rt -> rt.setRevoked(true));
    }
}
