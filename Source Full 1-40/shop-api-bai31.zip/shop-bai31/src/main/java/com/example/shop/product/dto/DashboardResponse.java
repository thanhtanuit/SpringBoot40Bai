package com.example.shop.product.dto;

public record DashboardResponse(double usdRate, long tongTonKho, long thoiGianMs) {
}
