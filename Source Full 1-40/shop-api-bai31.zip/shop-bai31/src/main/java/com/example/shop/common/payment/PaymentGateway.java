package com.example.shop.common.payment;

/**
 * Cổng thanh toán. Code nghiệp vụ chỉ biết interface này —
 * KHÔNG có câu if (môi trường == dev) nào ở bất cứ đâu.
 */
public interface PaymentGateway {

    /** @return mã giao dịch */
    String thanhToan(Long orderId, double soTien);
}
