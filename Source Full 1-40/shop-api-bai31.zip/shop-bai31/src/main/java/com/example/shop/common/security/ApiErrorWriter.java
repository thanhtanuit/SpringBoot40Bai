package com.example.shop.common.security;

import java.io.IOException;

import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.LocaleResolver;

import com.example.shop.common.error.ApiError;
import com.example.shop.common.error.ApiResponse;
import com.example.shop.common.error.ErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Bài 30 — entry point và access denied handler nằm NGOÀI @RestControllerAdvice (filter chain,
 * Bài 23) nên phải tự ghi cùng định dạng. Locale lấy qua CHÍNH LocaleResolver của app.
 */
@Component
public class ApiErrorWriter {

    private final ObjectMapper objectMapper;
    private final MessageSource messages;
    private final LocaleResolver localeResolver;

    public ApiErrorWriter(ObjectMapper objectMapper, MessageSource messages, LocaleResolver localeResolver) {
        this.objectMapper = objectMapper;
        this.messages = messages;
        this.localeResolver = localeResolver;
    }

    public void ghi(HttpServletRequest req, HttpServletResponse res, ErrorCode code) throws IOException {
        String message = messages.getMessage(code.messageKey(), null, localeResolver.resolveLocale(req));
        res.setStatus(code.status().value());
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setCharacterEncoding("UTF-8");
        objectMapper.writeValue(res.getWriter(),
                ApiResponse.fail(new ApiError(code.name(), message, req.getRequestURI(), null)));
    }
}
