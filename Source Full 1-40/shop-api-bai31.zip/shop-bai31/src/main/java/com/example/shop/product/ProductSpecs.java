package com.example.shop.product;

import org.springframework.data.jpa.domain.Specification;

import com.example.shop.product.Category;
import com.example.shop.product.Product;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;

/**
 * Bài 15 — mỗi bộ lọc là MỘT hàm.
 *
 * QUY ƯỚC MẤU CHỐT: tham số rỗng → trả null. Specification.allOf bỏ qua null,
 * nên bộ lọc không gửi BIẾN MẤT HẲN khỏi câu SQL — không còn "(? IS NULL OR ...)"
 * như Bài 10, và database dùng được index đúng lúc (Bài 39 đo bằng EXPLAIN ANALYZE).
 *
 * Chữ ký lambda (root, query, cb):
 *   root  — gốc truy vấn = Product. root.get("name") là CHUỖI, KHÔNG kiểm tra lúc biên dịch.
 *           Gõ sai → lỗi lúc chạy. Nhược điểm lớn nhất của Criteria API.
 *           (Nâng cao: static metamodel Product_.name — thêm hibernate-jpamodelgen.)
 *   query — truy vấn tổng thể: distinct, groupBy, phân biệt câu count
 *   cb    — CriteriaBuilder: equal, like, greaterThan, between, isNull, in, and, or, not
 *
 * Thêm bộ lọc mới: thêm một hàm ở đây, một dòng vào allOf trong service.
 */
final class ProductSpecs {

    private ProductSpecs() {
    }

    public static Specification<Product> hasKeyword(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return null;
        }
        String mau = "%" + keyword.trim().toLowerCase() + "%";
        return (root, query, cb) -> cb.like(cb.lower(root.get("name")), mau);
    }

    public static Specification<Product> skuLike(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return null;
        }
        String mau = "%" + keyword.trim().toUpperCase() + "%";
        return (root, query, cb) -> cb.like(root.get("sku"), mau);
    }

    public static Specification<Product> priceGte(Double min) {
        if (min == null) {
            return null;
        }
        return (root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), min);
    }

    public static Specification<Product> priceLte(Double max) {
        if (max == null) {
            return null;
        }
        return (root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), max);
    }

    /**
     * root.get("category").get("id") KHÔNG tạo JOIN — dùng thẳng cột category_id của product.
     */
    public static Specification<Product> inCategory(Long categoryId) {
        if (categoryId == null) {
            return null;
        }
        return (root, query, cb) -> cb.equal(root.get("category").get("id"), categoryId);
    }

    public static Specification<Product> inStock(Boolean inStock) {
        if (inStock == null) {
            return null;
        }
        return (root, query, cb) -> inStock
                ? cb.greaterThan(root.get("stock"), 0)
                : cb.equal(root.get("stock"), 0);
    }

    /**
     * Lọc theo TÊN danh mục — phải JOIN thật: root.join(...) sinh
     * "inner join category c1_0 on c1_0.id = p1_0.category_id".
     */
    public static Specification<Product> categoryNameLike(String categoryName) {
        if (categoryName == null || categoryName.isBlank()) {
            return null;
        }
        String mau = "%" + categoryName.trim().toLowerCase() + "%";
        return (root, query, cb) -> {
            Join<Product, Category> c = root.join("category", JoinType.INNER);
            return cb.like(cb.lower(c.get("name")), mau);
        };
    }
}
