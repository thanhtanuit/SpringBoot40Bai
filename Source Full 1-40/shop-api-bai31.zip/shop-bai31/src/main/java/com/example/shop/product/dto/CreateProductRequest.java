package com.example.shop.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import com.example.shop.product.ValidSku;

/**
 * Dữ liệu client gửi lên khi tạo / sửa sản phẩm.
 *
 * KHÔNG có trường id — client không có cách nào gửi id nữa.
 * Đây là cách chặn mass assignment: trường không tồn tại thì không gán được.
 *
 * BẪY 2: dùng kiểu WRAPPER (Double, Integer), không dùng double, int.
 * Kiểu nguyên thuỷ không chứa được null → client không gửi price thì Jackson
 * điền 0.0 → @NotNull KHÔNG BAO GIỜ bắt được → sản phẩm giá 0 lọt vào,
 * và bạn mất khả năng phân biệt "không gửi" với "gửi số 0".
 *
 * @NotNull  cấm null
 * @NotEmpty cấm null, ""
 * @NotBlank cấm null, "", "   "   ← dùng cho tên
 *
 * {min}, {max} trong message tự thay bằng giá trị trong annotation.
 */
@Schema(description = "Dữ liệu tạo / thay thế sản phẩm")
public record CreateProductRequest(

        // example QUAN TRỌNG HƠN description: Swagger dùng nó điền sẵn form "Try it out".
        // Mặc định springdoc điền "string" và 0 — thường không qua nổi validate.
        @Schema(description = "Tên sản phẩm, không được trùng", example = "Bàn phím cơ Keychron K2")
        @NotBlank(message = "{product.name.notblank}")
        @Size(min = 2, max = 100, message = "{product.name.size}")
        String name,

        // Bài 12: dùng annotation tự viết ở Bài 4. Bắt buộc có (@NotBlank) VÀ đúng dạng (@ValidSku).
        @Schema(description = "Mã SKU dạng ABC-1234", example = "KEY-0002")
        @NotBlank(message = "{product.sku.notblank}")
        @ValidSku
        String sku,

        @Schema(description = "Giá bán (VND)", example = "1250000")
        @NotNull(message = "{product.price.notnull}")
        @Positive(message = "{product.price.positive}")
        Double price,

        // Tuỳ chọn: không gửi thì service coi là 0
        @Schema(description = "Tồn kho ban đầu", example = "15", defaultValue = "0")
        @Min(value = 0, message = "{product.stock.min}")
        Integer stock
) {
}
