package com.example.shop.order.dto;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public record CreateOrderRequest(

        @Schema(example = "Nguyễn Văn A")
        @NotBlank(message = "{order.customer.notblank}")
        @Size(max = 100, message = "{order.customer.size}")
        String customerName,

        /*
         * @NotEmpty chỉ bảo đảm danh sách không rỗng.
         * @Valid BẮT BUỘC để validate lan xuống từng phần tử —
         * thiếu nó, quantity = -5 lọt qua hoàn toàn.
         */
        @NotEmpty(message = "{order.items.notempty}")
        @Valid
        List<OrderItemRequest> items
) {
}
