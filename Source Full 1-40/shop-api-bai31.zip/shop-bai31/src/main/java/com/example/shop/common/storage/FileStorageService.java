package com.example.shop.common.storage;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * Bài 17 — TÁCH SAU INTERFACE ngay từ đầu (ý tưởng Bài 3).
 *
 * Lưu đĩa cục bộ KHÔNG dùng được khi chạy nhiều instance: upload vào máy A, download
 * rơi vào máy B. Docker còn tệ hơn — container restart là mất nếu không mount volume.
 * Thay bằng S3FileStorage là xong, không đụng controller (Bài 37).
 *
 * Hướng tốt hơn cả ở app thật: PRESIGNED URL — client tải thẳng lên S3 bằng URL có chữ ký
 * do server cấp; server không phải nhận và chuyển tiếp hàng megabyte.
 */
public interface FileStorageService {

    /** Lưu file, trả về TÊN file đã sinh (không phải đường dẫn tuyệt đối). */
    String store(MultipartFile file);

    Resource load(String filename);

    void delete(String filename);
}
