package com.example.shop.order;


import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.shop.order.OrderRepository;

/**
 * Bài 20 — job đầu tiên. Method @Scheduled phải KHÔNG THAM SỐ và trả void.
 * initialDelay: không chạy khi app còn đang khởi tạo.
 *
 * fixedRate  đếm từ lúc BẮT ĐẦU lần trước — dồn ứ nếu job chậm hơn chu kỳ.
 * fixedDelay đếm từ lúc KẾT THÚC lần trước — không bao giờ dồn ứ, an toàn hơn.
 * (Thực nghiệm: DemoRateVsDelayJob, profile "demo-job".)
 */
@Component
class OrderStatsJob {

    private static final Logger log = LoggerFactory.getLogger(OrderStatsJob.class);

    private final OrderRepository orderRepo;

    public OrderStatsJob(OrderRepository orderRepo) {
        this.orderRepo = orderRepo;
    }

    @Scheduled(fixedDelay = 60_000, initialDelay = 10_000)
    public void demDonMoi() {
        Instant tuLuc = Instant.now().minus(1, ChronoUnit.MINUTES);
        long soDon = orderRepo.countByCreatedAtAfter(tuLuc);
        log.info("[JOB] Đơn hàng phút vừa rồi: {}", soDon);
    }
}
