package com.example.shop.product;

import org.springframework.stereotype.Component;

import com.example.shop.product.ProductRepository;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Bài 29 — Gauge: giá trị đo TẠI THỜI ĐIỂM đọc. Hàm chạy MỖI LẦN scrape (Prometheus: 15s/lần) →
 * phải là truy vấn rẻ.
 */
@Component
class InventoryMetrics {

    public InventoryMetrics(MeterRegistry registry, ProductRepository productRepo) {
        Gauge.builder("shop.products.low_stock", productRepo, r -> r.countByStockLessThan(5))
                .description("Số sản phẩm sắp hết hàng (tồn < 5)")
                .register(registry);
    }
}
