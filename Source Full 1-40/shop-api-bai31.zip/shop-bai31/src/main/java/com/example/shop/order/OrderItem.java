package com.example.shop.order;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Bài 31 — KHÔNG còn @ManyToOne Product. Lưu productId + BẢN SAO productName, unitPrice
 * tại thời điểm mua (V16).
 *
 * ĐÁNH ĐỔI nhìn thẳng: bỏ khoá ngoại → database không còn đảm bảo product_id trỏ tới sản phẩm
 * có thật. Đổi lại: hai feature ĐỘC LẬP; OrderMapper không join sang product — N+1 Bài 9 biến mất.
 * Cách các hệ thống lớn làm khi tách dịch vụ. Monolith thấy giá quá cao thì giữ @ManyToOne cũng
 * hợp lý — nhưng biết mình đang chọn tiện lợi và chấp nhận hai feature dính nhau.
 */
@Entity
@Table(name = "order_item")
class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    /** Chỉ id — KHÔNG phải quan hệ JPA. */
    @Column(name = "product_id", nullable = false)
    private Long productId;

    /** Chốt tại thời điểm mua — đổi tên sản phẩm về sau không làm sai đơn cũ. */
    @Column(name = "product_name", nullable = false, length = 100)
    private String productName;

    /** Chốt giá (Bài 9). */
    @Column(name = "unit_price", nullable = false)
    private double unitPrice;

    @Column(nullable = false)
    private int quantity;

    protected OrderItem() {
    }

    OrderItem(Long productId, String productName, double unitPrice, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    void setOrder(Order order) {
        this.order = order;
    }

    public double getLineTotal() {
        return unitPrice * quantity;
    }

    public Long getId() {
        return id;
    }

    public Order getOrder() {
        return order;
    }

    public Long getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }
}
