# shop-api — trạng thái sau Bài 31: Package by feature (mở đầu Phần 4)

> Bài này **không thêm tính năng nào** — chỉ di chuyển file và siết ranh giới.
> Thước đo: toàn bộ test Phần 3 vẫn xanh.

## Chạy

```bash
mvn test                           # unit + @WebMvcTest + ArchitectureTest
mvn verify                         # + integration (Docker)
mvn test -Dtest=ArchitectureTest
```

## Cấu trúc mới

```
com.example.shop
├── product/        ProductController, ProductService (public interface),
│   │               ProductServiceImpl · Product · Category · ProductRepository · ProductMapper ·
│   │               ProductSpecs · ProductPresenter · ProductCacheConfig · CleanupJob · ...   (package-private)
│   └── dto/        CreateProductRequest, ProductResponse, ProductSnapshot, ...                (public)
├── order/          OrderController, SalesController, OrderSecurity (public — SpEL gọi từ ngoài)
│   │               OrderService · Order · OrderItem · OrderRepository · OrderMapper · OrderMetrics ·
│   │               NotificationService · OrderStatsJob                                        (package-private)
│   └── dto/
├── user/           AuthController (public) · AuthService · User · Role · RefreshToken ·
│   │               UserRepository · RefreshTokenService · DatabaseUserDetailsService          (package-private)
│   └── dto/
└── common/
    ├── error/      ErrorCode, BusinessException, GlobalExceptionHandler, ApiResponse, ApiError
    ├── audit/      BaseEntity, AuditLog, AuditService, JpaAuditingConfig
    ├── security/   SecurityConfig, JwtService, JwtAuthenticationFilter, ...
    ├── storage/ client/ config/ payment/ web/ job/
```

## Sơ đồ phụ thuộc

```mermaid
graph TD
    order --> product
    order --> common
    product --> common
    user --> common
```

Mũi tên không được tạo vòng. `common` không bao giờ trỏ lên feature.

## Thay đổi thiết kế thật sự

| | Trước | Sau |
|---|---|---|
| order lấy sản phẩm | `ProductRepository` + entity `Product` | `ProductService.layThongTinDeDatHang()` → `ProductSnapshot` |
| order trừ kho | `p.setStock(...)` | `ProductService.truTonKho()` — product giữ bất biến của mình |
| Dọn cache khi trừ kho | `OrderService` biết tên cache `"products"` | `@CacheEvict` trên `truTonKho` |
| `OrderItem` | `@ManyToOne Product` | `productId` + bản sao `productName`, `unitPrice` (V16, bỏ FK) |
| Best-sellers | `ProductService` → `OrderItemRepository` | `order.SalesController` → `OrderService` (URL giữ nguyên) |
| Cache `products` | `common.CacheConfig` biết `ProductResponse` | `product.ProductCacheConfig` |
| Audit CREATE | `OrderService` → `AuditLogRepository` | `AuditService.ghiCungGiaoDich()` |

**Đánh đổi của V16:** database không còn đảm bảo `product_id` trỏ tới sản phẩm có thật. Đổi lại:
hai feature độc lập, `OrderMapper` không join sang product — N+1 của Bài 9 biến mất.

## Test đã điều chỉnh

| | |
|---|---|
| Test di chuyển theo package | Để truy cập class package-private |
| `OrderServiceTest` | Mock `ProductService` + `ProductSnapshot`, kiểm `verify(truTonKho)` |
| `OrderFlowIntegrationTest` | Repository → **JdbcTemplate** — kiểm kết quả thật, không phụ thuộc cấu trúc code |
| `architecture/ArchitectureTest` | **Mới** — vòng tròn, chiều phụ thuộc, controller không gọi repository / không trả entity, entity feature không public, không `@Autowired` field |

> Test không truy cập được nội bộ → dấu hiệu nó đang kiểm chi tiết cài đặt thay vì hành vi.

## Ba điều đọng lại

1. Package by feature là điều kiện để **giấu được chi tiết** — và giấu được mới tạo ra ranh giới thật.
2. Bỏ `public` khỏi `ProductRepository` → danh sách lỗi compile **chính là** danh sách vi phạm ranh giới.
3. Refactor không có test là đánh bạc.

Bài 32: `OrderService` vẫn ôm ba trách nhiệm, thông báo gửi trước commit → event nội bộ.
