# docs/ — đặc tả OpenAPI xuất ra file (Bài 28)

App đang chạy (profile dev):

```bash
curl http://localhost:8081/v3/api-docs/all      -o docs/openapi.json
curl http://localhost:8081/v3/api-docs.yaml/all -o docs/openapi.yaml
```

(Có nhóm `all`, `public`, `admin` nên đường dẫn có hậu tố tên nhóm.)

**Commit `openapi.json` vào repo:**

1. **Thấy thay đổi API trong pull request** — ai đổi tên field hay xoá endpoint thì diff hiện rõ.
2. **Phát hiện breaking change tự động** — `openapi-diff` so hai phiên bản; Bài 38 đưa vào CI.

Công khai tài liệu cho bên ngoài: host file tĩnh này, không để endpoint sống trong app production.
