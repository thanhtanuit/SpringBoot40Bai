# PromQL cho dashboard nghiệp vụ (Bài 29)

```promql
# Đơn hàng mỗi phút
rate(shop_orders_created_total[1m]) * 60

# Đơn thất bại theo lý do
sum by (reason) (rate(shop_orders_failed_total[5m]))

# Tỷ lệ lỗi 5xx — ỨNG VIÊN CẢNH BÁO ĐẦU TIÊN: > 1% trong 5 phút thì báo
sum(rate(http_server_requests_seconds_count{status=~"5.."}[5m]))
  / sum(rate(http_server_requests_seconds_count[5m]))

# p95 thời gian xử lý đơn
shop_orders_duration_seconds{quantile="0.95"}

# Connection đang CHỜ trong pool — khác 0 kéo dài = pool nhỏ hoặc truy vấn chậm (Bài 39)
hikaricp_connections_pending

# Sản phẩm sắp hết
shop_products_low_stock
```
