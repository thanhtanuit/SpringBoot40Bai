# shop-api — trạng thái sau Bài 26: Test tầng Controller

> `@WebMvcTest` test **hợp đồng HTTP**: URL nào gọi được, mã trạng thái nào, JSON hình dạng gì,
> **ai được phép**. Nghiệp vụ đã có Bài 25 lo.

## Chạy

```bash
mvn test                                         # không cần Docker
mvn test -Dtest=ProductControllerTest            # so thời gian ↓
mvn test -Dtest=ProductControllerIntegrationTest
```

| | Khởi tạo context | Tổng |
|---|---|---|
| `@WebMvcTest` | ~1.5s | ~2s |
| `@SpringBootTest` | ~8s | ~9s |

Ghi số thật của bạn vào Notion.

## Test mới

```
src/test/java/com/example/shop/web/
├── ProductControllerTest.java             GET/404/400, validate, 409, ẩn costPrice, ma trận quyền
├── OrderControllerTest.java               quyền sở hữu (OrderSecurity mock), validate List
└── ProductControllerIntegrationTest.java  @SpringBootTest — chỉ để so thời gian
```

## Ma trận quyền đã thành test

| | Ẩn danh | USER | SELLER | ADMIN |
|---|---|---|---|---|
| `GET /api/products/{id}` | 200 | | | |
| — `costPrice` | ẩn | | ẩn | hiện |
| `POST /api/products` | 401 | 403 | 201 | 201 |
| `PATCH /api/products/{id}` | | 403 | | |
| `DELETE /api/products/{id}` | 401 | 403 | 403 | 204 |
| `GET /api/orders/{id}` | 401 | chủ đơn 200 / khác 403 | | |

## Bẫy

| Bẫy | |
|---|---|
| Không `@Import(SecurityConfig)` | Dùng security tự động → test phân quyền sai lệch mà vẫn **xanh** |
| `roles = "ROLE_USER"` | Thành `ROLE_ROLE_USER` — dùng `roles = "USER"` |
| Chuỗi JSON viết tay | Đổi tên field DTO không lỗi compile — dùng `ObjectMapper` (trừ khi cố tình gửi JSON hỏng) |
| `@MockitoBean` khác nhau mỗi class | Mỗi biến thể một context mới — suite chậm dần |
| `.andDo(print())` khắp nơi | Log CI dài vô dụng — chỉ bật khi tìm lỗi |

## Giới hạn

Service bị mock → **không** chứng minh hệ thống chạy đầu-cuối. Endpoint xanh ở đây vẫn có thể
hỏng vì truy vấn sai hay migration thiếu. Bài 27: Testcontainers.
