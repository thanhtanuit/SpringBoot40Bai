# shop-api — trạng thái sau Bài 12: Quản lý schema bằng Flyway

> Từ Bài 8, cấu trúc bảng do Hibernate đoán. Hôm nay **giành lại quyền kiểm soát**:
> bạn viết SQL, có đánh số phiên bản, có lịch sử từng bước.

## Chạy

```bash
docker compose down -v      # MỘT LẦN: xoá sạch DB cũ do ddl-auto: update tạo
docker compose up -d
mvn spring-boot:run
```

Log khởi động:

```
Successfully validated 3 migrations
Creating Schema History table "public"."flyway_schema_history"
Current version of schema "public": << Empty Schema >>
Migrating schema "public" to version "1 - init schema"
Migrating schema "public" to version "2 - seed data"
Migrating schema "public" to version "3 - add sku"
Successfully applied 3 migrations
```

Sau đó Hibernate **im lặng** — nghĩa là validate xong, entity khớp schema.
Khởi động lần hai: `Current version: 3`, không migration nào chạy lại.

## Migration

```
src/main/resources/db/migration/
├── V1__init_schema.sql   bốn bảng, ràng buộc đặt tên tường minh
├── V2__seed_data.sql     3 danh mục, 5 sản phẩm — không cần ON CONFLICT
└── V3__add_sku.sql       mẫu ba bước: thêm nullable → điền → siết NOT NULL
```

Xem lịch sử:

```bash
docker compose exec postgres psql -U shop -d shop \
  -c "SELECT version, description, checksum, success FROM flyway_schema_history"
```

## Thay đổi so với Bài 11

| | |
|---|---|
| `pom.xml` | + `flyway-core`, `flyway-database-postgresql` |
| `application-dev.yml` | `ddl-auto: validate`, `spring.flyway` — xoá `defer`, `sql.init` |
| `data.sql` | **Xoá** — thay bằng V2 |
| `Product` + DTO + mapper + service | Thêm `sku`, dùng `@ValidSku` của Bài 4, trùng SKU → 409 |

## Hai thí nghiệm

1. **validate chặn:** thêm `private String note;` vào `Product`, không viết migration →
   `Schema-validation: missing column [note] in table [product]`. Xoá đi.
2. **checksum:** thêm một dấu cách vào `V1__init_schema.sql` →
   `Migration checksum mismatch for migration version 1`. Hoàn tác.

> Migration đã chạy là **bất biến**. Muốn sửa schema: viết file mới.

## Ba cái bẫy

| Bẫy | Hậu quả |
|---|---|
| Thiếu `flyway-database-postgresql` | "Unsupported Database: PostgreSQL" lúc boot |
| Tên file một dấu gạch dưới | Flyway im lặng bỏ qua |
| Sửa migration đã chạy | Schema hai nơi lệch nhau, cả hai cùng báo một phiên bản |

## Bốn quy tắc thực hành

1. Mỗi thay đổi schema là một file mới.
2. Nhiều người cùng làm: đánh số theo thời gian (`V20260911_1__...`).
3. Đừng `DROP COLUMN` vội — deploy code bỏ dùng cột trước.
4. Đọc kỹ migration trong PR — `UPDATE` thiếu `WHERE` là mất dữ liệu thật.

Đổi tên cột không downtime: **expand–contract**, bốn lần deploy — xem slide Bài 12.
